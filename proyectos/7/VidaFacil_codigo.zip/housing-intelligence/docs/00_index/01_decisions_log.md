# Registro de Decisiones

## D-001 — Producto con tres capas
**Decisión:** PUBLIC + PRO + DATA/API/MCP.

## D-002 — Capa gratuita completa
La mayoría de funcionalidades que ayudan al ciudadano deben permanecer gratis para maximizar utilidad, adopción y aprendizaje agregado.

## D-003 — No vender datos personales
La capa PRO solo utilizará datos agregados/anonimizados y fuentes públicas/propias.

## D-004 — Fuente de verdad
La IA no será la fuente de verdad. La fuente de verdad será la combinación de datos estructurados, reglas, modelos, features y versiones.

## D-005 — GIS
PostgreSQL + PostGIS serán el corazón geoespacial.

## D-006 — Base vectorial
pgvector inicialmente, evitando infraestructura extra hasta que sea necesaria.

## D-007 — Geografía
Usar límites administrativos + H3 como malla analítica común.

## D-008 — JEV
JEV se utilizará para decisiones rápidas, tipadas y probabilísticas: clasificación, routing, control de calidad y reranking.

## D-009 — LLM
Claude Fable 5 se reserva para razonamiento complejo, conversación, informes y fallback; no para cálculos ni clasificaciones masivas.

## D-010 — Mapa
MapLibre + deck.gl como stack principal. Digital twin 3D estilizado, no Google Earth completo.

## D-011 — Madrid 3D
Aprovechar modelo 3D oficial de edificios de Madrid cuando sea viable.

## D-012 — MVP
“MVP” para DATAMAD significa versión reducida geográficamente pero técnicamente avanzada, no demo superficial.


## D-013 — Fase actual: datos antes que código
Antes de iniciar desarrollo fuerte se completará inventario de fuentes, taxonomía, geografía y feature dictionary.

## D-014 — Datos exactos vs conocimiento semántico
Población, precios, distancias y métricas exactas vivirán en PostgreSQL/PostGIS. La base vectorial se reserva para documentación, semántica y embeddings de lugares.

## D-015 — Dataset temporal
Cada fuente tendrá frecuencia de actualización explícita y el producto distinguirá datos estructurales, periódicos y casi tiempo real.

## D-016 — Prioridad de fuentes oficiales
Para DATAMAD se priorizarán fuentes oficiales de Comunidad de Madrid y Ayuntamiento, complementadas con INE, Catastro y transporte.


## D-017 — Enriquecimiento multi-fuente
La plataforma combinará fuentes oficiales, Catastro, OSM/POIs, APIs comerciales opcionales y scraping selectivo.

## D-018 — Source Trust
Cada dato tendrá procedencia, frescura y nivel de confianza. Las fuentes oficiales prevalecen cuando exista conflicto.

## D-019 — Entity Resolution
Se construirá un registro canónico de lugares para deduplicar colegios, hospitales, negocios y otros POIs entre múltiples fuentes.

## D-020 — POI scoring
Los POIs no se puntuarán mediante conteo bruto. Se transformarán en accesibilidad, cobertura, diversidad, redundancia y tiempo de viaje.


## D-021 — Documentación orientada a ejecución
La documentación se considera ahora input directo para Claude Code. Debe incluir contratos, acceptance criteria, tests y reglas de implementación.

## D-022 — CLAUDE.md raíz
El repositorio final incluirá un `CLAUDE.md` como punto de entrada obligatorio para agentes de código.

## D-023 — Source/Dataset/Metric registries
Fuentes, datasets y métricas serán entidades versionadas de primera clase.

## D-024 — No SQL libre desde IA
Ni Claude ni MCP expondrán ejecución SQL arbitraria. Toda consulta de negocio debe pasar por tools/servicios.

## D-025 — Model registry
Todo modelo ML activo deberá tener versión, dataset/feature versions, evals y rollback.


## D-026 — Actualización de datos por frecuencia natural
Cada fuente se actualizará según su frecuencia real. No se forzará una única cadencia global.

## D-027 — Perfil persistente con consentimiento
El usuario podrá guardar perfil completo si crea cuenta y acepta el tratamiento. PII y señales analíticas se separarán técnicamente.

## D-028 — Recomendación híbrida
Residential Fit usará hard constraints + scoring explicable + ML progresivo + reranking cuando corresponda.

## D-029 — Prioridades corregibles
La IA propondrá prioridades/pesos y el usuario podrá corregirlas manualmente.

## D-030 — Mapa 3D estilo SimCity
El producto usará una visualización 3D estilizada, tipo SimCity/Jarvis, basada en geometría real y capas analíticas.

## D-031 — Natural Language GIS
El usuario podrá consultar el mapa en lenguaje natural. La IA traducirá la intención a filtros y tools predefinidos; no generará SQL libre.

## D-032 — Plan intermedio de particulares
Se contempla una capa de pago para particulares con mayor número de consultas/análisis avanzados, manteniendo una capa gratuita útil.

## D-033 — Monetización temprana de consumo
AdSense/SEO se podrá utilizar inicialmente en contenido editorial y páginas informativas, separado del mapa interactivo y sin degradar experiencia.

## D-034 — Confidence explícito
Las estimaciones y datos interpolados deberán mostrar confidence/frescura y no aparentar precisión inexistente.

## D-035 — Enriquecimiento por fases
Fase inicial: oficial + OSM/APIs. Fase posterior: ampliar scraping de forma controlada, legal y versionada cuando aporte cobertura real.

## D-036 — Accesibilidad > conteo POI
Los servicios se medirán por tiempo, cobertura, diversidad, redundancia, horario y accesibilidad real.

## D-037 — Madrid Place Model
Se entrenará un modelo territorial propio con 200–400 features y embeddings por microzona.

## D-038 — Aprendizaje progresivo de comportamiento
Las señales de uso agregadas alimentarán primero analytics y, con suficiente volumen/calidad, entrenamiento del recomendador.

## D-039 — Housing Gap avanzado
PRO deberá recomendar no solo dónde hay gap, sino tipología, tamaño, precio objetivo, target y producto residencial sugerido.

## D-040 — Parcel Intelligence ampliado
PRO analizará zonas, parcelas y proyectos/activos subidos por clientes.

## D-041 — Private Data Enrichment
Clientes PRO podrán conectar datos propios aislados por tenant. Nunca se incorporarán al dataset global sin un acuerdo/base específica.

## D-042 — JEV en desarrollo y producción
JEV se utilizará tanto en preparación de datos como en runtime para clasificación, routing, control de calidad y reranking.

## D-043 — pgvector con dos familias
pgvector almacenará RAG documental y embeddings territoriales. No será fuente de cifras exactas.

## D-044 — MCP PRO avanzado
Objetivo a medio plazo: permitir que agentes creen consultas analíticas y capas de mapa temporales desde lenguaje natural.

## D-045 — Evaluador de vivienda por URL/dirección
PUBLIC podrá analizar una vivienda concreta importando datos de un anuncio cuando sea legal/técnicamente posible.

## D-046 — Reality Check como optimizador
El sistema no solo explicará por qué una búsqueda falla: propondrá la mínima modificación de presupuesto, tiempo, tamaño, municipio, movilidad o tenure para volverla viable.


## D-047 — Datos económicos exactos protegidos + rangos derivados
Ingresos, ahorro y deuda podrán almacenarse con valor exacto protegido para cálculo individual. Analytics y PRO usarán rangos/segmentos derivados.

## D-048 — Separación identidad/perfil
La identidad de usuario se almacenará separada del perfil residencial/económico y se unirá por identificador interno.

## D-049 — Ubicaciones sensibles minimizadas
Lugares de trabajo/familia podrán usarse con precisión suficiente para routing, pero se almacenarán minimizando precisión cuando no sea necesaria o cifrando la ubicación exacta.

## D-050 — Datos sensibles voluntarios
Movilidad reducida, dependencia u otras necesidades sensibles solo podrán introducirse voluntariamente y tendrán protección reforzada. Nunca se inferirán silenciosamente.

## D-051 — Entrenamiento territorial H3 + contexto vecinal
Los modelos territoriales usarán H3/sección censal como base y features de contexto de celdas vecinas.

## D-052 — Jerarquía de datos faltantes
Dato directo → agregación razonable → estimación documentada → desconocido. Cada degradación reduce confidence.

## D-053 — Residential Fit evolutivo
Fase inicial: hard constraints + pesos personalizados y explicables. Fase posterior: ML personalizador/ranker, manteniendo el baseline interpretable.

## D-054 — Primer ML de preferencias
Learning-to-Rank/gradient boosting será la primera familia prevista cuando haya volumen suficiente de feedback.

## D-055 — Price/Rent Model
Usar ML estructurado para precio/alquiler combinado con estadísticas oficiales y siempre con intervalos/confidence.

## D-056 — Madrid Place Model
200–400 features territoriales y embeddings de 64–128 dimensiones como diseño inicial.

## D-057 — Histórico MVP
El MVP utilizará actualidad + aproximadamente 3–5 años cuando exista histórico suficiente. El histórico completo queda para evolución posterior.

## D-058 — Emerging Areas
PRO incluirá detección de zonas emergentes a partir de tendencias de población, renta, vivienda, actividad, transporte y servicios.

## D-059 — Forecasting por horizontes
MVP: forecast operativo 1–3 años. Producto completo: escenarios adicionales 5–10 años claramente etiquetados como escenarios y no predicción exacta.

## D-060 — Confidence por componente
Cada fuente/modelo puede tener confidence propio y el resultado puede ofrecer un confidence agregado.

## D-061 — Feedback estructurado + texto
Motivos de rechazo rápidos más texto opcional.

## D-062 — Entrenamiento controlado
No habrá online learning autónomo. Nuevas versiones se entrenan, evalúan, comparan y activan solo tras superar criterios.

## D-063 — Explicabilidad ultra-simple
Las explicaciones deben ser comprensibles sin interpretar métricas abstractas. Priorizar lenguaje cotidiano, comparaciones concretas y ejemplos tangibles.

## D-064 — PRO no expone atributos sensibles
PRO podrá ver necesidades agregadas como “demanda de vivienda accesible”, nunca perfiles sensibles ni atributos individuales.

## D-065 — Cold Start experto
Datos públicos + reglas expertas + perfiles sintéticos para arrancar antes de tener masa de usuarios.

## D-066 — Simulador PRO avanzado
El producto completo incluirá simulación de proyectos: hogares compatibles, absorción, competencia, servicios, movilidad, sensibilidad de precio y escenarios territoriales.

## D-067 — Madrid-first para DATAMAD
En el MVP DATAMAD los datos del Catálogo de Datos Abiertos de la Comunidad de Madrid serán estructurales y alimentarán funcionalidades centrales. Otras fuentes solo complementan, validan o enriquecen.


## D-068 — Micro-location before neighborhood averages
La plataforma no tratará un barrio como unidad homogénea. El scoring principal se calculará a nivel microzona/H3/sección censal y podrá descender a calle/edificio cuando exista cobertura suficiente.

## D-069 — Housing feature set amplio
El modelo de vivienda intentará incorporar precio, superficie, dormitorios, antigüedad, tipología, ascensor, garaje, eficiencia, accesibilidad, obra nueva/usada, tenencia, densidad y vacancia cuando exista información fiable y legalmente reutilizable.

## D-070 — Accesibilidad peatonal por red
La proximidad a servicios se medirá preferentemente por recorridos y tiempos reales de red, no por radio euclídeo.

## D-071 — Transporte multimodal completo
El modelo de movilidad incorporará Metro, autobuses urbanos/interurbanos, Cercanías, Metro Ligero, tren/ferrocarril y otros modos disponibles, considerando acceso, frecuencia, transbordos y destinos.

## D-072 — Múltiples anchors personales
El perfil podrá contener varios destinos relevantes: trabajo, pareja, colegio, familia, universidad, hospital u otros, cada uno con frecuencia y prioridad.

## D-073 — Medio ambiente personalizado
Ruido, contaminación, calor y verde serán capas territoriales y podrán influir en Residential Fit según preferencias.

## D-074 — Actividad urbana dinámica
La vida de barrio se modelará con diversidad, proximidad, horarios y evolución de aperturas/cierres cuando existan datos.

## D-075 — Seguridad objetiva y metodológicamente prudente
La plataforma podrá incorporar seguridad vial y seguridad ciudadana basada en datos oficiales/agregados. No ocultará diferencias territoriales, pero evitará etiquetas estigmatizantes y falsa precisión.

## D-076 — Educación avanzada
El modelo familiar podrá considerar proximidad, etapa, titularidad, oferta/cobertura y otros datos comparables disponibles, evitando rankings simplistas de “barrios buenos/malos”.

## D-077 — Salud avanzada
El modelo incluirá centros de salud, hospitales, farmacias, tiempos de acceso, tipología de centro, urgencias/especialidades y cobertura cuando existan datos.

## D-078 — Building intelligence best-effort
A nivel edificio se intentará combinar Catastro, geometría, contexto, documentación técnica y estimaciones. Si no existe cobertura suficiente, se degradará a contexto catastral/territorial sin inventar datos.

## D-079 — 15-Minute Living Model
Se construirá un modelo de acceso a necesidades en 5, 10 y 15 minutos, personalizado por perfil y multimodal cuando corresponda.

## D-080 — Car Dependency Model
Se calculará dependencia del coche y el impacto económico/temporal de vivir con o sin vehículo privado.

## D-081 — Total Housing Cost completo
El coste residencial incluirá vivienda, energía, transporte, coche, parking, comunidad, impuestos, mantenimiento y coste temporal cuando los datos lo permitan.

## D-082 — Timeline territorial
El mapa deberá soportar evolución histórica y, posteriormente, forecast/escenarios en una experiencia visual tipo SimCity.

## D-083 — Economic Fabric PRO
PRO analizará tejido empresarial, comercio, oficinas, empleo y actividad económica alrededor de zonas y parcelas.

## D-084 — Emerging Opportunity Model
Se desarrollará un modelo de oportunidad emergente combinando cambios de población, vivienda, negocios, transporte, renta y servicios.

## D-085 — Infrastructure Scenario Engine
DATAMAD puede incluir una versión limitada; el producto completo permitirá simular nuevas estaciones, colegios, hospitales, promociones u otras infraestructuras y recalcular el territorio.

## D-086 — Hybrid Technical RAG
Las consultas técnicas combinarán documentación RAG + datos GIS + métricas estructuradas + modelos, no solo texto.

## D-087 — Similarity Search explicable
La búsqueda “como X pero más barato/verde/conectado” usará Place Embeddings + restricciones del usuario + explicación de similitudes y diferencias.

## D-088 — Objetivo de 300–500 features
El feature universe aspirará a 300–500 variables base/derivadas bien documentadas. El MVP usará un subconjunto estable y probado.


## D-089 — Doble referencia territorial
Los scores podrán compararse contra toda Madrid y contra zonas comparables, evitando interpretaciones engañosas.

## D-090 — Tipologías territoriales híbridas
Se usarán clustering/Place Embeddings para descubrir tipologías de zonas, con interpretación y naming humano.

## D-091 — Movilidad sensible a horario
Cuando existan datos, la accesibilidad tendrá en cuenta horarios reales, frecuencia y franjas temporales.

## D-092 — Pendiente y caminabilidad personalizada
La dificultad peatonal podrá incorporar pendiente/ruta y perfil del usuario cuando haya datos suficientes.

## D-093 — Barreras urbanas explícitas
Además del routing, se modelarán barreras urbanas relevantes como vías rápidas, ferrocarril o cruces complejos.

## D-094 — Capacidad de servicios best-effort
Cuando existan datos fiables, colegios, hospitales y otros servicios incorporarán capacidad/servicios; si no, se degradará a tipología/tamaño.

## D-095 — Presión oferta-demanda en servicios
Cuando exista información suficiente, se calculará saturación/cobertura relativa, no solo oferta bruta.

## D-096 — Submodelos por etapa de vida
El motor común tendrá módulos especializados FamilyFit, SeniorFit, StudentFit, AccessibleLivingFit y otros que puedan surgir.

## D-097 — Preferencias inferidas solo como sugerencia
La IA podrá proponer factores plausibles según contexto, pero pedirá confirmación antes de incorporarlos como preferencia.

## D-098 — Progressive profiling
El onboarding será progresivo y preguntará solo lo necesario para mejorar la recomendación.

## D-099 — Active Questioning
El sistema priorizará preguntas que reduzcan más incertidumbre o cambien materialmente el ranking.

## D-100 — Data Coverage Map
Se construirá una capa de cobertura/calidad de datos por microzona.

## D-101 — Históricos versionados
Se conservarán snapshots/versiones de métricas y datasets relevantes para análisis temporal.

## D-102 — Correcciones de fuentes versionadas
Si una fuente corrige históricos, se conservará trazabilidad y se recalcularán dependencias afectadas.

## D-103 — Lineage completo
PUBLIC verá explicaciones sencillas; PRO/engineering podrá acceder a lineage detallado por métrica/score.

## D-104 — Incertidumbre de precio explicada
Estimaciones de precio/alquiler se expresarán como rangos y con explicación de incertidumbre.

## D-105 — Detección de anomalías multi-capa
Outliers mediante reglas + estadística + JEV para triage/revisión.

## D-106 — Knowledge Graph opcional
No es requisito del MVP. Queda documentado para incluirlo solo si sobra tiempo o las relaciones justifican claramente su coste.

## D-107 — Simulación territorial gradual
DATAMAD puede recalcular un subconjunto de variables ante escenarios. Producto completo aspirará a simulación before/after más completa.

## D-108 — Feature abundance, model restraint
El sistema puede tener 300–500 features disponibles, pero cada modelo usará solo las que aporten señal, estabilidad y explicabilidad.

## D-109 — Map-first onboarding
No habrá formulario tradicional como experiencia principal. El usuario entra al mapa y usa chat, chips y filtros.

## D-110 — Conversational + filter UX
Chat y filtros son interfaces sobre un único `ScenarioState`.

## D-111 — Accessibility needs, not diagnosis labels
No crear rankings rígidos por diagnóstico. Modelar necesidades concretas de accesibilidad, movilidad, estímulo, orientación y servicios.

## D-112 — Accessibility is core
Accesibilidad física, visual, auditiva, cognitiva y sensorial forma parte del Residential Intelligence Engine.

## D-113 — No silent inference of disability
Nunca inferir discapacidad, autismo, salud mental u otra condición sensible del comportamiento.

## D-114 — Sensory/cognitive adaptation
El ranking podrá considerar ruido, intensidad peatonal, complejidad de rutas/transbordos, previsibilidad y accesibilidad cognitiva cuando el usuario lo solicite.

## D-115 — Visual-accessibility routing
Incorporar cuando haya datos: avisadores acústicos, cruces, accesibilidad de aceras, complejidad de intersecciones, transporte accesible, obras/incidencias y ayudas de orientación.

## D-116 — Accessibility confidence
No afirmar que una calle/edificio es accesible si solo existen proxies territoriales.

## D-117 — Multi-stage Residential Fit pipeline
Hard constraints → candidate generation → structured scoring → ML/JEV reranking → diversified top results.

## D-118 — Reality Check on empty result
Una búsqueda sin resultados activa diagnóstico de constraints y alternativas mínimas.

## D-119 — Composite + component scores
Score global para ordenar + subscores por coste, movilidad, servicios, entorno, accesibilidad, vivienda, etc.

## D-120 — Personal fit vs territorial quality
Separar “te encaja a ti” de la referencia/calidad territorial general.

## D-121 — Hybrid weight generation
Pesos por baseline experto + preferencias explícitas + contexto + aprendizaje posterior.

## D-122 — Pareto recommendation
Representar compromisos entre objetivos en conflicto.

## D-123 — Confidence-aware scoring
La fiabilidad del dato afecta la certeza y puede bloquear validación si es crítica.

## D-124 — Spatial continuity controls
Contexto vecinal y suavizado selectivo para evitar saltos artificiales.

## D-125 — Piecewise affordability preference
Curvas por tramos: ideal, cómodo, máximo y exclusión.

## D-126 — Multi-anchor weighted mobility
Anchors ponderados por frecuencia, importancia y tolerancia.

## D-127 — Saturation functions
Servicios y POIs usan rendimientos decrecientes.

## D-128 — Hard vs soft penalty
Solo hard constraints o “evitar” eliminan automáticamente.

## D-129 — Safety moderation
Seguridad con peso moderado, personalización y metodología explícita.

## D-130 — Verified accessibility constraints
Requisitos como ascensor/step-free solo se dan por cumplidos con evidencia suficiente; si no, UNKNOWN.

## D-131 — AreaFit + HomeFit
Mismo motor base, capas específicas para zona y vivienda.

## D-132 — Session adaptation, controlled global learning
La sesión adapta; el modelo global cambia solo tras evaluación.

## D-133 — Result diversity
El top contiene alternativas realmente distintas.

## D-134 — Subjective concept enrichment
Ambiente/tranquilidad/vida de barrio se modelan con señales observables y web enrichment trazable.

## D-135 — Explicit alternative discovery
Las alternativas fuera de constraints se separan visualmente.

## D-136 — Algorithm invariants
Validación con golden profiles, synthetic profiles, casos reales e invariantes lógicos.

## D-137 — Bronze/Silver/Gold + lineage completo
Conservar RAW original, versión normalizada y features finales reproducibles.

## D-138 — Source disagreement is data
No esconder discrepancias entre fuentes; almacenarlas y resolverlas mediante políticas por métrica.

## D-139 — Multi-scale features
Cada microzona puede tener features propias y contextuales a 5/10/15 min y vecindad H3.

## D-140 — Null reason taxonomy
Distinguir missing_source, not_applicable, stale, parse_error, coverage_gap, genuinely_absent y otros estados.

## D-141 — Domain feature stores
Features separadas por vivienda, movilidad, servicios, ambiente, economía, urbanismo, etc., con vistas unificadas para modelos.

## D-142 — 30–50 deeply integrated DATAMAD datasets
El MVP prioriza profundidad, calidad y trazabilidad frente a acumular datasets superficiales.

## D-143 — Graceful domain degradation
Si falta un dominio, el motor reduce confidence y aplica reglas de redistribución; nunca imputa 0 por defecto.

## D-144 — Market listing history subject to lawful access
El histórico de anuncios es objetivo estratégico, pero solo se ingiere mediante permiso, licencia, API/proveedor autorizado o fuente reutilizable.

## D-145 — Catastro via official services
Catastro se ingiere preferentemente mediante INSPIRE WFS/ATOM/WMS y productos oficiales, no scraping de interfaz.

## D-146 — Transport via official open feeds
CRTM/operadores: GTFS/API/open data primero; scraping solo como último recurso y nunca para sustituir feeds oficiales.

## D-147 — Commercial activity history
Aprovechar censos de locales/actividades actuales e históricos para churn, aperturas/cierres, intensidad y evolución.

## D-148 — Machine-readable Feature Dictionary
Cada feature tendrá definición canónica YAML/JSON y documentación Markdown derivada/sincronizada.

## D-149 — Feature quality gate
Una feature no entra a producción sin contrato, tests, lineage, confidence, versionado y utilidad definida.

## D-150 — Mid-market developer first GTM
La punta de lanza comercial será promotora/inmobiliaria mediana por accesibilidad comercial y ciclo de venta razonable.

## D-151 — Sell analysis before full SaaS
Antes de completar PRO, monetizar estudios e informes apoyados por la plataforma.

## D-152 — PRO integrated workspace
PRO combina mapa, chat, análisis, escenarios, exportes e informes.

## D-153 — Dual entry: site-first or thesis-first
Una promotora puede empezar por “tengo esta parcela” o “quiero construir este producto”.

## D-154 — Conversational Opportunity Finder
Permitir búsqueda territorial desde tesis de inversión/producto mediante lenguaje natural.

## D-155 — Residential vertical extensibility
El core debe soportar BTR, senior, student, accessible, family/public housing y otras verticales sin duplicar motor.

## D-156 — Project workspace
Cada activo/proyecto tendrá workspace con documentos, análisis, capas, escenarios y comentarios.

## D-157 — Tenant-isolated private data
CRM/leads/cartera/precios/absorción privados se aíslan por tenant.

## D-158 — Competitive benchmarking
Comparar proyectos con oferta comparable y posicionamiento cuando haya datos suficientes.

## D-159 — Price sensitivity engine
PRO podrá estimar cómo cambia demanda compatible según precio/renta objetivo.

## D-160 — Financial scenarios later
No posicionar el MVP como asesoramiento financiero. Añadir escenarios económicos cuando el cliente introduzca supuestos.

## D-161 — B2G same core
Administraciones usan el mismo motor con objetivos y UX específicos.

## D-162 — Tiered PRO pricing
Profesional individual, Business y Enterprise/B2G.

## D-163 — Consumer PLUS
Plan intermedio para particulares con más consultas, escenarios, alertas y análisis.

## D-164 — Useful FREE
La capa gratuita debe resolver el problema principal sin paywall artificial.

## D-165 — Editorial ad monetization only
Adsense limitado a páginas editoriales/SEO; no contaminar mapa/ranking.

## D-166 — Opt-in contextual monetization
Afiliación contextual separada del ranking y siempre opt-in.

## D-167 — Paid reports ladder
Ofrecer desde análisis rápidos hasta estudios de mayor profundidad/importe.

## D-168 — DATA as product
API/MCP con pricing por uso/volumen/SLA y límites según plan.

## D-169 — Residential Intelligence Infrastructure
La empresa se define como infraestructura de inteligencia residencial, no como portal inmobiliario.

## D-170 — Final-product-first development
Se intentará construir el producto final desde el inicio. DATAMAD no tendrá una arquitectura MVP separada.

## D-171 — Controlled scope cuts
Si falta tiempo, se desactivan capabilities mediante flags/fallbacks, manteniendo arquitectura final.

## D-172 — Capability tiering
Toda funcionalidad se clasifica por criticidad/valor/riesgo para ordenar implementación y posibles recortes.

## D-173 — No throwaway hackathon code
Evitar mocks/arquitecturas temporales que haya que desechar salvo prototipos estrictamente de investigación.


## D-174 — Trabajo previo permitido por las bases (2026-10-20)
Las bases oficiales DATAMAD 2026 (§6 "Proyectos preexistentes") permiten usar código, componentes e investigación previos si se identifican, siempre que la propuesta evolucione de forma sustancial entre el 7 y el 26 de noviembre. Se cierra `DATAMAD-PREWORK-01`. Se creará el tag git `pre-datamad` el 6 de noviembre y se declarará el trabajo previo en README y slides. Fuente: `09_datamad/24_bases_oficiales_2026.md`.

## D-175 — Google Maps / Gosom fuera del proyecto DATAMAD (2026-10-20)
`google_maps_scraped` queda `REJECTED`: los términos de Google prohíben la extracción automatizada y las bases (§6.3, §6.7, §16) excluyen datos obtenidos ilícitamente. POIs desde Ayuntamiento, Comunidad de Madrid y OpenStreetMap. Pendiente de Mariano: confirmar o permitir un benchmark privado fuera del repo. Ver `07_privacy_legal/source_reviews/google_maps_gosom.md`.

## D-176 — Entornos de base de datos (2026-10-20)
Docker local (Postgres 17 + PostGIS 3.6 + pgvector 0.8) para desarrollo, tests y CI. Proyecto Supabase free dedicado (`ilvbivfnqvfqslbbiuts`) como entorno remoto/demo, accesible por el MCP de proyecto `supabase-datamad`. Sin h3-pg en Supabase: H3 se calcula siempre en Python. El código solo cambia `DATABASE_URL`.

## D-177 — Toolchain (2026-10-20)
Python 3.12 con uv workspace (wheels geo en arm64), ruff, pyright (strict en `packages/contracts`), pytest + hypothesis, gitleaks con regla explícita para tokens `sbp_`. Node 24 con npm workspaces, Next.js 16, TypeScript 5.9 strict, ESLint 9, Vitest 5.

## D-178 — Imagen de base de datos propia (2026-10-20)
`postgis/postgis` no publica arm64. Se extiende `pgvector/pgvector:pg17` con `postgresql-17-postgis-3`. Extensiones en schema `extensions` (convención Supabase). CI construye la misma imagen en el job de integración.

## D-179 — Capa de datos (2026-10-20)
Nuevo paquete `packages/db` (SQLAlchemy 2 + GeoAlchemy2 + psycopg 3 + Alembic). Vocabularios como `text + CHECK` generados desde los `StrEnum` de `hi_contracts`, no como tipos ENUM de Postgres. Geometrías administrativas en EPSG:4326 y EPSG:25830.

## D-180 — Geografía canónica (2026-10-20)
Fuente estructural: `cm_secciones_censales` (portal de la Comunidad de Madrid, seccionado 2019, EPSG:25830). Municipios, distritos censales y los 131 barrios de Madrid capital se derivan por dissolve. Identificadores canónicos `ES.28.{MUN|DIS|BAR|SEC}.<código INE>`. El seccionado 2025 del INE entra como actualización declarada (DATA-008), no como sustituto.

## D-181 — Scorecard y curación (2026-10-20)
El criterio "ingestion difficulty" del doc 38 se almacena como `ingestion_ease` (5 = más fácil) para que todos los criterios tengan la misma dirección. Los borradores del harvester nunca son P0. La promoción a catálogo curado se hace con ficheros de curación versionados en `data/catalog/curation/`.

## D-182 — Candidatos fuera de git (2026-10-20)
`data/catalog/candidates/*.jsonl` (4–14 MB) se regeneran desde Bronze con `make catalog-harvest` y no se versionan. Sí se versionan manifests Bronze, informe, borradores y catálogo curado.

## D-183 — Idempotencia de pipelines (2026-10-20)
Un pipeline se omite solo si coinciden checksum de entrada y `parser_version` con la última versión válida. Mismo Bronze con código nuevo regenera Silver. Una ingesta que falla la calidad nunca sustituye a la última versión válida.

## D-184 — Integración en P0 (2026-10-20)
Trabajo en la rama `claude/sprint-p0` con CI en cada push. La integración en `main` la decide Mariano mediante PR.

## D-185 — Gosom descartado; POIs abiertos como alternativa (2026-10-20)
Mariano confirma el criterio: no usar nada que pueda dar problemas. Google Maps/Gosom queda REJECTED también como investigación dentro del repo. Se registran `overture_places` y `fsq_os_places` (licencias permisivas por registro) para cubrir negocios y servicios. Valoraciones y reseñas quedan fuera de alcance.

## D-186 — Protección de personas vulnerables en equipamientos (2026-10-22)
Del registro de centros de atención social solo se mapean servicios para mayores (residencias, centros de día y hogares/clubes). Pisos tutelados, viviendas comunitarias, albergues, centros de acogida de menores, centros para mujeres maltratadas y residencias para personas con enfermedad mental o discapacidad no entran en el producto aunque la fuente publique su ubicación. Del registro sanitario se excluyen las consultas privadas individuales (minimización). Nunca se guardan teléfonos, correos ni NIF. Reglas en `data/catalog/pipelines/*.yaml` y tests en `tests/data/test_catalog.py`.

## D-187 — Modelo de observaciones y pipelines declarativos (2026-10-22)
Las estadísticas oficiales se guardan como `metric_observation` (valor XOR motivo del vacío, dimensiones canónicas, territorio, periodo, versión de dataset). Cada dataset declara su pipeline en `data/catalog/pipelines/<dataset_id>.yaml` (`cm_stat_table`, `cm_postcode_concept`, `points_csv`); el código implementa cada tipo una vez sobre un orquestador común. Los equipamientos se guardan en `place_master` + `place_source_alias` con id canónico estable (uuid5).

## D-188 — Sincronización con Supabase (2026-10-22)
El entorno remoto se carga copiando tablas validadas desde la base local (`make supabase-sync PROFILE=demo|full`), no re-ejecutando pipelines. Perfil demo 77 MB y completo 276 MB, simulados con un rol sin superusuario. Pendiente solo la contraseña de la base de datos.

## D-189 — Features (2026-10-22)
Las features se calculan con métodos genéricos (`metric_value`, `metric_share`, `metric_weighted_mean`, `places_per_population`, `place_attribute_per_population`) parametrizados en su YAML. Ratios con denominador por debajo del umbral declarado se publican con confidence 0,5. Nacionalidad y sexo no pueden ser features (test que lo impide); se descartó `poblacion_extranjera_pct`.

## D-190 — search_path explícito (2026-10-22)
Migraciones y motor de la aplicación fijan `search_path TO public, extensions` al conectar; una base recién creada sin esa configuración rompía la migración (detectado al aislar el test de migraciones).

## D-191 — Licencia open source (2026-11-10)
Mariano elige Apache-2.0 para el código (`LICENSE`, texto canónico de apache.org) y CC BY 4.0 para la documentación y los metadatos del catálogo (`docs/LICENSE`). Los datos de terceros mantienen su licencia original por fuente. Cierra LEGAL-001.

## D-192 — Replan comprimido de la fase de competición (2026-11-10)
No hubo commits entre el 22 oct y el 10 nov, así que P2 y Sprint 1 quedaron sin hacer y el roadmap del doc 19 ya no cabe (unos 22 días de trabajo para 13 hasta el freeze del 23 nov). Se prioriza lo que más puntúa (datos CM 25 + impacto 25):
- 11–16 nov: PUBLIC core (CRTM GTFS, features por sección/H3, ScenarioState, affordability, Residential Fit baseline, mapa con chips/filtros, explicación y procedencia).
- 17–20 nov: Housing Gap municipal + API/MCP con 3–5 tools + demo desplegada.
- 21–22 nov: cut review. 23 nov: freeze. 24–25 nov: slides §8 y ensayos. 26 nov: entrega antes de las 14:00.
Quedan en CUT/LATER: PRO workspace, parcel analysis, ML/embeddings, timeline, 3D polish y HomeFit por URL. Si el PUBLIC core no está en verde el 16 nov, el Housing Gap pasa a YELLOW.
Hechos del mismo día: tag `pre-datamad` en `08cc526` (último commit anterior al 7 nov) y merge de PR #2 y #3 en `main`; el trabajo de competición sigue en `claude/sprint-1-public`.

## D-193 — Formulario de presentación antes del 20 nov (2026-11-10)
La organización comunicó el 9 nov (correo de madrid.datamad@urjc.es, recibido en la cuenta de inscripción de Mariano) que es imprescindible enviar el formulario de presentación antes del 20 nov para seguir en la selección: hasta 50 preseleccionados y 12 finalistas que presentan el 26 nov. Ajuste sobre D-192:
- Despliegue de la demo (OPS-001) adelantado al 17 nov.
- Repo público y formulario el 18 nov, con el 19 nov como límite real.
- El Housing Gap y las tools MCP pasan al 19–22 nov, sobre la demo ya publicada.
El formulario lo envía Mariano; Claude prepara el resumen y los enlaces.

## D-194 — Alcance de la demo: lista de lo que falta por zona (2026-11-10)
Mariano confirma el enfoque de su documento «Housing Intelligence — la idea» (31 oct):
- El diferenciador es la lista FALTA / JUSTO / CUBIERTO por zona, no el Housing Gap como recomendador de producto residencial.
- La vivienda entra como una fila más de la lista (tamaño de los hogares frente a superficie de las viviendas). El resto de filas: escuela infantil, colegio, centro de salud, mayores y farmacia.
- La clasificación se hace frente a la referencia regional, con confidence y con los proxies declarados.
- Empresas («qué abrir») queda solo en slides y API/MCP.
- Zonas verdes quedan fuera porque solo hay datos de Madrid capital.
- La necesidad declarada por usuarios se presenta como siguiente paso y nunca se simula.
Plan: `09_datamad/25_plan_competicion.md`.

## D-195 — Repo público (2026-11-10)
Mariano aprueba hacer público el repo en cuanto haya algo enseñable, como tarde el 18 nov (formulario). Antes se cumple el checklist del §7 del plan de competición. Ya están en verde secretos (gitleaks), tokens y licencias. Falta que Mariano acepte que el email de autor de los commits y `docs/` (estrategia) quedarán visibles; el historial no se reescribe.

## D-196 — Transporte nivel A: paradas y frecuencias desde los GTFS del CRTM (2026-11-10)
DATA-007. Los 6 GTFS del CRTM (metro, metro ligero, cercanías, EMT, autobuses urbanos e interurbanos) también están publicados en el Portal de Datos Abiertos de la Comunidad de Madrid, así que cuentan como datasets CM. Cada dataset lo enlaza con un recurso `role: cm_portal`.
- Cada parada, o estación cuando el feed declara `parent_station`, se guarda en `place_master` con `category=transport` y `subcategory=<modo>`. El servicio va en `attributes`: salidas al día, salidas por hora en punta, headway en punta de la línea más frecuente, primer y último servicio, líneas y accesibilidad declarada.
- El servicio se mide en un día de referencia: el martes mediano (por número de viajes activos) dentro de la vigencia del propio feed. El resultado depende solo del fichero, no del día en que se ejecuta. El GTFS de metro venció el 27-05-2026 y sigue siendo el último publicado; se usa y la calidad lo avisa (`feed_current`).
- La punta es de 07:00 a 09:00. La última parada de un viaje y las paradas sin subida no cuentan como salidas. Las salidas antes de las 04:00 se leen como servicio de la noche anterior. El headway es por línea y sentido; en cercanías, que no declara `direction_id`, es por línea con ambos sentidos (`headway_basis`).
- Las paradas sin servicio el día de referencia no se publican y se cuentan en la calidad: nunca se guardan como 0.
- `stop_times` solo vive en Bronze/Silver; la base de datos guarda unas 15.000 paradas agregadas.
- Particularidades de los feeds, declaradas y no ocultas: el `frequencies.txt` de EMT solo anota viajes que ya están listados uno a uno (`expand_frequencies: false`). En metro, 25 andenes de transbordo no declaran estación: se unen a la estación que está en el mismo punto y tiene el mismo nombre.
- El tiempo a polos de empleo (nivel B) queda en CORE-009.

## D-197 — RLS en todas las tablas públicas, sin políticas (2026-11-11)
OPS-001. Supabase expone el schema `public` a los roles `anon` y `authenticated` a través de su Data API. Su advisor marcó las 14 tablas como críticas (`rls_disabled_in_public`): con la clave pública se podían leer **y modificar** filas.
- El producto no usa esa API: el frontend nunca accede a la base de datos y el backend se conecta como dueño de las tablas.
- La migración 0003 activa RLS en las 14 tablas sin crear ninguna política. Así la Data API no ve filas ni puede escribir. En Supabase, `postgres` tiene BYPASSRLS, y en local el dueño se salta RLS, así que la API, los pipelines y `make supabase-sync` siguen igual.
- Un test de migraciones falla si una tabla nueva de `public` no tiene RLS.
- Comprobado el 11 nov con datos cargados: la Data API devuelve `[]` con la clave publishable. El advisor solo deja el aviso informativo `rls_enabled_no_policy`, que es el estado buscado.
- Si un día se quiere exponer algo por la Data API, se hace con políticas explícitas de solo lectura y por tabla.

## D-198 — Repo público con el historial limpio (2026-11-11)
DATAMAD-PUBLIC-01; completa D-195. Mariano acepta que se vean el email de autor y `docs/`. Antes de publicar apareció un problema: los fixtures de equipamientos del 22 oct llevaban teléfonos, emails de contacto, NIF y titulares, copiados del portal CM. La licencia CC BY no cubre la protección de datos (bases §6.6 y §16).
- El repo original pasa a llamarse `housing-intelligence-archive`, privado y archivado, como prueba de fechas.
- En la misma URL se publica una copia cuyo historial reescrito solo cambia esos 3 ficheros. Se conservan las fechas y el tag `pre-datamad`, que ahora apunta a `cf39459`.
- `scripts/build_places_fixtures.py` redacta los datos de contacto, los NIF y los titulares.
- Evidencia y tabla de SHAs antiguos y nuevos: `evidence/gate-00/2026-11-11/`.

## D-199 — Nombre del producto: «Vida Fácil» (2026-11-11)
Mariano decide llamar al producto **«Vida Fácil»**, con el lema «Encuentra tu sitio en Madrid»: corto, en español y fácil de recordar para personas mayores. El repo sigue siendo `housing-intelligence`, y «Housing Intelligence» puede aparecer como plataforma o equipo en el pie.
- Nombres descartados:
  - «Madrid 360»: es la marca del Ayuntamiento y parecería un producto municipal.
  - «Madrid Mejor»: suena a eslogan político.
  - «Fix360»: está en inglés.
- La línea D comprobó el 11 nov en TMview y en búsqueda web que no choca con ninguna marca del sector vivienda.

## D-200 — Escala: municipios y distritos de Madrid capital (2026-11-11)
La región se muestra por municipios (179) y Madrid capital por sus 21 distritos, para que no sea un único bloque de 3,3 M habitantes. El buscador y la lista de lo que falta funcionan en los dos niveles. La geometría y los nombres de los 21 distritos ya están en `geo_admin_unit` (nivel `distrito`, códigos 2807901–2807921). La población por edad y los hogares por distrito llegan con DATA-012, que va antes de GAP-001.

## D-201 — Mapa y estilo (2026-11-11)
- **Mapa:** 2D en la vista general. Al entrar en una zona, la cámara se inclina y muestra en 3D edificios, parques y puntos clave.
- **Estilo:** modo claro, navy + violeta + tarjetas de cristal, según el brief `DISENO_VIDA_FACIL.md` y sus dos mockups. Las slides siguen este estilo, no el del PDF del 31 oct.

## D-202 — Encaje en % con hechos tangibles (2026-11-11)
El buscador da un **% de encaje** y, debajo, 3–5 hechos tangibles con su nivel de confianza (por ejemplo, «colegio a 6 min andando»). Nunca notas sobre 100 ni barras. Los hechos siempre se pueden trazar a un indicador y a sus datasets.

## D-203 — Presupuesto de alquiler o de compra (2026-11-11)
El presupuesto puede ser de alquiler (€/mes) o de compra (€). La compra va con confianza baja y con la cobertura declarada. Si no hay una fuente oficial abierta y fiable (DATA-021), la compra queda como SIN DATOS y la web lo explica.

## D-204 — Prioridades del buscador (2026-11-11)
«Me importa»: transporte, salud, colegios, zonas verdes, seguridad y «sin escaleras». «Sin escaleras» es una necesidad funcional opcional, nunca una etiqueta de discapacidad (CLAUDE.md §13). La seguridad solo cuenta si la persona la marca como prioridad.

## D-205 — Extras: zonas verdes, accesibilidad física y seguridad (2026-11-11)
- **Fuentes:** el Ayuntamiento de Madrid y OpenStreetMap (ODbL, con atribución). Son datos complementarios: no cuentan como datos CM, pero suman impacto. Sin fotos de zona.
- **Seguridad (DATA-020):**
  - solo datos oficiales agregados (actuaciones de la Policía Municipal por distrito, por cada 1.000 habitantes);
  - nunca nacionalidad ni otras características de personas, por lo que los datos de «delitos» del portal CM quedan descartados;
  - nunca etiquetas como «peligroso»;
  - fuera de Madrid capital, SIN DATOS salvo una fuente oficial equivalente.
- **Accesibilidad física (DATA-019):** instalaciones accesibles del Ayuntamiento y `wheelchair_boarding` del GTFS de metro y cercanías; el resto, SIN DATOS.
- **Zonas verdes (DATA-018):** inventario del Ayuntamiento en Madrid capital y parques de OSM en el resto.

## D-206 — Orden: núcleo antes que extras (2026-11-11)
Para el formulario del 18 nov va primero el núcleo: el buscador, la lista de lo que falta y el 3D de zona. Los extras (D-205) y el precio de compra (DATA-021) entran del 19 al 22 nov, salvo que la línea A vaya adelantada. El trabajo se reparte en cuatro líneas paralelas según `prompts/LINEAS.md`: A (datos, motor, API e integración), B (web), C (despliegue) y D (formulario y pitch).

## D-207 — Contratos PUBLIC v2 (2026-11-11)
Aplica D-200 a D-204 en `packages/contracts/src/hi_contracts/public/`. La v1 (`7541527`) no llegó a usarse.
- **`ScenarioState` v2:**
  - `budget` con tipo alquiler o compra;
  - hogar con adultos, menores y mayores a cargo;
  - las 6 prioridades;
  - `zone_level` desaparece, porque el buscador siempre usa municipios + distritos de Madrid.
- **`SearchResult` v2:**
  - `match_pct` y `facts` (con `topic` para el icono y `confidence`);
  - `gap_highlights` (3 filas de «Qué falta aquí»);
  - `all_zones` para la coropleta;
  - `relaxed_scenario` en cada opción del Reality Check, para aplicarla con un toque.
- **Rutas:**
  - `GET /api/v1/gaps/{level}/{code}` acepta `distrito`;
  - nueva `GET /api/v1/datasets?cm_only=` para el contador y la procedencia;
  - CORS con `POST`.

## D-208 — Rol de solo lectura para la API pública (2026-11-11)
OPS-001; amplía D-197. La API de la demo se conecta a Supabase como `vf_api_ro` (migración 0005, a partir del SQL de la línea C en `infra/deploy/sql/api_readonly_role.sql`).
- **Permisos del rol:**
  - solo lectura por defecto (`default_transaction_read_only`) y por privilegios: solo tiene `SELECT`;
  - sin superusuario, sin `BYPASSRLS` y sin contraseña en el repo. Mariano la pone a mano (`ALTER ROLE vf_api_ro PASSWORD …`) y solo la usa en la `DATABASE_URL` del alojamiento.
- **Políticas:**
  - cada tabla que lee la API tiene una política `vf_api_ro_read` (`FOR SELECT`, solo para ese rol): `dataset_registry`, `dataset_version`, `feature_registry`, `feature_value`, `geo_admin_unit`, `place_master` y `source_registry`;
  - `anon` y `authenticated` siguen sin ninguna política, así que la Data API de Supabase sigue cerrada;
  - el advisor ya no avisará `rls_enabled_no_policy` en esas 7 tablas, y no es un problema.
- **Tests que lo vigilan:**
  - un test unitario falla si la API empieza a leer una tabla que no esté en `API_TABLES`, porque esa tabla se vería vacía en producción;
  - un test de integración comprueba que el rol lee esas tablas, no ve las demás y no puede escribir.
- **Downgrade:** quita permisos y políticas, pero conserva el rol, porque los roles son de todo el servidor.

## D-209 — Población por distrito de Madrid desde el padrón municipal (2026-11-11)
DATA-012; aplica D-200. La CM no publica la población por distrito de Madrid: `cm_distritos_madrid` solo trae superficie y densidad, y sus «Zonas Estadísticas» no son distritos.
- **Fuente:** padrón municipal del Ayuntamiento (`ayto_padron_municipal`, datos.madrid.es, CC BY 4.0). Trae una fila por sección censal y edad, con 4 recuentos (españoles y extranjeros, hombres y mujeres). Se usa el último mes publicado; la carga del 11 nov es del 1 oct 2026.
- **Qué se guarda:** la métrica `poblacion_padron` por distrito, con las **mismas bandas quinquenales que `poblacion_censada` de la CM** más el total. Así, los filtros de edad de las features valen para los dos niveles sin traducción.
  - El padrón es un registro exhaustivo: una edad sin filas en un distrito es 0 personas, y se publica como 0. Una fila que no se puede leer va a cuarentena y nunca cuenta como 0.
  - Solo se guarda la suma de los 4 recuentos. La nacionalidad y el sexo nunca se guardan (D-189, D-205).
- **Comparabilidad:** el total de Madrid en el padrón es un 1,68 % mayor que el del censo anual de la CM (3.535.868 frente a 3.477.497 a 1 ene 2025), por fecha y por método. No se calibra: se publica tal cual y se declara en las features. La calidad compara los dos totales en cada carga y avisa si la diferencia pasa del 5 %, sin bloquear.
- **Calidad bloqueante:** los 21 distritos tienen que estar y resolver en `geo_admin_unit`. Un fichero incompleto no sustituye a la última versión válida.
- **Procedencia:** es un dato complementario, no CM (`is_cm_open_data=false`), y la procedencia de cada fila lo muestra. El test del catálogo que exige que las estadísticas vengan de la CM admite esta excepción explícita y ninguna más.
- **Hogares por distrito** (DATA-012 Fase 3): salen del panel de indicadores de distritos y barrios del Ayuntamiento (`ayto_panel_indicadores_distritos_barrios`, CC BY 4.0, complementario y no CM).
  - Se guardan el total de hogares y el tamaño medio del hogar que publica el Ayuntamiento, a 1 de enero de cada año del panel (2019–2025).
  - Son hogares del padrón (personas inscritas en una misma vivienda), no el hogar del censo 2021 de la CM.
  - En los distritos, `tamano_medio_hogar` toma la media publicada, sin recalcularla. En los municipios sigue la del censo.
  - La fila de vivienda de GAP-001 queda SIN DATOS por distrito mientras no haya superficie de las viviendas por distrito.

## D-210 — Distancia a pie: velocidad, ventanas, destinos y calles de origen (2026-11-11)
CORE-005, Fases 3 y 4. Doce features por sección censal, municipio y distrito, más la referencia regional. Son 6 destinos con dos medidas cada uno:
- la mediana de minutos hasta el más cercano;
- el % de calle a N minutos o menos.

Datos: la red peatonal de OSM (`osm_red_peatonal`, ODbL, complementaria) y los registros de la CM para los destinos.
- **Velocidad: 4,5 km/h (1,25 m/s) para todo el mundo.** Sustituida por D-211: 4 km/h.
  - La guía de la FHWA de EE. UU. recomienda 1,2 m/s para la mayoría de los casos y 1,0 m/s donde más del 20 % son mayores de 65 (https://www.fhwa.dot.gov/publications/research/safety/pedbike/98107/section2.cfm).
  - El estudio «El Madrid de los 15 minutos» del Ayuntamiento usa 4 km/h (https://geoportal.madrid.es/fsdescargas/IDEAM_WBGEOPORTAL/GEOPORTAL/Jornada/2022/SALA5_1130_PROXIMIDAD_POR_CALCULODEREDES.pdf).
  - 4,5 km/h es un paso adulto tranquilo y la parte alta para personas mayores, y se declara en cada feature. A 4 km/h los minutos salen un 12,5 % más altos y a 3,6 km/h, un 25 % más.
  - Una velocidad para movilidad reducida entra con la accesibilidad física, opcional (D-205, del 19 al 22 nov), sin cambiar este cálculo.
- **Ventanas del %:** transporte 5 min (unos 375 m), centro de salud 15 min y el resto 10 min.
- **Destinos** (por subcategoría del registro, en el YAML de cada feature):
  - escuela infantil: pública y privada, de 0 a 3 años;
  - colegio con primaria: público o concertado;
  - centro de salud o consultorio de atención primaria;
  - farmacia;
  - centro de mayores: hogares, clubes y centros de día (las residencias no son destino a pie);
  - cualquier parada de autobús, metro, metro ligero o cercanías, sin mirar la frecuencia, que llega con CORE-009.
- **Origen: las calles donde vive la gente,** aproximadas por el tipo de vía de OSM: residencial, de convivencia, sin clasificar, peatonal y terciaria.
  - Cada nodo pesa la mitad de la longitud de sus tramos y cae en la sección censal que lo contiene. El municipio y el distrito salen del código de la sección.
  - Es un proxy de dónde vive la gente, no la población. Pesa más donde hay más calle, como las urbanizaciones de baja densidad, y por eso la mediana regional (por ejemplo, 3,4 min a una parada) es más alta que la de la sección típica (2,1 min).
- **Cálculo:**
  - Un Dijkstra multiorigen por tipo de destino sobre la componente principal de la red. Cada destino se une a ella por su nodo más cercano, en línea recta.
  - Por zona se calculan la mediana de minutos ponderada por la longitud de calle y el % de esa calle a N minutos o menos. Las dos medidas son coherentes por construcción: la mediana está dentro de la ventana si y solo si lo está la mitad de la calle o más.
- **Sin datos y desconocido, nunca 0:**
  - una zona sin calles de origen en OSM es `SOURCE_NO_COVERAGE`. Pasa en 24 secciones urbanas pequeñas (0,01–0,13 km²), 15 de ellas en Moratalaz y Villa de Vallecas. Ahí las viviendas dan seguramente a vías que OSM no marca como calle de origen (peatonales o de servicio). Una mejora posible: usar en esas secciones cualquier vía transitable como origen, declarándolo;
  - una zona cuyas calles no llegan a ningún destino es `UNKNOWN`.
- **Confianza:** la parte de la calle de la zona que conecta con la red. Si la zona tiene menos de 300 m de calle de origen, 0,5 como máximo.
- **Niveles:** el H3 r9 queda para cuando lo pida la vista 3D de la zona (CORE-005b). Serían unas 300.000 filas más en `feature_value`, que se copia entera a Supabase.
- **Comprobación (Gate 3):**
  - 15 casos golden con límites razonados, por ejemplo: Sol tiene farmacia a 5 min o menos, y La Acebeda no tiene ninguna farmacia en el registro (97,5 min a la más cercana) pero sí consultorio (12,7 min);
  - la coherencia entre mediana y % en las 4.819 zonas con valor de cada destino;
  - la cobertura de las 4.843 zonas.
  - El cálculo completo de las 24 features tarda 29 s y ocupa 0,9 GB de memoria.

## D-211 — Distancia a pie a 4 km/h (2026-11-11)
CORE-005, Fase 5. Sustituye la velocidad de D-210; el resto de D-210 (ventanas, destinos, calles de origen, cálculo, nulos y confianza) no cambia.
- **Velocidad: 4 km/h (1,11 m/s) para todo el mundo**, en lugar de 4,5 km/h. Decisión de Mariano: la demo también se dirige a personas mayores.
  - Fuente: el estudio «El Madrid de los 15 minutos» del Ayuntamiento («Velocidad de desplazamiento estimada en 4 Km/h»), https://geoportal.madrid.es/fsdescargas/IDEAM_WBGEOPORTAL/GEOPORTAL/Jornada/2022/SALA5_1130_PROXIMIDAD_POR_CALCULODEREDES.pdf. Así las cifras se pueden comparar con las del Ayuntamiento.
  - Referencia: 1,11 m/s queda entre los 1,2 m/s que la FHWA de EE. UU. recomienda para la mayoría de los casos y los 1,0 m/s que recomienda donde más del 20 % son mayores de 65 (https://www.fhwa.dot.gov/publications/research/safety/pedbike/98107/section2.cfm). No se afirma que sea la velocidad de las personas mayores: con movilidad reducida los minutos son más, y la feature lo declara.
- **Efecto:** los minutos suben un 12,5 % (×1,125) y las ventanas del % cubren menos calle: 5 min son unos 333 m (antes 375), 10 min unos 667 m y 15 min unos 1.000 m.
- **Versión:** las 12 features a pie pasan a la versión 2 (`feature_version` en cada fila).
- **Comprobación (Gate 3), con el recálculo real:**
  - los 15 casos golden de D-210 cumplen sus límites sin tocarlos. Los más justos: Sol a una parada, 3,1 min (límite 4), y el centro de Madrid a un centro de salud, 6,9 min (límite 10). La Acebeda: farmacia a 109,7 min y consultorio a 14,3 min (límite 20);
  - la coherencia entre mediana y % sigue sin desacuerdos en las 4.819 zonas con valor de cada destino;
  - por ejemplo, Chamartín (distrito 2807905): centro de salud 9,5 min (antes 8,4) y farmacia 2,6 min (antes 2,3). La mediana regional a una parada pasa de 3,4 a 3,8 min y la de la sección típica, de 2,1 a 2,4 min.

## D-212 — Nombres oficiales de municipios y distritos (2026-11-11)
DATA-022 y los nombres con la Ñ rota que pidió B. El CSV de nombres de `cm_secciones_censales` escribe «/» o el byte 0xD0 donde va la Ñ («REDUE/A», «GRIÐON», «PI/UECAR-GANDULLAS») y no lleva tildes («VICALVARO»). No es un problema de encoding: el carácter se perdió en la fuente.
- **Fuente de los nombres publicados:**
  - los 179 municipios, de la tabla estadística de la CM `cm_poblacion_edad_nacionalidad_sexo` (columna `Territorio`, última versión válida): «Griñón», «Redueña», «Álamo (El)»;
  - los 21 distritos de Madrid, del panel de indicadores del Ayuntamiento (`ayto_panel_indicadores_distritos_barrios`): «Vicálvaro». La CM no publica tablas por distrito de Madrid (D-209);
  - los distritos censales del resto de municipios se llaman «<municipio> — distrito censal NN», con el nombre oficial del municipio;
  - los barrios de Madrid siguen con el nombre de `cm_barrios_madrid`, que ya trae la Ñ (a algunos les faltan tildes, como «Las Aguilas»; queda anotado).
- **Cómo:** un paso aparte, `hi-ingest admin-names` (`make admin-names`, y al final de `run-all`), porque la geografía se publica antes que las tablas que traen los nombres. Solo cambia `geo_admin_unit.name`: la geometría y los códigos no se tocan. La ejecución queda en `ingestion_run` con las versiones usadas, y la evidencia guarda cada cambio.
- **Calidad bloqueante:** cada municipio y cada distrito de Madrid tiene un nombre oficial y solo uno, y ningún nombre publicado lleva caracteres fuera de la ortografía española (falla con «/», «Ð» o un byte sin decodificar). Si falla, no se cambia ningún nombre.
- **Presentación:** `display_name` pone delante el artículo que las tablas de la CM escriben detrás: «Álamo (El)» se muestra «El Álamo». La API lo aplica en `/gaps`, `/geo/admin-units` y `/features`.

## D-213 — Lista de lo que falta: referencia por tipo de territorio y cortes con prueba estadística (2026-11-11)
GAP-001, Fase 5. Sustituye los cortes provisionales de `gap-0.1` (ratio frente a la región: FALTA < 0,8 ≤ JUSTO < 1,0 ≤ CUBIERTO). Método `gap-0.2`, en `hi_domain/gaps.py` y `hi_api/services/gap_reference.py`; la API lo publica en `method`. **Aprobada por Mariano el 11 nov** (a través de `datamad-10`): referencia por tipo de municipio, FALTA solo si la diferencia es clara y no se explica por el tamaño, y «poco fiable» en zonas pequeñas. Refina la decisión cerrada «frente a la referencia regional por población»: sigue siendo una tasa de la región por población, pero de las zonas comparables.

**Problemas de `gap-0.1`, medidos con los datos reales del 11 nov:**
- La tasa de casi todas las filas depende del tipo de territorio. Ejemplo: cada pueblo tiene su consultorio, así que los municipios rurales tienen 14,8 veces más centros de atención primaria por habitante que los urbanos. La media regional (0,59 por 10.000) quedaba por encima de cualquier zona urbana: los 21 distritos de Madrid salían FALTA o JUSTO y ninguno CUBIERTO.
- Una zona pequeña salía FALTA por no tener un servicio que, por su tamaño, ni siquiera se espera que tenga. Ejemplo: un pueblo de 500 habitantes sin farmacia, cuando la región tiene 4,2 por cada 10.000.
- Una zona pequeña podía dar cifras extremas. B señaló La Acebeda, con 10.700 viviendas grandes por cada 100 hogares grandes. Faltaba una regla común para los denominadores pequeños.

**Decisión** (igual para las 6 filas, sin ajustar a ninguna zona concreta):
1. **Referencia: los demás municipios del mismo tipo de la Comunidad de Madrid.**
   - **Tipo:** la definición legal de medio rural de la Ley 45/2007, de desarrollo sostenible del medio rural (art. 3.a): menos de 30.000 habitantes y menos de 100 habitantes por km². Con la población del censo de la CM y la superficie de la geografía canónica salen 84 municipios rurales (143.000 habitantes) y 95 urbanos.
   - **Herencia:** un distrito o una sección toma el tipo de su municipio. Los distritos de Madrid son urbanos.
   - **Cálculo:** la tasa de referencia es la suma de los recuentos de los municipios del tipo dividida por la suma de sus poblaciones, **sin el municipio de la propia zona**. Un distrito o una sección dejan fuera su municipio entero. Madrid es la mitad de la población urbana y no puede compararse consigo mismo. Equivale a la estandarización indirecta: los casos esperados de una zona son su población por esa tasa.
   - **Contexto:** la región entera sigue apareciendo en `regional_reference` y en la explicación («… en los demás municipios urbanos de la Comunidad de Madrid, 0,56 (en toda la Comunidad, 0,59)»).
   - **Procedencia:** las filas citan también la población del censo y la geografía, que fijan el tipo.
   - **Justificación:** una prueba de homogeneidad (χ², 1 gl) de la tasa entre rural y urbano, fila por fila. Todas las filas la rechazan al 5 %:

     | Fila | Tasa rural / urbana | χ² | p |
     |---|---|---|---|
     | Escuela infantil | 2,70 | 64,9 | 8·10⁻¹⁶ |
     | Colegio | 1,81 | 16,0 | 6·10⁻⁵ |
     | Centro de salud | 14,82 | 968,8 | 10⁻²¹² |
     | Mayores | 2,86 | 33,2 | 8·10⁻⁹ |
     | Farmacia | 1,27 | 4,3 | 0,039 |
     | Vivienda | 2,52 | 49.523 | < 10⁻³⁰⁰ |

2. **Cortes:**
   - **CUBIERTO:** ratio ≥ 1, es decir, igual o por encima de la referencia.
   - **FALTA:** la falta tiene que ser grande y no deberse al azar del tamaño de la zona. Hacen falta dos condiciones:
     - **material:** ratio < 0,8. Es la regla de los cuatro quintos, que se usa para decidir cuándo una tasa es sustancialmente menor que la de referencia (29 CFR 1607.4(D)). El corte no cambia respecto a `gap-0.1`;
     - **significativa:** el límite superior del intervalo de confianza exacto de Poisson de la zona (Garwood, bilateral al 95 %; equivale a una prueba unilateral al 2,5 %) queda por debajo de los casos esperados. Es el criterio de «peor que la referencia» de los indicadores de salud pública inglesa (Fingertips) y de los gráficos en embudo (Spiegelhalter, 2005).
   - **JUSTO:** el resto de valores conocidos. **SIN DATOS** sigue siendo solo un valor desconocido.
3. **Zonas demasiado pequeñas (respuesta a B):**
   - **Regla:** una zona es «poco fiable» en una fila (`reliable: false`) cuando sus casos esperados son menos de 3,69. Es el límite superior al 95 % de un recuento de cero: por debajo, ni siquiera no tener ninguno sería una falta significativa.
   - El umbral sale de la propia prueba, no de un tope arbitrario, y es el mismo en todas las filas.
   - Una zona poco fiable nunca sale FALTA y conserva su valor. La API la marca; **la web aún no la muestra** (pendiente de B: «poco fiable»).
   - `reliable` es `true` también cuando la prueba no se aplica (fila sin recuentos o de «menos es mejor»).
   - **La Acebeda en vivienda:** espera 4,3 viviendas grandes y tiene unas 107 por cada hogar grande. El dato es fiable y sale CUBIERTO. La cifra de 10.700 es real: la produce un denominador de un hogar. Mejor mostrarla como «más de 10 veces la referencia».
   - La confidence de los features (umbrales de población pequeña) no cambia: mide la calidad del dato, no la prueba.
4. **Recuentos:** las features por población guardan en `inputs.counts` el numerador y el denominador de cada fila (`places_per_population`, `metric_ratio` y `place_attribute_per_population`; la clasificación solo usa los de las filas principales). Los valores no cambian, así que la versión de las features tampoco, pero los recuentos solo existen tras recalcular las features (`make features`) y sincronizar Supabase.
   - **Comparación con la región entera:** si la región no tiene recuentos o el tipo se queda sin casos. Entonces la comparación es con la región entera y decide solo el ratio. Una zona concreta sin recuentos se compara con su tipo, también solo por el ratio.
5. **Límites declarados:**
   - **Modelo de Poisson:** encaja con recuentos de centros sobre una población.
   - **Vivienda** (viviendas grandes sobre hogares grandes) es un cociente de dos recuentos grandes. La prueba casi siempre sale significativa, así que en esa fila decide en la práctica el corte de 0,8. No se modela la sobredispersión.
   - Contar centros no es contar plazas (`proxy_note`).
   - El tipo se asigna por municipio y la superficie sale de la geometría de 2019.
   - Los casos esperados de un distrito usan el padrón (D-209) con una tasa calculada con el censo de la CM.
   - En `metric_ratio`, la región suma también el numerador de los municipios con denominador 0, y las sumas por tipo no lo hacen. El efecto es despreciable.

**Efecto con los datos del 11 nov** (`evidence/gate-04/2026-11-11/phase-gap001-f5.txt`):
- **Por municipio (179):** FALTA pasa de 44, 65, 27, 90 y 94 a 0, 0, 5, 2 y 5 (escuela infantil, colegio, centro de salud, mayores y farmacia). Entre 116 y 161 municipios quedan poco fiables en esas filas. En vivienda, con recuentos grandes, FALTA sube de 8 a 25.
- **Por distrito de Madrid (21):** centro de salud pasa de 18 FALTA y 3 JUSTO a 21 JUSTO; ningún distrito por sí solo tiene una falta significativa. Escuela infantil: 4 FALTA (antes 8). Colegio: 1 FALTA (antes 4).
- **Casos de la demo:**
  - Chamartín (2807905), centro de salud: antes FALTA (0,79 frente a la región); ahora JUSTO (0,47 frente a 0,56 de los demás municipios urbanos, ratio 0,84);
  - Madrid capital: centro de salud FALTA (0,37 frente a 0,56, ratio 0,67, significativa) y colegio JUSTO (0,96);
  - La Acebeda: farmacia JUSTO y poco fiable (0 farmacias para 70 habitantes).
- **Lectura para el pitch:** FALTA pasa a ser una afirmación fuerte y rara: menos del 80 % de lo que tienen las zonas comparables, con datos suficientes para afirmarlo. Por ejemplo, Madrid capital tiene un tercio menos de centros de atención primaria por habitante que el resto de municipios urbanos, aunque ningún distrito por sí solo baste para afirmarlo.

## D-214 — Asequibilidad: m² supuestos por tamaño del hogar, alquiler por distrito y compra sin datos (2026-11-11)
CORE-006. Código en `hi_domain/affordability.py` y en el método `postcode_weighted_mean` de `hi_features`. Responde a la línea D, que pidió qué m² se suponen según el tamaño del hogar. Es una decisión reversible: cambiar la tabla no toca ningún contrato.

1. **Coste estimado.** El alquiler de una zona es su alquiler medio por m² (feature `alquiler_m2_mensual`) multiplicado por los m² que necesita el hogar. La condición de presupuesto es:
   - **PASS** si ese coste es igual o menor que el presupuesto;
   - **FAIL** si lo supera;
   - **UNKNOWN** si la zona no tiene alquiler publicado. Nunca cuenta como PASS.
2. **m² supuestos por tamaño del hogar.** Si la persona no los fija (`min_floor_area_m2`), se toman los de la vivienda mediana de los hogares de su tamaño en la Comunidad de Madrid:
   - **Fuente:** Censo de Población y Viviendas 2021 del INE, tabla 59524 («Viviendas familiares principales convencionales según tamaño del hogar por superficie»), fila de la Comunidad de Madrid. Son 2.532.510 hogares con superficie conocida.
   - **Cálculo:** mediana interpolada dentro de los tramos de superficie del INE. Las personas del hogar son adultos, menores y mayores a cargo.

     | Personas | 1 | 2 | 3 | 4 | 5 o más |
     |---|---|---|---|---|---|
     | m² supuestos | 61 | 68 | 71 | 77 | 77 |

   - **Por qué la mediana del censo:** es lo que ocupa de verdad la mitad de los hogares de ese tamaño en la región, con una fuente oficial. Una norma de habitabilidad daría mínimos legales, no lo habitual. Con 5 o más personas sale 76,7 m², casi lo mismo que con 4: las familias grandes no viven en pisos mucho mayores. Se fija en 77 para que los m² nunca bajen al crecer el hogar (lo comprueba un test).
3. **Límites declarados (el coste es orientativo y tiende a quedarse corto):**
   - **Contratos vigentes:** el alquiler por m² de la CM sale de la Estadística de viviendas declaradas en el IRPF de la Agencia Tributaria. Es la media de los contratos vigentes, no de los anuncios, y un contrato nuevo suele costar más.
   - **m² de distinta base:** los m² de esa estadística son los del Catastro, que solo tiene superficie construida. El INE estima la superficie útil del censo a partir de esa misma superficie construida, con una recta por el origen. Por eso el coste estimado corresponde a un piso algo menor que el mediano. El INE no publica el coeficiente, así que no se corrige.
   - **Qué FAIL es fiable:** como el coste es una cota baja, FAIL es una afirmación fiable. PASS conserva la confidence del dato y la explicación lo dice («media de los contratos vigentes; uno nuevo suele costar más»).
   - **Cobertura:** la fuente municipal solo publica los municipios de más de 20.000 habitantes con contratos suficientes (37 de 179). El resto queda UNKNOWN, nunca 0 ni estimado.
4. **Alquiler por distrito de Madrid** (versión 2 de `alquiler_m2_mensual`). Conecta `cm_alquiler_m2_codigo_postal_madrid`, el dataset CM número 21:
   - **Problema:** la tabla de la CM publica el alquiler por código postal (54 códigos de Madrid capital, 2024), y no hay geometría de códigos postales (DATA-013 está en el backlog).
   - **Proxy:** el alquiler de cada distrito es la media de sus códigos postales, ponderada por cuántos lugares geocodificados del distrito llevan ese código en su dirección: colegios, centros de salud y centros sociales de la CM (2.885 lugares de Madrid). Los lugares aproximan dónde vive la gente; se declara como proxy.
   - **Confidence:** 0,8 como máximo, multiplicada por la parte de ese peso cuyo código tiene alquiler publicado en el último periodo (2024). Los lugares sin código en la dirección no cuentan: la confidence no mide cuántos lugares sostienen la media. En Madrid son entre 51 y 242 por distrito, así que no hace falta un mínimo; si se extiende a otros municipios, habrá que fijarlo.
   - **Restricción:** solo cuentan los lugares del municipio de Madrid, porque la fuente solo publica sus códigos.
   - **Comprobación:** la media de los 21 distritos ponderada por población da 14,46 €/m², frente a los 15,10 publicados para Madrid. La cifra municipal pondera por viviendas alquiladas, que se concentran en el centro.
   - **Ejemplos:** Salamanca 19,8 €/m², Chamartín 18,0, Fuencarral-El Pardo 14,4 y Villaverde 10,8.
   - **Por qué la media y no la mediana ponderada** (como proponía el board): la fuente publica medias, y con 1 a 5 códigos por distrito una mediana saltaría de un código a otro.
5. **Compra** (sustituido por D-227, que usa el valor tasado por municipio). Aún no hay una fuente oficial abierta y fiable de precio de compra por zona: DATA-021 entra del 19 al 22 nov (D-206). Mientras tanto, con `budget.kind = buy` la condición sale UNKNOWN en todas las zonas, con la explicación «Sin datos: aún no hay una fuente oficial abierta y fiable de precios de compra por zona». El buscador no inventa un precio.
   - **Candidatas para DATA-021:**
     - el valor tasado de vivienda libre del Ministerio de Vivienda (municipios de más de 25.000 habitantes);
     - el valor de referencia del Catastro que publica la CM para las viviendas arrendadas (municipios de más de 20.000 habitantes y códigos postales de Madrid).

## D-215 — Encaje residencial: condiciones, % de encaje y Reality Check (2026-11-11)
CORE-003. Método `fit-0.1`, en `hi_domain/fit.py`, `hi_domain/reality_check.py` y `hi_domain/search.py`, sobre los contratos v2 (D-202, D-207). Responde a la línea D, que pidió cómo se reparten los pesos y cómo se pasa a %. Es reversible: cambiar un peso o una curva solo cambia `methodology_version`.

1. **Zonas.** Los 178 municipios distintos de Madrid y los 21 distritos de Madrid capital (D-200): 199 zonas.
2. **Condiciones** (PASS, FAIL o UNKNOWN; UNKNOWN nunca cuenta como PASS):
   - **Presupuesto (`budget`):** según D-214.
   - **Servicio cerca obligatorio (`near:<servicio>`):** la mediana de los minutos a pie de las calles de la zona (CORE-005, 4 km/h) frente al máximo que pide la persona. Sin dato, UNKNOWN.
   - **Trayecto con límite (`commute:<i>`):** UNKNOWN en todas las zonas hasta que exista el tiempo en transporte público (CORE-009). La explicación da la distancia en línea recta. Si la persona pone un límite de minutos, ninguna zona pasa y el Reality Check propone quitarlo. Por eso, mientras tanto, la web debería enviar el trabajo sin límite (`max_minutes: null`), como preferencia.
3. **Criterios del % de encaje.** Van en este orden:
   1. las prioridades «Me importa», en el orden en que las marca la persona;
   2. cada lugar de trabajo o estudio;
   3. los servicios cerca que marca como deseables y que no están ya entre sus prioridades;
   4. el margen de presupuesto, si es de alquiler.
4. **Pesos por rango (rank sum):** con n criterios, el primero pesa n, el segundo n − 1 y el último 1, y se normalizan para sumar 1. Ejemplo con 5 criterios: 33 %, 27 %, 20 %, 13 % y 7 %. Es el método de pesos por orden más fácil de explicar: lo que marcas primero cuenta más.
5. **Utilidad de cada criterio** (de 0 a 1, curvas lineales con saturación, CLAUDE.md §14):
   - **Servicio a pie** (transporte → parada; salud → centro de salud; colegios → colegio con primaria): vale 1 hasta la ventana de D-210 y baja a 0 en el triple de esa ventana.
     - Ventanas: transporte 5 min, centro de salud 15 y los demás 10. Si la persona fija sus minutos, se usan los suyos.
     - Ejemplo: un colegio a 10 min vale 1, a 20 min vale 0,5 y a 30 min o más vale 0.
   - **Trabajo:** distancia en línea recta desde el centro de la zona. Vale 1 hasta 2 km (unos 30 min a pie) y 0 desde 20 km, que es más o menos el radio del municipio de Madrid más la primera corona. Es un proxy declarado, porque la distancia no es tiempo de trayecto, y lleva confidence 0,5. Es un parámetro de diseño: se sustituye por el tiempo real con CORE-009.
   - **Margen de presupuesto:** vale 1 si el coste es el 75 % del presupuesto o menos, y 0 si lo iguala.
   - **Zonas verdes, seguridad y «sin escaleras»:** aún sin datos (D-205, del 19 al 22 nov). Nunca puntúan como 0: salen como hecho «sin datos» y bajan la confidence.
6. **Paso a %:** media ponderada de las utilidades de los criterios con dato, por 100 y redondeada a la unidad (0,5 hacia arriba). El orden usa el valor sin redondear.
   - La confidence de la zona es la suma de peso × confidence de los criterios con dato, sobre el peso total. Así un criterio sin dato la baja.
   - Sin ningún criterio, una zona que cumple todo encaja al 100 %. Con criterios pero ninguno con dato, el % es desconocido (`null`), nunca 0.
7. **Resultado:**
   - **`results`:** las 10 mejores zonas con todas las condiciones en PASS, ordenadas por % de encaje, confidence y nombre.
   - **`near_misses`:** hasta 5 zonas que fallan exactamente una condición y cumplen las demás.
   - **`all_zones`:** las 199 zonas, para la coropleta.
   - **`facts`:** hasta 5 hechos tangibles por zona (3 o más cuando hay datos). Primero los criterios con dato, por orden de importancia para la persona, sean fortaleza o debilidad; si hay menos de 3, se completan con minutos a pie de contexto; los «sin datos» van al final.
   - **`gap_highlights`:** 3 filas de GAP-001 elegidas por el hogar: escuela infantil si hay menores de 3 años, colegio si hay menores, mayores si hay mayores a cargo, y después centro de salud, farmacia y vivienda.
8. **Reality Check:** para cada condición, cuántas zonas pasarían si solo esa se relajara, con las demás fijas:
   - **presupuesto de alquiler:** +10 %, redondeado hacia arriba a 50 €;
   - **presupuesto de compra:** quitarlo;
   - **servicio cerca:** +5 min, hasta 60; a partir de ahí pasa a ser preferencia;
   - **trayecto:** sin límite.

   `binding_constraint` es la condición que no se cumple (FAIL o UNKNOWN) en más zonas, digan lo que digan las demás. Con un límite de trayecto, que siempre es UNKNOWN, esa es la que gana. Relajar nunca quita zonas (test de propiedades).
9. **Caso demo con los datos del 11 nov** (`scripts/golden_search.py`, `evidence/gate-04/2026-11-11/phase-core003-f2.txt`): pareja con 2 hijos (4 y 8 años), 1.500 €/mes, colegio a 10 min como requisito, prioridades colegios, transporte y salud, y trabajo en la Castellana como preferencia.
   - **Recuento:** 32 de las 199 zonas cumplen todo y 15 quedan desconocidas (sin alquiler publicado o sin minutos a pie).
   - **Primera:** Ciudad Lineal, con un 99 %: colegio a 5 min, parada a 2 min, centro de salud a 11 min, a 3,2 km de Azca y unos 1.075 €/mes por 77 m².
   - **Siguientes:** Tetuán, Hortaleza y Moratalaz (97 %). Chamartín sale octava (95 %), porque sus 1.384 €/mes dejan poco margen.
   - **Reality Check:** la condición que más zonas quita es el colegio a 10 min. Con 5 min más aparecen 17 zonas, y con 150 € más, 1.
   - **Casi:** Salamanca, que falla solo por presupuesto (≈ 1.526 €/mes).
10. **Pendiente:**
   - diversificación y soluciones Pareto (§14): hoy el orden es solo por % de encaje;
   - tiempo de trayecto real (CORE-009);
   - ML/JEV.

## D-216 — Auditoría de equipamientos: clasificación, coordenadas y contrato de `/places` (2026-11-12)
Fase de prueba, T1 (decisión de Mariano del 12 nov: antes de los extras, comprobar que lo que enseña la demo es cierto y completo). Informe: `evidence/gate-01/2026-11-12/audit-places.md` (`scripts/audit_places.py`). Reversible: son filtros del catálogo y una categoría nueva.
1. **«Centro Polivalente» no son servicios para mayores.** Son los 1.001 «centros polivalentes» del registro de centros sanitarios (RD 1277/2003, tipo C.2.90): clínicas privadas de varias especialidades (97 % «Privado No Benéfico»; estética, fisioterapia, odontología…), sin nombre en el registro. Ni son atención primaria ni hospitales, y ninguna feature los usaba, pero llenaban la capa de salud (el 65 % de sus puntos). **Salen del registro de lugares**, con la misma regla de minimización que ya dejaba fuera las consultas privadas. Que fueran 1.001, como los servicios para mayores de DATA-009, era una coincidencia.
   - Efecto colateral: el alquiler por distrito (D-214) ponderaba los códigos postales también con esas clínicas, que se concentran en zonas comerciales. Sin ellas, el proxy se acerca más a donde vive la gente. Salamanca pasa de 19,8 a 19,0 €/m² y Chamartín de 18,0 a 17,9; Villaverde y Fuencarral-El Pardo apenas cambian. En el caso demo (D-215), Salamanca ya cabe en 1.500 €/mes y deja de ser «casi».
2. **Las farmacias son una categoría propia (`pharmacy`).** Eran `health` y salían en cualquier capa de salud. Migración 0006 (la comprobación de categorías admite `pharmacy`; al bajar, vuelven a `health`). Las features de farmacia cambian de categoría, no de valor ni de versión.
3. **Coordenadas que faltan o contradicen la dirección** (propuesta de D, revisión de 10 zonas):
   - **Cuándo:** solo en los registros sin coordenadas, fuera de los límites de Madrid o cuyas coordenadas caen en otro municipio que el declarado (o, en Madrid, en otro distrito que el declarado por el registro de centros educativos).
   - **Cómo:** la dirección del propio registro va al geocodificador oficial CartoCiudad (IGN, CC BY 4.0 scne.es), sin código postal (con él no responde). Solo se acepta un **portal** en el municipio declarado: el número exacto (confidence 0,8) o el portal conocido más cercano a 10 números o menos (0,6; unos 50–100 m). Sin número («S/N»), solo calle o en otro municipio → cuarentena.
   - Coordenadas en otro municipio sin dirección válida → cuarentena (nunca se publican en el sitio equivocado). Un distrito distinto es una prueba más débil: solo se mueve si la dirección cae en el distrito declarado; si no, se conserva y se anota.
   - Las respuestas se guardan en caché (`data/bronze/geocoding/`) y cada lugar lleva `attributes.coordinates` con el origen. Fuente registrada como `ign_cartociudad`.
   - **La calle también tiene que coincidir** (palabras del nombre sin artículos ni tildes): CartoCiudad puede devolver un portal de otra calle del mismo municipio (revisión con `reviewer`).
   - **Resultado:** 40 lugares geocodificados (educación 18, sanidad 4, mayores 13, farmacias 5): 36 que no tenían coordenadas y 4 reubicados. Entre ellos el colegio Humanitas El Cañaveral, dos centros de salud de Madrid, el consultorio de Gargantilla, la farmacia 763 (estaba en Valdemoro) y el CEIP Amorós (estaba en Tetuán). El consultorio CS12766 de Buitrago, con coordenadas en otro municipio, pasa a cuarentena: el geocodificador devuelve otra calle. Siguen en cuarentena 40 de educación, 6 de sanidad y 34 de mayores: «S/N», carreteras por kilómetro o direcciones que el geocodificador no encuentra. De los casos de D quedan sin resolver los centros de salud de Alcalá (2) y Madrid (2), con «S/N»; el consultorio de Villar del Olmo («calle Real 42» lleva a un pueblo de Jaén y se rechaza) y el CEIP de Navalafuente (el portal conocido más cercano es el 16 para el 56).
   - El CEIP Nuria Espert queda en Barajas: la dirección no contradice las coordenadas y la cartografía oficial (secciones del INE) lo pone en Barajas, aunque el registro diga Hortaleza.
4. **`/places` pasa a tener contrato** (`places-1`, `PlacesResponse`): titularidad pública, concertada o privada en los centros educativos, `gap_rows` (las filas de la lista de lo que falta que cuentan ese lugar, con los mismos filtros del Feature Dictionary), `capacity` cuando la fuente la publica por centro (hoy, las plazas autorizadas de mayores) y el origen y la confidence de las coordenadas. Lo pidió B para su T3.
5. **Base de población de Madrid (D6 de la revisión de D):** se mantiene lo declarado en D-209: el municipio con el censo de la CM y los distritos con el padrón (+1,7 %). En los cálculos que mezclan distritos y municipios (D-217) los distritos se escalan al total del censo para no contar dos veces esa diferencia.

## D-217 — La oferta se mide por capacidad y accesibilidad (2SFCA) y los municipios pequeños se comparan con sus vecinos (2026-11-12)
Fase de prueba, T2a y T2b. **Decisión de Mariano (12 nov):** la oferta de servicios se mide por capacidad y accesibilidad, no por número de centros. Método `gap-0.3`, que sustituye a `gap-0.2` en las cinco filas de servicios; vivienda no cambia. Código: `hi_domain/access/fca.py`, `hi_features/fca.py` (método `two_step_fca`), `hi_domain/gaps.py` (`pool_with_neighbours`) y `hi_api/services/gap_reference.py`. Evidencias: `evidence/gate-04/2026-11-12/gap-status-gap03.md` y `evidence/gate-03/2026-11-12/fca-sensitivity.md`. Refina D-213: la referencia sigue siendo la de los municipios del mismo tipo, con los mismos cortes y la misma prueba.

1. **Qué cambia.** Antes cada fila contaba centros por habitante del propio municipio o distrito: una clínica pesaba como La Paz, un consultorio de aldea como un centro de salud grande, y lo que había al otro lado de la frontera de un distrito no contaba. Ahora cada fila mide **la capacidad que la gente tiene al alcance a pie, compartida con quienes compiten por ella**.
2. **Método: 2SFCA** (Luo y Wang, 2003, «Measures of spatial accessibility to health care in a GIS environment», *Environment and Planning B* 30: 865–884).
   - Paso 1, por centro: su capacidad dividida por la gente que vive a 15 minutos a pie o menos.
   - Paso 2, por calle: la suma de esas cuotas de los centros a 15 minutos o menos.
   - Por zona: la media ponderada por población de sus calles, que es igual a la capacidad que le llega dividida por su población. La capacidad se conserva: en la región, el total es la capacidad alcanzable entre la población (test de propiedades).
   - **Captación: 15 minutos a 4 km/h (1 km por la red de calles),** la de «El Madrid de los 15 minutos» del Ayuntamiento, la misma fuente de D-211. Es binaria (dentro o fuera), la versión más fácil de explicar.
   - **Sensibilidad:** con 10 o 20 minutos, el orden de los municipios casi no cambia (Spearman 0,995–0,997; entre el 1 % y el 2 % se mueve más de 20 puestos).
   - **Red y personas:** la red peatonal y las calles de origen de D-210. La población de cada municipio (censo de la CM), y en Madrid la de cada distrito (padrón escalado al total del censo de Madrid, D-216 §5), se reparte entre sus calles en proporción a su longitud. Quien vive a más de 15 minutos de cualquier centro no suma oferta: la fila mide lo que se tiene cerca.
   - Cruza fronteras: un colegio en el límite de dos distritos sirve a los dos.
3. **Capacidad por fila: solo la publicada, nunca estimada por centro.**

   | Fila | Capacidad (S) | Demanda | Feature |
   |---|---|---|---|
   | Colegio | Aulas de primaria públicas y concertadas del municipio (`cm_unidades_escolares`, curso más reciente), repartidas a partes iguales entre sus colegios de esa titularidad: la estadística no las da por centro (confidence 0,8) | 5 a 14 años | `aulas_primaria_a_pie_por_1000_ninos` |
   | Escuela infantil | 1 por escuela: nadie publica plazas por centro | 0 a 4 años | `escuelas_infantiles_a_pie_por_1000_ninos` |
   | Centro de salud | 1 por centro de salud del SERMAS (equipo de atención primaria, 268). Los consultorios locales son puntos de consulta del mismo equipo: cuentan en los minutos a pie, no como capacidad | Total | `centros_salud_a_pie_por_10000_hab` |
   | Mayores | Plazas autorizadas de hogares, clubes y centros de día (registro de la CM) | 65 o más | `plazas_mayores_a_pie_por_100_mayores` |
   | Farmacia | 1 por farmacia (la ley de la CM las planifica por habitantes) | Total | `farmacias_a_pie_por_10000_hab` |

   - Las features anteriores (centros por habitante) siguen como indicadores extra de cada fila.
   - La fila de centro de salud cuenta un subconjunto de los destinos de sus minutos a pie; el invariante del catálogo lo admite solo en esa fila, declarado en el test.
   - Para la prueba de D-213 las features guardan la capacidad en **centros equivalentes** (capacidad entre la capacidad media por centro de la región). El ratio no cambia, y la prueba de Poisson cuenta centros, no aulas ni plazas, que van en bloques.
4. **Lo que no existe en abierto (T2a, comprobado el 12 nov):**
   - población asignada por tarjeta sanitaria y cupos de médicos por centro o por zona básica de salud;
   - camas por hospital en el portal de la CM. «Hospitales y datos asistenciales» y «Dotación de camas» solo traen el total regional: 85 hospitales y 20.776 camas instaladas en 2023, 3,00 por 1.000 habitantes. Se cargan como referencia (`cm_hospitales_datos_asistenciales` y `cm_dotacion_camas`, 11 métricas).
   - El Catálogo Nacional de Hospitales 2025 (Ministerio de Sanidad) sí publica camas por hospital (XLSX, reutilizable con cita), pero no si tiene urgencias. Queda propuesto como fuente complementaria para enseñar «Hospital La Paz · N camas» (siguiente paso, con resolución de entidades frente al registro de la CM).
   - La geometría de las zonas básicas de salud es abierta, pero de 2019 y con el padrón de 2019: no se usa para la capacidad. Solo sirve aquí para fijar el radio de §6.
5. **Hospitales:** no hay 2SFCA a pie, porque un hospital no se elige a 15 minutos andando. La fila de centro de salud gana como extra `min_a_pie_hospital`: los minutos a pie por la red hasta el hospital general más cercano, público o privado (60). Es un proxy de las urgencias 24 h, que ninguna fuente abierta marca, y se declara.
6. **Escala: los municipios pequeños se comparan con sus vecinos.**
   - El 2SFCA no crea información: en centros equivalentes, un pueblo pequeño sigue esperando menos de 3,69 casos y su estado sigue siendo poco fiable (D-213). Eso le pasaba a 140 de 179 municipios en colegios.
   - **Regla:** un municipio poco fiable se compara junto con sus vecinos más cercanos del mismo tipo (rural o urbano), que se añaden por orden de distancia hasta que el grupo espera 3,69 casos. Es el mismo umbral de D-213 y la referencia deja fuera a todo el grupo.
   - **Radio:** solo vecinos a 15 km o menos (entre los puntos interiores de los municipios). Las zonas básicas de salud rurales de la CM tienen un radio equivalente mediano de 7,7 km y una extensión mediana de 22,9 km (capa oficial de 2019, 15 zonas de menos de 100 hab./km²). Así el grupo es el entorno con el que ya se organizan los servicios de esos pueblos, no una comarca entera. Si con ese radio no se llega, el municipio sigue «poco fiable».
   - **Base:** filtros espaciales adaptativos con un mínimo de casos esperados (Talbot et al., 2000, *Statistics in Medicine* 19: 2399–2408).
   - El estado del grupo es el de la zona, con los mismos cortes y la misma prueba. La API lo marca en `comparison_group` (códigos, nombres y ratio del grupo) y lo explica en el texto de la fila. Los distritos de Madrid no se agrupan: casi nunca son pequeños.
7. **Efecto con los datos del 12 nov** (municipios, 179):
   - **Poco fiables:** escuela infantil de 138 a 37, colegio de 140 a 65, centro de salud de 167 a 96, mayores de 160 a 93 y farmacia de 116 a 18.
   - **FALTA:** escuela infantil 0, colegio 0, centro de salud 0, mayores 6 y farmacia 5 (antes 0, 0, 5, 2 y 5).
   - **Casos de la revisión de D:** M1, San Martín de Valdeiglesias, centro de salud: FALTA → CUBIERTO (1,59; poco fiable, sin vecinos suficientes a 15 km). M2: los consultorios ya no cuentan como capacidad. M3, La Acebeda: 0 a pie, poco fiable.
   - **Madrid capital, centro de salud:** FALTA (0,67) → **JUSTO (0,95)**. Al medir lo que se alcanza a pie, y no centros por habitante del propio municipio, Madrid queda cerca de los demás municipios urbanos. **La frase del pitch «Madrid tiene un tercio menos de centros de atención primaria por habitante» deja de valer.**
   - **Chamartín:** centro de salud CUBIERTO (1,17), colegio CUBIERTO (1,12) y mayores JUSTO (0,59).
8. **Contrato:** `GapMethod.version = gap-0.3`, `ComparisonGroup` y `comparison_group` en `GapRow` y `ZoneGapStatus` (opcional, compatible). Los distritos de las features 2SFCA son solo los 21 de Madrid (D-200). Fixtures regenerados con datos reales, con un ejemplo agrupado (`zone_gap_list.el_alamo`) y `places.colegios_chamartin` (`places-1`, D-216). El test de la web `gapMap.test.ts` lee ahora el estado de Centro del fixture en vez de fijarlo (cambio mínimo en `apps/web`, pedido por `datamad-10`).
9. **Límites declarados:**
   - captación binaria, sin decaimiento con la distancia (E2SFCA, Luo y Qi 2009, queda como mejora);
   - la población se coloca por longitud de calle, no por portal;
   - las aulas se reparten a partes iguales dentro de cada municipio y titularidad;
   - en un hogar o club las plazas autorizadas son aforo y en un centro de día, plazas de atención;
   - la distancia de los vecinos se mide en línea recta;
   - la proximidad a pie no es la única forma de acceso: en los pueblos, el coche y el autobús cuentan (CORE-009).

## D-218 — Nombre y camas de los hospitales desde el Catálogo Nacional de Hospitales (2026-11-12)
Petición de Mariano (12 nov): que se vea el tamaño de cada hospital, porque no es lo mismo una clínica que La Paz, y que los hospitales tengan su nombre en vez de «Hospital general (Madrid)». Reversible: es un directorio complementario y campos opcionales en `/places`. Código: `hi_ingestion/pipelines/directory/` (tipo de pipeline `facility_directory`), `hi_ingestion/pipelines/places/directory.py` (cruce) y `hi_domain/facilities.py`. Evidencia: `evidence/gate-01/2026-11-12/hospitales-cnh.md`.
1. **Fuente:** Catálogo Nacional de Hospitales 2025 del Ministerio de Sanidad (actualizado a 31 de diciembre de 2024), hoja «DIRECTORIO DE HOSPITALES», solo la provincia de Madrid (91 hospitales). El aviso legal del Ministerio autoriza la reutilización, también comercial, si no se desnaturaliza la información, se cita la fuente y se menciona la fecha de actualización. Se leen solo nombre, dirección, código postal, clase, dependencia y camas; nunca teléfono ni correo (D-186). Es fuente complementaria: el portal de la CM no publica camas por hospital (D-217 §4) y el registro de centros sanitarios de la CM sigue siendo la fuente de cada lugar, su tipo y su ubicación.
2. **Solo Silver.** El directorio no crea lugares. Tiene su propio Quality Gate (entre 80 y 120 filas en la región, códigos únicos, camas numéricas en al menos el 90 %, sin columnas de contacto) y el pipeline del registro de la CM lo lee en su última versión válida. Ese fichero entra en la suma de comprobación y en el linaje de la carga del registro: una edición nueva del catálogo vuelve a procesar el registro (test).
3. **Cruce (resolución de entidades).** No hay un código común (el registro de la CM usa su número, `CH0001`; el catálogo, `CODCNH`), así que se cruza por dirección postal con tres reglas, de la más fuerte a la más débil, siempre uno a uno:
   - `direccion` (1,0): mismo código postal, misma calle y el número del registro aparece en la dirección del catálogo;
   - `calle` (0,9): mismo código postal y calle, y es el único hospital de esa calle;
   - `codigo_postal` (0,7): el único hospital de la misma clase en ese código postal.

   «Único» se juzga entre todos los hospitales del código postal, también los ya cruzados: un lugar que el catálogo no tiene nunca hereda el que sobra en su código postal. La calle tiene que tener las mismas palabras (sin tipo de vía ni artículos: «Real» no es «Real de Pozuelo»), los puntos kilométricos y los códigos postales no cuentan como número de portal, y un hospital público nunca se cruza con uno privado (veto cuando las dos fuentes lo dicen). Un hospital del catálogo que reclaman dos lugares no va a ninguno, y lo que ya ha tomado una regla fuerte no se ofrece a una débil. Cada cruce se guarda como alias en `place_source_alias` (método y puntuación) y en `attributes.directory` del lugar. Reglas endurecidas tras la revisión con `reviewer` (parser `places-1.3.1`).
4. **Resultado con los datos del 12 nov:** 79 de los 85 hospitales del registro (64 por dirección, 13 por calle y 2 por código postal). Contraste independiente: antes de añadir el veto, los 79 cruces ya coincidían en público o privado (0 discrepancias), y con las reglas endurecidas salen los mismos 79 pares. Los 6 sin cruzar se declaran en el informe: CH0049 (el catálogo pone el Ramón y Cajal en la calle de Ayala, no en la carretera de Colmenar), CH0068, CH0120, CH0121 (Tres Cantos, sin hospital del catálogo en su código postal), CH0122 y CH0123 (el hospital de su código postal ya lo tomó otro registro por dirección). Conservan «Hospital general (Municipio)» y no muestran camas. Corregirlos a mano necesitaría un fichero de correcciones con fuente oficial por registro: es la misma decisión pendiente de Mariano que la de las coordenadas (board).
5. **Nombre:** el del catálogo tal como lo publica (sin corregir tildes: no se desnaturaliza). Se quita la forma jurídica («Clínica La Luz, S.L.» → «Clínica La Luz») y no se usa cuando el catálogo da una empresa o un operador en lugar del centro: un nombre válido dice qué es («hospital», «clínica», «sanatorio», «centro», «complejo», «instituto», «fundación»). Así quedan fuera «Servicio Madrileño de Salud», «HM Hospitales 1989, S.A.», «ID Dalud Móstoles Sa», «Alm Univass S.L.», «Casta Guadarrama» y «Fraternidad Muprespa, Mutua…» (6 lugares, que conservan el nombre genérico pero sí muestran camas). Son nombres de establecimientos, no de personas: ninguna consulta privada ni titular particular entra en el producto (D-186).
6. **Contrato `/places` (aditivo, sigue `places-1`):** en los hospitales cruzados, `capacity` = camas instaladas (`unit: "camas instaladas"`, `dataset_id: ms_catalogo_nacional_hospitales`) con dos campos opcionales nuevos: `dependency` (`publica` o `privada`, del registro de la CM; las mutuas colaboradoras cuentan como privadas porque solo atienden accidentes de trabajo de sus afiliados) y `kind` (el tipo del registro, p. ej. «Hospital general»). Ningún campo existente cambia ni desaparece. Hasta hoy ningún lugar de salud traía `capacity`; en los hospitales la unidad es «camas instaladas» (las del catálogo a 31/12/2024, no las de funcionamiento de un día concreto). Ejemplo: `data/fixtures/contracts/places.hospitales_madrid.fixture.json`.
7. **Lo que no se hace:** las camas no entran en la lista de lo que falta ni en un 2SFCA. Un hospital no se elige a 15 minutos andando (D-217 §5), y medir «camas alcanzables» exigiría una captación en coche o en transporte público que hoy no tenemos (CORE-009). Queda como posible extra con su propio ADR.
8. **Centros de salud y consultorios (fase 2, mismo método):** el registro de la CM no publica su nombre. Se cruzan con el Catálogo de Centros de Atención Primaria del SNS 2026 del Ministerio de Sanidad (actualizado a 31 de diciembre de 2025; 266 centros de salud y 154 consultorios locales del SERMAS en Madrid, todos de gestión pública directa), con las mismas reglas y el veto público/privado. El catálogo da un nombre de lugar («ABRANTES»), que se presenta con el tipo del registro y en mayúsculas normales: «Centro de salud Abrantes», «Consultorio local La Acebeda». Son nombres de centros públicos, nunca de personas (D-186). Lo que va entre paréntesis en la calle del registro («de la Paloma (El Vellón)») vale con y sin paréntesis. **Resultado:** 356 de los 423 centros de salud y consultorios del registro (278 por dirección, 55 por calle y 23 por código postal; 0 discrepancias público/privado). Los 67 sin cruzar (sobre todo, código postal distinto en las dos fuentes o dos registros de la CM en la misma dirección) conservan «Centro de salud (Municipio)». No hay capacidad: el catálogo no publica profesionales ni población asignada por centro (D-217 §4).
9. **Segunda pasada (HOSP-001 F3, notas de C desde producción):** cinco reglas en vez de tres, con el mismo principio (uno a uno, «único» entre todas las entradas, también las ya tomadas). Nuevas: `direccion_municipio` (0,85; mismo municipio, calle y número en otro código postal, porque las dos fuentes discrepan en los bordes de los distritos) y `municipio` (0,6; la única entrada del mismo tipo en el municipio, para pueblos que comparten código postal). Por debajo de la dirección completa (código postal, calle y número) el municipio y el tipo tienen que coincidir: Madarcos y Robregordo comparten código postal y «calle de las Eras», y un consultorio en Palma 54 no es el centro de salud de Palma 51. La dirección completa basta aunque el catálogo archive el centro en el municipio de su área de salud (Aravaca, en Madrid, figura en Pozuelo de Alarcón). Las calles se comparan con abreviaturas («Mª», «Ntra. Sra.»), singular y plural, esquinas, «bulevar», «callejón» y «carrera» como tipo de vía, el número pegado a «Nº» y la sustitución del catálogo de atención primaria, que escribe «CALLE» por cada «CL» y «AVENIDA» por cada «AV» también dentro de las palabras («SAN CALLEAUDIO», «ISLA DE JAVENIDAA»); el nombre publicado nunca se corrige. **Resultado:** centros de salud con nombre de 228 a 255 (genéricos de 44 a 17) y consultorios de 128 a 144 (de 23 a 7); ningún cruce anterior cambia de pareja y se pierden 3, explicados en la evidencia (Las Américas pasa del centro que solo compartía código postal al que tiene su dirección). Hospitales sin cambios: el Ramón y Cajal (CH0049, Fuencarral-El Pardo) sigue sin nombre ni camas porque el catálogo lo sitúa en la calle de Ayala 38 (28001) y el registro en la carretera de Colmenar Viejo, km 9,1; solo lo resolvería el fichero de correcciones con fuente oficial que sigue pendiente de Mariano (§4). El «Hospital especializado · 50 camas» de Chamartín (CH0113) es el de una mutua: el catálogo publica el nombre de la mutua, no el del centro, y por §5 no se usa. Tras la revisión con `reviewer`: una esquina solo vale para un lugar sin número, el singular solo quita la «s» de plurales en -as/-os de más de 4 letras, y se aceptan y declaran dos riesgos medidos (5 cruces por dirección completa en los que el registro y el catálogo clasifican distinto el mismo edificio, y 21 cruces por calle con portales distintos en las dos fuentes). Evidencia: `evidence/gate-01/2026-11-12/nombres-segunda-pasada.md` (parser `places-1.5.4`; los directorios guardan el municipio de cada entrada con `directory-1.1.0`).

10. **Correcciones con fuente oficial (decisión de Mariano, delegada en `datamad-10`, 12 nov):** un fichero versionado, `data/catalog/corrections/places.yaml` (contrato `PlaceCorrections`), con una corrección por registro: qué registro, qué se usa en su lugar (una dirección para el geocodificador o la entrada del directorio que es ese lugar), por qué y dónde lo publica una fuente oficial (URL, fecha de consulta y el texto exacto). Nunca de memoria ni de fuentes privadas. La carga lo aplica con linaje: el fichero es un input (`corrections`) de la carga del registro, así que un cambio la vuelve a procesar, y cada lugar corregido lo dice en `attributes.correction`. Un emparejamiento a mano va antes que las reglas (`match_method: correccion`) y su entrada ya no se ofrece a otro lugar; una dirección corregida pasa por el geocodificador con las reglas de D-216. **Aplicadas:** el Ramón y Cajal (CH0049, con la web del hospital en comunidad.madrid: 886 camas) y los 4 centros de salud «S/N» (Orcasur, Campamento, Miguel de Cervantes y María de Guzmán, con el número de portal del catálogo de atención primaria del Ministerio). **Sin fuente utilizable, declarados:** el consultorio de Villar del Olmo, el CEIP de Navalafuente y el consultorio CS12766 de Buitrago. Evidencia: `evidence/gate-01/2026-11-12/correcciones.md`.
## D-219 — Conexiones de la API: pool por entorno y pooler de Supabase en modo transacción (2026-11-12)
Incidente del 12 nov (05:00): la vista de zona daba 500 intermitentes con «EMAXCONNSESSION max clients reached in session mode» (`pool_size: 15`). Cada instancia de Vercel abría el pool por defecto de SQLAlchemy (5 + 10) contra el pooler de Supabase en modo sesión (puerto 5432), que admite 15 clientes en total para todo el proyecto: con tres instancias ya no quedaban. Código: `packages/db/src/hi_db/session.py` y `settings.py`. Reversible: tres variables de entorno, con los valores por defecto de siempre.
1. **Pool por entorno (mitigación, `4645326`):** `DB_POOL_SIZE` y `DB_MAX_OVERFLOW` fijan el pool de cada proceso. Por defecto 5 y 10 (los de SQLAlchemy; validados ≥ 1 y ≥ 0). Producción usa 2 y 1.
2. **Modo transacción (arreglo de fondo):** la API pasa al pooler en modo transacción (puerto 6543), el que Supabase recomienda para funciones serverless que abren muchas conexiones cortas. En ese modo una conexión del servidor se presta solo durante una transacción, así que el límite deja de ser de 15 clientes.
3. **Sin prepared statements en ese modo:** el pooler compartido de Supabase no los admite en modo transacción («turn them off», guía de conexión de Supabase). psycopg 3 prepara solo una consulta cuando la ha ejecutado `prepare_threshold` veces en la misma conexión (5 por defecto) y los desactiva con `prepare_threshold=None` (documentación de psycopg 3.1+, «Prepared statements» y `Connection.connect`). `DB_PREPARED_STATEMENTS=false` pasa ese valor a `psycopg.connect()` por `connect_args`, que SQLAlchemy entrega tal cual al `connect()` del driver. Sin la variable, o con `true`, no se pasa nada y psycopg conserva su valor. Un valor que no sea booleano hace fallar el arranque. Comprobado en la base local: 1 prepared statement tras 8 ejecuciones de la misma consulta con el valor por defecto y 0 con `false` (test unitario `tests/unit/test_db_engine_prepared_statements.py`).
4. **Estado de sesión:** en modo transacción un `SET` de sesión no está garantizado entre transacciones. La API no lo necesita: el rol `vf_api_ro` (D-208, migración 0005) ya trae `search_path = public, extensions`, `default_transaction_read_only` y `statement_timeout` a nivel de rol, y cada conexión del servidor los toma al abrirse (comprobado por MCP en `pg_db_role_setting`). El `SET search_path` de `make_engine` queda como redundante y es inofensivo (pone el mismo valor). La API no usa tablas temporales, `LISTEN`, bloqueos consultivos ni cursores de servidor.
5. **Orden del cambio en producción:** primero `DB_PREPARED_STATEMENTS=false` en Vercel y redespliegue (funciona también en el puerto 5432); después Mariano cambia el puerto de `DATABASE_URL` a 6543, se redespliega y se pasa el smoke. Al revés, las consultas repetidas fallarían con «prepared statement … already exists» o «does not exist». El pool se queda en 2 + 1 hasta medirlo en modo transacción.
6. **Solo la API.** Las migraciones y el sync (`SUPABASE_DATABASE_URL`) siguen en el modo sesión: Alembic necesita estado de sesión (`.env.example`).
7. **Alternativas descartadas:**
   - `NullPool` (una conexión nueva por petición): resuelve el límite, pero suma a cada petición la apertura de TLS y el arranque de sesión con el pooler;
   - conexión directa a Postgres: solo IPv6, y Vercel sale por IPv4;
   - pooler dedicado (PgBouncer ≥ 1.21, que sí admite prepared statements): es de pago;
   - activar `prepare_threshold=None` al detectar el puerto 6543 en la URL: comportamiento oculto; se prefiere una variable explícita;
   - dejar solo el pool pequeño en modo sesión: con 2 + 1 caben 5 instancias, y un pico de tráfico (la demo ante el jurado) puede abrir más.

## D-220 — Tiempo en transporte público al trabajo: horarios GTFS del CRTM, llegando a las 9:00 (2026-11-12)
CORE-009. Hasta hoy el trabajo puntuaba en línea recta (D-215: `fit-0.1`, confidence 0,5) y un límite de trayecto salía siempre UNKNOWN. Reversible: método `commute-0.1`, dos tablas Gold (migración 0007) y el encaje `fit-0.2`. Código: `hi_domain/access/transit.py` (búsqueda), `hi_features/commute.py` (`hi-features commute`). Evidencia: `evidence/gate-03/2026-11-12/commute-matrix.md` (`scripts/commute_summary.py`).
1. **Qué se mide:** los minutos de puerta a puerta para **llegar a las 9:00** a un sitio de trabajo, con los horarios publicados de los 6 GTFS del CRTM (metro, Metro Ligero, Cercanías, EMT, autobuses urbanos e interurbanos), cada uno en su martes de referencia (D-196). Es la mediana de tres horas de llegada (8:30, 8:45 y 9:00), para no depender de que un tren llegue a las 8:59 o a las 9:01. Incluye la espera en destino si el último servicio que llega a tiempo llega antes.
2. **Método:** red expandida en el tiempo (cada parada de cada expedición es un evento: llegada, salida a bordo y andén). Transbordos en la misma parada con 2 minutos y a pie entre paradas a 250 m o menos. Una búsqueda hacia atrás desde las llegadas a tiempo da, en cada parada, la última salida que todavía llega: es la búsqueda «llegar a las…» de cualquier planificador de viajes, y como los tiempos son absolutos basta con la alcanzabilidad. Tests de propiedades: una hora de llegada más tardía o una expedición más nunca adelantan una salida.
3. **Orígenes:** las 4.417 secciones censales, que tienen poblaciones parecidas; cada una en el nodo de sus calles residenciales (las de D-210) más cercano a su centro ponderado por longitud, porque el punto interior de una sección rural grande puede caer en el campo. Valor de la zona = mediana de sus secciones (las que no llegan cuentan como las más lentas, así que si no llega más de la mitad, la zona queda sin dato). A pie hasta la parada (y desde la parada al destino) en línea recta × 1,3 de rodeo a 4 km/h (D-211), hasta 1 km.
4. **Destinos («hubs»):** las 379 estaciones de metro, Cercanías y Metro Ligero de `place_master` y el centro de población de cada zona (la sección más cercana a todas las demás de la zona). Son los sitios que la web ofrece en «Trabajo en». 200 zonas (179 municipios y los 21 distritos de Madrid) × 579 destinos = 115.800 filas.
5. **Datos del CRTM que hay que limpiar (nunca se inventa un horario):**
   - expediciones cuyas horas retroceden: fuera (514 de autobuses urbanos y 98 de interurbanos);
   - paradas seguidas con la misma hora (solo la primera es punto de horario): se interpolan por distancia hasta el siguiente punto de horario, como hace GTFS con las paradas sin hora;
   - después del último punto de horario (hay expediciones con la misma hora en todas sus paradas): se estima por distancia con la **velocidad mediana de las expediciones de la misma línea que sí publican horario**, o de todo el GTFS si ninguna lo hace. Afecta a 5.730 expediciones interurbanas y 1.250 urbanas; se declara;
   - expediciones a más de 120 km/h de media en línea recta: fuera (584 interurbanas).
6. **Límites declarados:**
   - el GTFS interurbano publicado no trae expediciones de las líneas 720 a 726 (Colmenar Viejo, Soto del Real, Manzanares el Real, Miraflores…), y 35 líneas interurbanas tienen la misma hora en todas sus paradas en todas sus expediciones (p. ej. 01:00); en esas zonas el tiempo sale alto o sin dato (Colmenar Viejo a Sol, 107 min);
   - 45–50 zonas, sobre todo de la Sierra Norte y del sureste, no llegan al centro de Madrid a las 9:00 saliendo desde las 5:30: sin dato, nunca 0;
   - la red a pie es en línea recta con rodeo, no por calles (la red peatonal se usa para colocar los orígenes);
   - horarios programados, no tiempos reales; un día laborable de referencia.
8. **En la búsqueda (`fit-0.2`, F3):**
   - **Sitio de trabajo → destino:** la estación de metro, Cercanías o Metro Ligero a 600 m o menos (más el paseo desde ella), si no el centro del distrito de Madrid o municipio que lo contiene. La web solo ofrece estaciones y zonas. Fuera de toda zona, línea recta como antes (con aviso).
   - **Condición** (`max_minutes`): PASS o FAIL con los minutos; UNKNOWN donde no se llega con los horarios publicados (hay huecos declarados en §6, así que nunca es FAIL seguro).
   - **Preferencia:** utilidad 1 hasta 30 minutos (o el límite si lo hay) y 0 al triple, como los minutos a pie. «No se llega a las 9:00» puntúa lo peor con confidence 0,5: es una medida con los horarios publicados, no un dato que falte, pero puede ser un hueco del GTFS.
   - **Confidence:** 0,7 hasta una estación y 0,6 hasta el centro de una zona (representa toda la zona); horarios programados de un martes de referencia.
   - **Golden de búsqueda:** las expectativas del trabajo pasan a minutos (`top_within_minutes`): la persona sola que trabaja en Nuevos Ministerios tiene primero Villaverde, a 35 min en transporte público y 11 km en línea recta, así que su «primera zona a 10 km o menos» ya no describe el método; tampoco la «primera a 5 km» del caso demo, porque el centro de Fuencarral-El Pardo cae en el monte de El Pardo. Se mantienen las de km que siguen valiendo. **Caso demo:** Fuencarral-El Pardo pasa a primera (100 %, 29 min hasta la Castellana) y Ciudad Lineal a segunda (99 %, 33 min); con `fit-0.1` era al revés por la línea recta.
   - **Orden estable (petición de D):** las zonas se ordenan por el encaje sin redondear; si empatan, por más confidence, después por menos minutos en transporte público hasta el primer sitio de trabajo y al final por el id de la zona. Nunca depende del orden en que llegan las zonas (test de propiedad, y el golden de búsqueda lo comprueba en los 6 escenarios con las zonas al revés). En el caso demo, Ciudad Lineal (99 %, 33 min) va delante de Hortaleza (99 %, 32 min) porque su encaje sin redondear es mayor (0,9943 frente a 0,9918).
   - **Revisión (`reviewer`):** un cambio andando a otra parada nunca cuesta menos que los 2 minutos de la misma parada (había parejas de paradas a 0 m); una zona que falta en la matriz cae a la línea recta en vez de puntuar como «no se llega»; el Reality Check ya no dice «aún sin calcular». Matriz recalculada: 73.783 filas con minutos.
7. **Alternativas descartadas:** polos de empleo fijos (la web deja elegir cualquier estación o zona); un motor externo (r5, OpenTripPlanner: Java y otro servicio que desplegar); RAPTOR (misma respuesta, más código para la alcanzabilidad que aquí basta); calcular en cada petición (cargar 400.000 eventos por instancia de Vercel).

## D-221 — Nombres con tilde solo con fuente oficial por registro (2026-11-12)
Petición de `datamad-10`: el Ramón y Cajal salía «Ramon». Los dos catálogos del Ministerio que dan nombre a hospitales y centros de atención primaria (D-218) pierden a veces tildes o eñes («Fundacion», «Infanta Sofia», «LAVAPIES»). Matiza D-218 §5 («sin corregir tildes»): el nombre publicado sigue siendo el del catálogo, salvo que una corrección versionada con fuente oficial dé otro. Reversible: un campo opcional en el fichero de correcciones. Código: `hi_contracts/catalog/corrections.py`, `hi_ingestion/pipelines/places/normalize.py` (parser `places-1.7.1`). Evidencia: `evidence/gate-01/2026-11-12/nombres-tildes.md`.
1. **Cómo:** `name` en la corrección de un registro de `data/catalog/corrections/places.yaml` (D-218 §10). El contrato exige que el nombre sea el texto que cita la fuente (`says`), con palabras completas y acentos en forma compuesta (NFC); solo pueden cambiar las mayúsculas, las comillas y los espacios («Centro de Salud Lavapiés» → «Centro de salud Lavapiés», como los demás nombres). Una tilde que la fuente no escribe hace fallar la carga: nunca se corrige de memoria (D-212). Puede ir sola o con la corrección de dirección o de directorio del mismo registro.
2. **Orden y linaje:** el nombre corregido va el último, encima del del registro y del directorio. `attributes.correction` dice `kind` (`name`, o `directory+name` en el Ramón y Cajal), la fuente y `previous_name`; `attributes.directory.name` conserva el nombre tal como lo publica el catálogo.
3. **Fuentes, de más a menos fuerte:** el BOCM cuando lista el registro por su número (órdenes de la Consejería de Sanidad que renuevan autorizaciones: «CH0080. Hospital Universitario Fundación Alcorcón», «CS8694.- Centro de Salud Lavapiés»); la página del centro en comunidad.madrid con la misma dirección; un texto del BOCM que nombra el mismo centro con el mismo domicilio. Todas son de la Comunidad de Madrid. Una excepción declarada: el Hospital Beata María Ana (CH0024) solo tiene un decreto que lo nombra sin dirección (Placa de Oro, 2014); el emparejamiento es por el nombre, que es único en la región, y por la titularidad (Iglesia, Hermanas Hospitalarias, Madrid), no por el domicilio.
4. **Revisión sistemática** (`scripts/audit_name_accents.py`): un nombre es candidato si los datos oficiales ya cargados (municipios, distritos, barrios, registros de la CM, paradas del CRTM) escriben la misma palabra con tilde o eñe, o si termina en «-cion»/«-sion». Se leyeron además a mano los 313 nombres de atención primaria sin ninguna tilde (así salió «Lain»). **Corregidos: 11** (8 hospitales y 3 centros de atención primaria). **Sin corregir, declarados:** HM Nuevo Belén y HM Montepríncipe (ninguna fuente pública oficial los nombra), las tres «Quironsalud» (marca comercial; ninguna fuente oficial), Belvis del Jarama (la CM también escribe «Belvis de Jarama»), «Cortes» (el barrio de Cortes no lleva tilde) y «Canal de Panamá» (falso positivo de «cañal»).
5. **El nombre es el de la fuente entero, no solo sus tildes:** al corregir una tilde se toma el nombre completo como lo escribe la fuente, aunque cambie algo más: «Dr.» (Pedro Laín Entralgo), «Don» (Infante Don Luis de Borbón) o sin «de» (La Fuenfría). En CS12162 el nombre oficial dice «Consultorio» (también el catálogo del Ministerio) y el registro lo inscribe como centro de salud: el tipo (`subcategory`) no cambia y la diferencia queda visible y declarada (D-218 §9). No se buscan fuentes para cambiar nombres que no han perdido tildes («Hospital General de Villalba» frente a «Hospital Universitario General de Villalba»).

## D-222 — Zonas verdes: parques de OSM de 1 ha o más, medidos a pie hasta su borde (2026-11-12)
DATA-018 (extra elegido por Mariano, D-205). Hasta hoy la prioridad «Zonas verdes» del buscador salía «aún sin datos». Reversible: un dataset complementario (`osm_parques`), un tipo de pipeline (`osm_parks`) y features nuevas. Código: `hi_ingestion/pipelines/osm_parks/`, `hi_features/methods.py` (`destination_points`). Evidencia: `evidence/gate-01/2026-11-12/parques.md`, `evidence/gate-03/2026-11-12/parques-features.md`.
1. **Fuente:** el mismo extracto de OpenStreetMap (Geofabrik, ODbL) que la red peatonal (D-210). El portal de la Comunidad de Madrid no publica parques urbanos: solo espacios naturales protegidos, que no son el parque del barrio. El inventario del Ayuntamiento de Madrid (D-205) solo cubre la capital; OSM cubre toda la región con un mismo criterio. Fuente complementaria: no cuenta como dato CM.
2. **Qué es un parque:** un área OSM con `leisure=park` (vía cerrada o multipolígono) que no esté cerrada al público (`access` = `no`, `private` o `customers`) y que tenga **1 ha o más**, el tamaño mínimo por defecto del indicador de zonas verdes urbanas de la OMS (Annerstedt van den Bosch et al., *Scandinavian Journal of Public Health*, 2016: 300 m en línea recta hasta el borde de una zona verde de al menos 1 ha). Resultado del 12 nov: 1.402 parques (8.423 ha) en 80 municipios; 4.911 áreas más pequeñas y 54 cerradas al público quedan fuera. 711 no tienen nombre en OSM («Parque sin nombre»).
3. **Lugar y borde:** cada parque es un lugar de `place_master` (categoría `green`, subcategoría «Parque», con un punto dentro del parque para el mapa) que guarda su superficie (`area_ha`) y los puntos de su borde exterior cada 50 m en EPSG:25830 (`edge_points_25830`, 70.573 puntos). A un parque se llega por su borde, no por su centro: El Retiro mide 1,4 km de lado. Quality Gate: entre 700 y 4.000 parques, ids únicos, borde con al menos 3 puntos, 1 ha o más, ninguno cerrado al público y menos del 2 % en cuarentena.
4. **Límites declarados:** no cuentan los bosques y el campo de los pueblos, que no son parques urbanos, ni las plazas y jardines de menos de 1 ha (el umbral de la OMS). La calidad del etiquetado de OSM varía por municipio. Los recuentos de parques y hectáreas pueden contar dos veces un parque dibujado a la vez como vía y como relación, o un parque dentro de otro (no cambia ninguna distancia). El Monte de El Pardo no es un parque público (Patrimonio Nacional, acceso restringido) y no se incluye.
5. **Parques que OSM etiqueta de otra forma (petición de `datamad-10`):** se comparó la lista oficial del Ayuntamiento de los principales parques y jardines municipales (datos.madrid.es, 203 con coordenadas) con los parques de OSM. 34 no caen dentro ni a menos de 150 m de un parque de OSM de 1 ha o más: casi todos son jardines de menos de 1 ha. Dos son grandes y OSM los etiqueta de otra forma: la **Casa de Campo** (`landuse=forest`, 1.373 ha en OSM; el Ayuntamiento publica 1.535,52 ha) y la **Quinta de Torre Arias** (`leisure=garden`, 18 ha). Entran por un fichero versionado, `data/catalog/corrections/parks.yaml` (contrato `ParkInclusions`), con la fuente oficial de cada uno (URL, fecha y texto), como las correcciones de D-218 §10; el fichero es un input de la carga y cada parque incluido lo dice en `attributes.inclusion`. Parser `osm-parks-1.1.1`: 1.404 parques. El Quality Gate falla si un parque del fichero no llega a publicarse (`every_inclusion_published`), y de un contorno inválido solo se quedan sus polígonos (si no queda ninguno, cuarentena).
6. **Features (`min_a_pie_parque`, `pct_calle_parque_5min`):** el mismo método a pie que D-210 (red de calles de OSM, 4 km/h, mediana de las calles donde vive la gente y % de calle dentro de la ventana) con destino en **cualquier punto del borde** del parque: un destino que guarda `edge_points_25830` se alcanza por todos ellos. La ventana es de 5 minutos (unos 330 m por la calle, frente a los 300 m en línea recta de la OMS). Por sección, municipio y distrito. Madrid capital: de 1,8 min (Moratalaz, 87 % de calle a 5 min) a 8,4 min (Chamberí, 20 %). 101 de los 179 municipios tienen la mitad de sus calles a más de 30 minutos andando de un parque urbano de 1 ha: 78 son rurales según la Ley 45/2007 (de los 84 rurales de la región; criterio de D-213) y 23 urbanos. En los rurales el indicador no dice nada del campo que los rodea; los minutos de más de 30 (Chinchón 192, Patones 363) se leen como «no hay parque urbano a un paseo», no como una distancia útil.
7. **En el buscador (`fit-0.3`, petición de `datamad-10`, revisado con `reviewer`):** la prioridad «Zonas verdes» (que ya ofrecía la web y salía «aún sin datos») lee `min_a_pie_parque` por su enlace `fit: {role: walk_minutes, priority: zonas_verdes}` (el contrato `FitBinding` admite una prioridad además de un servicio). Utilidad 1 hasta 10 minutos y 0 a los 30, como los demás minutos a pie; hecho «Parque urbano a N min andando desde la mitad de sus calles». **Sin parque urbano a un paseo (más de 30 min) puntúa 0, con confidence ≤ 0,5 y el hecho «Sin parque urbano de 1 ha o más a un paseo (el campo no cuenta)».** No es FAIL porque es una prioridad, no una condición (no hay «parque a N min como mucho» en `ScenarioState`). Tampoco UNKNOWN: se probó y la revisión mostró que rompía el orden, porque un criterio sin dato sale de la media y un pueblo sin parque quedaba por delante de una ciudad con el parque a 25 minutos (y podía llegar al 100 % solo con el transporte). Con 0 el orden es monótono (test de propiedad: un parque más lejos nunca sube una zona) y el texto dice qué se mide y qué no. Sin dato de la feature, UNKNOWN como siempre. **No entra en «Qué falta»:** no hay fila de zonas verdes en GAP-001 sin un criterio estadístico como el de D-217 y una referencia que distinga parque urbano y campo. Golden de búsqueda: 7/7, con un escenario nuevo del perfil `golden_sensory_preferences` (zonas verdes primero: las 5 primeras zonas tienen un parque urbano a 10 minutos o menos).

## D-223 — «Sin escaleras»: estaciones con accesibilidad total según la topología del CRTM (2026-11-12)
DATA-019 (extra elegido por Mariano, D-205). Hasta hoy la prioridad «sin escaleras» del buscador salía «aún sin datos». Reversible: tres datasets de la topología del CRTM, un tipo de pipeline (`station_topology`), un enlace opcional en el GTFS (`station_accessibility`), una feature y el encaje `fit-0.4`. Código: `hi_ingestion/pipelines/station_topology/`, `hi_ingestion/pipelines/gtfs/accessibility.py`, `hi_domain/fit.py` (`PRIORITY_WALK`). Evidencia: `evidence/gate-01/2026-11-12/estaciones-accesibles.md` (`scripts/audit_step_free.py`), `evidence/gate-04/2026-11-12/golden-search-sin-escaleras.txt`.
1. **Qué se mide (necesidad funcional, opt-in, CLAUDE.md §13):** los minutos a pie hasta la estación de metro, Metro Ligero o Cercanías **con accesibilidad total** más cercana. Solo cuenta si la persona marca «sin escaleras»; nunca se infiere ni se etiqueta a nadie ni a ningún barrio. Es un proxy declarado: no mide autobuses, aceras, portales ni ascensores de los edificios.
2. **Fuente (dato CM):** «Topología de la Red de Metro», «… de Metro Ligero / Tranvía» y «… de Cercanías Madrid» del portal de datos abiertos de la Comunidad de Madrid (publica el CRTM, licencia CRTM-LDA con cita). Solo la capa de estaciones y cuatro campos: `IDESTACION`, `CODIGOEMPRESA`, `DENOMINACION` y `GRADOACCESIBILIDAD` (T, P o N). 12 nov: metro 293 estaciones (195 T, 6 P, 92 N), Metro Ligero 57 (57 T), Cercanías 111 (42 T, 28 P, 41 N).
3. **Cómo se lee el grado (aviso de A v11):** ni el CRTM ni el portal publican un diccionario de `GRADOACCESIBILIDAD`. Se lee T como «accesibilidad total» porque la Comunidad de Madrid declara de Metro Ligero «El 100% de la red es accesible» (comunidad.madrid, «Accesibilidad en el transporte público») y el CRTM que «los Metros Ligeros y los intercambiadores cuentan ya con un 100% de accesibilidad» (crtm.es, «Accesibilidad en el transporte»), y la capa da T a las 57 estaciones de Metro Ligero; en metro, el CRTM dice que «el 70% de las estaciones están actualmente adaptadas» y la capa da T al 66,6 % (T o P, 68,6 %). P (parcial) y N nunca cuentan como sin escaleras. Un grado que no esté declarado en el pipeline va a cuarentena.
4. **El `wheelchair_boarding` del GTFS del CRTM no se usa:** no sigue el estándar GTFS (2 = no se puede subir). En metro, las 282 paradas con 2 son de estaciones T en la topología, y Metro Ligero, accesible al 100 %, publica 2 en sus 71 andenes; en Cercanías mezcla grados. Hasta hoy el pipeline lo guardaba como «yes/no» con el sentido estándar (al revés en metro y Metro Ligero); no lo leía nada. Desde `gtfs-1.2.0` se guarda el código tal cual (`gtfs_wheelchair_boarding`) y nunca se interpreta.
5. **Enlace con las estaciones (resolución por código oficial):** cada estación del GTFS de metro, Metro Ligero y Cercanías toma el grado de la estación de la topología con su mismo código (metro y Metro Ligero: el `IDESTACION` que lleva su id, «par_4_12» → «4_12»; Cercanías: el id de parada es el `CODIGOEMPRESA`). Un intercambiador (Sol, Nuevos Ministerios…) es un lugar en el GTFS y una estación por línea en la topología: es sin escaleras solo si lo son todas. Una estación con un código que no está en la topología queda sin dato y no cuenta (Cercanías: Méndez Álvaro P.V. y Vallecas). Atributos: `step_free` (yes, partial, no), `topology_station_ids` y `step_free_source` (dataset y versión). Quality Gate del GTFS: al menos el 90 % de las estaciones con lectura (metro 100 %, Metro Ligero 100 %, Cercanías 97,8 %). Resultado: metro 148 sí, 2 parcial, 80 no; Metro Ligero 56 sí; Cercanías 26 sí, 26 parcial, 39 no. Si la topología no se ha cargado nunca, el GTFS carga igual con todas las estaciones sin dato y el informe de calidad lo dice (como los directorios de D-218); `run-all` carga antes las topologías. Si dos estaciones de la topología comparten código, cuenta la menos accesible (revisión).
6. **Feature `min_a_pie_estacion_sin_escaleras`:** el método a pie de D-210 (red de calles de OSM, 4 km/h, mediana de las calles donde vive la gente) con destino en las estaciones `step_free = yes`. De las 199 zonas del buscador, 5 tienen una a 10 minutos o menos, 29 entre 10 y 30 y 165 a más de 30. Madrid capital: de 6,8 min (Chamberí) a 25,5 (Usera). 4 km/h es la velocidad de todo el método: con movilidad reducida los minutos son más (declarado).
7. **En el buscador (`fit-0.4`):** la prioridad lee la feature por `fit: {role: walk_minutes, priority: sin_escaleras}`, con la misma regla que las zonas verdes (D-222 §7): utilidad 1 hasta 10 minutos y 0 a los 30; hecho «Estación de metro o tren accesible (sin escaleras) a N min andando desde la mitad de sus calles». A más de 30 minutos puntúa 0 con confidence ≤ 0,5 y el hecho «Sin estación de metro o tren accesible a un paseo (no mide autobuses, aceras ni portales)»: es una prioridad, no una condición, y un UNKNOWN pondría un pueblo sin estación por delante de una ciudad con la estación a 25 minutos. Sin dato de la feature, UNKNOWN como siempre. No entra en «Qué falta». Golden de búsqueda: 8/8, con un escenario nuevo del perfil `golden_reduced_mobility` («sin escaleras» primero: las 5 primeras zonas tienen una estación accesible a 15 minutos o menos).
8. **Recarga desde Bronze (revisión):** los 6 GTFS se recargaron con `--local` desde el mismo Bronze (sin horarios nuevos). Desde hoy un fichero que ya está en Bronze conserva la URL oficial y la fecha de descarga de su manifest (`local_file`), en vez de una ruta local.
9. **Descartado:** los autobuses (el CRTM declara accesibles el 100 % de los urbanos e interurbanos, así que una parada de autobús no distingue zonas); las «Instalaciones accesibles» del Ayuntamiento (solo Madrid capital, y son edificios, no el camino); el estado de los ascensores en tiempo real (no hay dato abierto).

## D-224 — Seguridad: la tasa oficial de hechos conocidos no entra en el buscador (2026-11-12)
DATA-020. Evaluada la fuente que proponía A v11: «Hechos conocidos de infracciones penales por tipología en municipios mayores de 20.000 habitantes por municipio» (portal CM, CC BY 4.0, Ministerio del Interior). Es oficial y agregada, y no trae características de personas, así que no le aplica el descarte de D-205. Evidencia: `evidence/gate-01/2026-11-12/seguridad-evaluacion.md`.
1. **Decisión:** no se carga ni puntúa. La prioridad «Seguridad» sigue saliendo «aún sin datos oficiales»: nunca 0, nunca etiquetas.
2. **Por qué:**
   - **Denominador:** la tasa se calcula por vecino empadronado, pero los hechos se cuentan donde se denuncian o actúa la policía. En 2024, criminalidad convencional por 1.000 habitantes: Humanes de Madrid 116,2 y Madrid 58,6, frente a una referencia de 47,9 para los 37 municipios. Ordenar zonas con esa tasa señalaría municipios por la actividad que reciben, no por la seguridad de quien vive allí.
   - **Cobertura:** solo 36 de las 199 zonas del buscador. Los 21 distritos de Madrid quedan fuera porque la fuente da la ciudad entera, y repartirla supondría barrios homogéneos (§11).
   - **Modelo:** la curva que convierte la tasa en encaje es una decisión de modelo y de producto sobre un dato sensible (CLAUDE.md §4).
3. **Opción abierta para Mariano (no se hace sin su decisión):** enseñar la tasa como dato de contexto en la vista de zona de esos 36 municipios. Iría con la cifra absoluta, la referencia, el año y el aviso del denominador. No puntuaría ni ordenaría zonas. Se descartaría la cibercriminalidad, porque no ocurre en un sitio. Faltaría resolver los nombres de municipio a código INE, porque la fuente no trae código.

## D-225 — Servidor MCP local: cinco herramientas de solo lectura sobre los servicios de la API (2026-11-12)
MCP-001. El producto DATA (API + MCP, CLAUDE.md §16) tenía `services/mcp/` vacío. Es reversible: un paquete nuevo del workspace (`hi-mcp`), dos servicios sin ruta en la API (`explanation.py` y `zones.py`) y dos contratos (`ZoneExplanation`, `ZoneLookup`). No cambia ninguna ruta ni ningún dato. Código: `services/mcp/src/hi_mcp/`. Uso: `docs/04_technical_architecture/32_mcp_server.md`. Evidencia: `evidence/gate-11/2026-11-12/`.
1. **SDK:** el oficial de Python, `mcp` 2.3.0 (PyPI, 2 oct 2026; documentación en py.sdk.modelcontextprotocol.io). No estaba en `uv.lock`. Se usan `MCPServer` (en la v2 sustituye a `FastMCP`), herramientas con tipos de Pydantic y transporte stdio. Las firmas se comprobaron en el código instalado: `MCPServer.tool`, `Annotated[CallToolResult, Modelo]` para dar el esquema de salida, `ToolError` y el `Client` en memoria de los tests. La restricción es `>=2.3,<3`. La imagen de la API no lo instala: `uv sync --frozen --package hi-api` solo instala el cierre de `hi-api` (comprobado con uv 0.11.4). El Dockerfile copia `services/mcp` como los demás miembros del workspace, sin instalarlo (revisión).
2. **Herramientas:**
   - `buscar_zonas`: `ScenarioState` → `SearchResponse`, igual que `POST /search`. Sin `include_map`, deja vacío `all_zones`, que es la mitad de la respuesta y solo sirve para pintar un mapa.
   - `que_falta`: igual que `GET /gaps/{level}/{code}`.
   - `explicar_zona`: la tarjeta de la zona en `/search` para un escenario, con sus indicadores y sus datasets (`attribution_text` y cuántos son CM).
   - `encontrar_zona`: los municipios y distritos de Madrid por su nombre. Los agentes no saben códigos INE.
   - `fuentes_de_datos`: igual que `GET /datasets`.

   Las herramientas devuelven el mismo sobre que sus rutas, y los tests de integración comparan las dos respuestas.
3. **Sin SQL en el servidor ni para el LLM (CLAUDE.md §3):** las herramientas llaman a las funciones de `hi_api.services`. Las entradas tienen tipo:
   - nivel como enumeración;
   - código INE con patrón `^28…`;
   - `ScenarioState`;
   - el nombre se compara en Python (`hi_domain.geo.names.match_rank`: sin mayúsculas, tildes ni signos).

   Cada llamada va en una transacción `READ ONLY` de Postgres. Un test lo comprueba con una escritura.
4. **Texto para el modelo:** el mismo JSON que `structuredContent`, compacto y en UTF-8. Con la serialización por defecto del SDK (JSON sangrado) y el mapa, una búsqueda ocupa unos 130 KB, por encima del corte de 25.000 tokens de Claude Code. El caso demo, compacto y sin `all_zones`, ocupa 60 KB.
5. **Local, sin desplegar:** stdio para una persona en su ordenador, contra la base local o la del paquete offline. Sin autenticación, límites de uso ni HTTP. Si algún día se publica, aplica `29_api_mcp_security_rate_limits.md`. `make mcp` no repite la receta, porque stdout es el protocolo.
6. **Revisión (`reviewer`):**
   - `explicar_zona` repite el aviso de un sitio de trabajo fuera de toda zona, como `/search` (`load_warnings`, compartido);
   - la caché de mapas de «Qué falta» de la búsqueda devuelve su valor desde una variable local, porque un `clear()` de otro hilo podía dar un `KeyError` (también en la API);
   - `encontrar_zona` dice cuántas coincidencias deja fuera (`total` y un aviso);
   - los registros van a stderr en nivel INFO (duración de cada herramienta);
   - un test lee el stdout del proceso y exige que sea solo JSON-RPC.
7. **Descartado:**
   - una herramienta de consultas genéricas sobre features o tablas (sería SQL libre con otro nombre);
   - el control del mapa (`MapState`, CLAUDE.md §9): la web no escucha a un agente;
   - rutas nuevas en la API para `explicar_zona` y `encontrar_zona`: no las pide la web y se desplegarían.

## D-226 — Seguridad en Madrid capital: lo que dicen los vecinos como contexto, la actividad policial sin el panel y sin atropellos en el buscador (2026-11-12)
DATA-020 F1. Amplía D-224 a petición de Mariano («Sí, investiga eso»), con las reglas de CLAUDE.md §11 y D-075: datos oficiales y agregados, sin inferencias demográficas y sin etiquetas. Evidencia: `evidence/gate-01/2026-11-12/seguridad-fuentes.md`. Las cuatro fuentes son del Ayuntamiento de Madrid (datos.madrid.es, CC BY 4.0, comprobado en CKAN el 12 nov) y solo cubren la capital: el resto de la región queda SIN DATOS, declarado.
1. **Percepción vecinal: entra como contexto en los 21 distritos.** Es el ítem «Percepción de seguridad en el barrio o la zona donde vive», de noche y de día, de 0 a 10, de la Encuesta de calidad de vida y satisfacción con los servicios públicos de 2025: 8.593 residentes de 16 años o más (corregido el 15 nov: ponía 8.893; ficha técnica del informe, «Tamaño muestral»), unas 400 por distrito.
   - Es la medida más cercana a «seguridad para quien vive allí»: los vecinos valoran su propio barrio, así que no tiene el problema de denominador de D-224.
   - Se lee del panel de indicadores que ya se carga: sus valores coinciden con la encuesta en los 21 distritos. Va con la media de Madrid (6,4 de noche y 7,8 de día en 2025).
   - No puntúa, no ordena zonas y no entra en «Qué falta».
   - Se enseña con lo que es: «así valoran sus vecinos la seguridad de su barrio», con el año y el tamaño de la muestra. Sin colores de alarma ni palabras como «peligroso»: una cifra baja no puede convertirse en una etiqueta del barrio.
2. **Actuaciones de la Policía Municipal: la fuente existe y es abierta, pero no se lee del panel.**
   - La copia del panel repite valores entre distritos distintos y no coincide con los ficheros mensuales. Por ejemplo, Salamanca tiene 57 actuaciones de patrimonio en el panel y 349 en la fuente.
   - Si entra, será desde la fuente mensual (12 XLSX por año, un pipeline nuevo). Solo las actuaciones relacionadas con las personas y con el patrimonio, por 1.000 habitantes del padrón (D-209) en 12 meses, con la media de la ciudad.
   - Las de drogas y armas quedan fuera: miden dónde se hacen operativos, no lo que le pasa a quien vive allí (Centro tiene 1.878 de tenencia de drogas en 2025).
   - Aviso obligatorio: «mide la actividad registrada por la Policía Municipal, no el riesgo de vivir allí». Solo contexto.
3. **Atropellos: no puntúan.** En 2025 hubo 1.375 atropellos con expediente en Madrid, 434 de ellos con un peatón ingresado o fallecido; por distrito, de 0,22 a 0,78 por 1.000 habitantes.
   - Sin un dato de cuánta gente camina por cada calle, la tasa señala los barrios con más vida (Centro, Salamanca) y premia los que dependen del coche.
   - Por sección censal hay de media uno cada dos años, así que el ruido pesaría más que la diferencia entre calles.
   - Una prioridad «calles más seguras para ir andando» ordenaría con un dato que no mide eso, así que no se crea.
   - La DGT: no se ha verificado una descarga abierta por municipio; no se usa.
4. **Fuera de la capital,** sin cambios respecto a D-224: el Balance de Criminalidad no puntúa.
5. **En el buscador,** la prioridad «Seguridad» sigue sin puntuar: no hay un dato que la mida para quien vive allí en toda la región. Su hecho deja de prometer datos, porque D-224 y esta decisión cierran que no se puntúa con lo que hay: «Seguridad: no la puntuamos (no hay un dato oficial que la mida para quien vive en cada zona)».
6. **Hecho en F2:**
   - features `seguridad_percibida_noche` y `seguridad_percibida_dia`, de dominio `safety`, sin `fit` ni `gap_row` (un test lo exige para todo el dominio);
   - el panel conserva la fila de la ciudad de estos dos indicadores como el municipio 28079 (`city_indicators`), que da la referencia;
   - cuando dos ediciones del panel repiten una fecha (2019 sale en las de 2020 y 2021), se queda una observación, la de la edición más reciente (parser `madrid_district_panel-1.2.0`);
   - confidence 0,9 por distrito (unas 400 personas) y 0,95 para la ciudad (8.593). Es un juicio editorial: el Ayuntamiento no publica el error de estas medias. No cambia ningún orden, porque no puntúan;
   - la API ya los sirve en `GET /features/{id}/values` sin cambiar código;
   - la Policía Municipal desde la fuente mensual queda pendiente.
7. **Revisión (`reviewer`, F2b):**
   - solo se funden las fechas repetidas entre ediciones distintas del panel; un duplicado dentro de una misma edición llega al check crítico `unique_keys` y lo hace fallar;
   - una edición que no es un año va a cuarentena;
   - la fila de la ciudad no lleva nombre de distrito;
   - las limitaciones públicas de las features no llevan cifras que caducan ni afirmaciones sin evidencia.

## D-227 — Comprar: el valor tasado de la vivienda libre por municipio, y los distritos de Madrid sin datos (2026-11-12)
DATA-021. Sustituye D-214 §5, donde comprar salía UNKNOWN en todas las zonas. Es reversible: un dataset CM, una feature con enlace `fit: {role: price_m2}` y el encaje `fit-0.5`. Código: `hi_domain/affordability.py` (`purchase_cost`, `_purchase_check`), `hi_domain/fit.py` (`purchase_fact`, `estimated_cost`) y `hi_domain/reality_check.py`. Evidencia: `evidence/gate-01/2026-11-12/cm_valor_tasado_vivienda_municipios/`, `evidence/gate-04/2026-11-12/golden-search-compra.txt`.
1. **Fuente (dato CM):** «Valor tasado de la vivienda libre por municipios de más de 25.000 habitantes. Total (Base 2005). Municipios», del portal de datos abiertos de la Comunidad de Madrid (id 1004050, CC BY 4.0, actualizado el 2 jun 2026). Es la Estadística de Valor Tasado de la Vivienda del Ministerio de Vivienda y Agenda Urbana.
   - Media anual en €/m², de 2005 a 2025, con código de municipio.
   - En 2025 tienen valor 28 municipios: los de más de 25.000 habitantes con tasaciones suficientes. Van de Aranjuez (1.931 €/m²) a Madrid (4.993 €/m²).
   - Se cargan los años desde 2021 y la búsqueda lee el último.
2. **Qué es y qué no es:** es lo que tasan las sociedades de tasación, sobre todo para conceder hipotecas. No es el precio de un anuncio ni el de una venta concreta. Es la media de todo el municipio y de toda la vivienda libre, nueva y usada. Confidence 0,8.
3. **Distritos de Madrid: SIN DATOS.** Un distrito no toma la media de la ciudad: entre Salamanca y Villaverde el precio cambia demasiado (CLAUDE.md §11). La feature les da una fila `SOURCE_MISSING` y la condición sale UNKNOWN con su explicación.
4. **Coste y condición:** valor tasado por m² × los m² que se suponen para el hogar (D-214), redondeado a miles de euros. El estado, el valor y el texto usan ese mismo número.
   - PASS o FAIL con la confidence del dato. Sin valor publicado, UNKNOWN y nunca PASS: «Sin precio de compra publicado para esta zona…».
   - Si la tasación se expresa por m² construido, el coste se queda algo corto, porque los m² supuestos son útiles. Por eso un FAIL es más fiable que un PASS, como con el alquiler.
   - `estimated_cost_eur` es el precio de compra cuando se busca comprar.
5. **Encaje (`fit-0.5`):** el presupuesto de compra puntúa como el de alquiler: utilidad 1 si el coste es el 75 % del presupuesto o menos y 0 en el presupuesto. El hecho es «Comprar ≈ 221.000 € por 77 m² (2.869 €/m², valor tasado medio de la vivienda libre, no el precio de un anuncio)».
   - El Reality Check sube el presupuesto un 10 %, redondeado al alza a 10.000 €, hasta el máximo de 5 millones. Ya no quita el límite: a una zona sin precio no la mete ningún presupuesto.
   - Golden `golden_couple` (320.000 € para dos adultos): 10 resultados con precio publicado; la condición que más zonas deja fuera es el presupuesto, porque 172 zonas no tienen precio.
6. **Descartado:**
   - El valor de referencia del Catastro por código postal que publica la CM (id 1934262): es por vivienda, solo de las arrendadas, de 2023, y es un valor administrativo, no un precio.
   - El valor tasado trimestral por antigüedad (`valor_tasado_vivienda_municipio_antiguedad`): no trae código de municipio; queda para cuando haga falta el trimestre.
   - Repartir el valor de Madrid entre sus distritos.
7. **Orden del cambio en producción:** primero se despliega el código y después se sincroniza. El código desplegado (`fit-0.4`) no conoce el rol `price_m2`: con la feature en la base, `/search` fallaría.
8. **Revisión (`reviewer`, F1b):**
   - `explicar_zona` (MCP) cita como indicador de coste el que evalúa: el valor tasado para comprar y el alquiler para alquilar o sin presupuesto;
   - un test de integración siembra un valor tasado en un municipio de los fixtures y comprueba por la API PASS, FAIL, el coste en € y el dataset citado;
   - quedan fijados en tests el redondeo del Reality Check (305.000 € → +40.000 €) y el tope de 5 millones;
   - pendiente de la web (línea B): las tarjetas aún dicen «Aún no tenemos precios oficiales de compra por zona» (`SearchCard.tsx`, `FitDetails.tsx`). Deberían decirlo solo donde la condición sale UNKNOWN, por ejemplo: «Solo hay precio en los municipios de más de 25.000 habitantes; los distritos de Madrid no lo tienen».

## D-228 — Alquiler de contratos nuevos: el índice CM 1934428 no permite ajustar el nivel; propuesta con la tabla de nuevos contratos de la Agencia Tributaria (2026-11-12)
Fase de mejora, punto 8 (`<workspace>/prompts/FASE_MEJORA.md`). **Mariano decidió «Ajustar con el índice CM».** Este ADR registra por qué ese índice no sirve y la alternativa. **Mariano eligió la opción A el 12 nov** (a través de `datamad-10`), y se implanta en `fit-0.6` (§6). Evidencia: `evidence/gate-01/2026-11-12/alquiler-contratos-nuevos/evaluacion.md`.
1. **Qué publica el dataset 1934428** (comprobado el 12 nov; CC BY; actualizado el 02-06-2026):
   - dos índices anuales del IPVA del INE (2015 = 100), contrato nuevo y contrato existente, de 2021 a 2024, sin código de territorio;
   - los valores coinciden con los de la Comunidad de Madrid en la tabla 59004 del INE, aunque los metadatos digan «Toda España»;
   - en 2024 los contratos nuevos subieron un 9,2 % y los existentes un 2,7 %.
2. **Por qué no sirve:**
   - cada serie vale 100 en su propio 2015, así que el cociente de los dos índices no dice cuánto más cuesta un contrato nuevo;
   - el INE avisa de que su variación «solo recoge una parte del efecto del cambio de contrato»;
   - hay un único valor para toda la región, y sacar de ahí un factor de nivel sería un ajuste a ojo.
3. **Alternativa con fuente oficial:**
   - **Fuente:** «Estadística de viviendas declaradas en IRPF» de la Agencia Tributaria, ejercicio 2024. Es la misma estadística que la CM republica y que ya usamos.
   - **Qué publica:** el alquiler medio mensual y los m² medios del total y de los «contratos de arrendamiento formalizados en el ejercicio», para 37 municipios de la CM y los 54 códigos postales de Madrid.
   - **Reutilización:** permitida, citando la fuente y la fecha.
   - **Factor (contratos nuevos / total, en €/m²):** municipios entre 1,05 y 1,26 (Madrid 1,20); códigos postales entre 1,10 y 1,26.
   - No está en el portal de la CM.
4. **Propuesta:**
   - **A, recomendada:** el €/m² de la CM por el factor de la AEAT de la misma zona; en los distritos, el de sus códigos postales, ponderado como en D-214.
     - Efecto: Fuencarral pasa de ~1.107 a ~1.270 € y Salamanca de ~1.526 a ~1.880 €, con 77 m².
     - Hecho: «contratos firmados en 2024».
   - **B:** solo un aviso más fuerte con esas cifras, sin cambiar el coste.
   - En los dos casos el índice 1934428 no entra en el cálculo.
5. **Si se elige A:**
   - versión 3 de `alquiler_m2_mensual` y `fit-0.6`, con tests antes del código y el golden actualizado;
   - el texto `RENT_NOTE` está en el código, así que primero se despliega y después se sincroniza.
6. **Implantación de la opción A** (`fit-0.6`, versión 3 de `alquiler_m2_mensual`; elegida por Mariano el 12 nov):
   - **Fuente complementaria, no CM:** `agencia_tributaria`, con los datasets `aeat_alquiler_nuevos_contratos_municipios` y `aeat_alquiler_nuevos_contratos_codigo_postal`.
     - Son las páginas HTML de la AEAT (no publica CSV ni XLSX), con la URL, la fecha de la metodología (01/07/2026) y la licencia en el catálogo.
     - Pipeline nuevo `aeat_rent_comparison`. Comprueba la cabecera y el año, y no deja publicar la tabla si está cortada.
     - Métricas `alquiler_mensual_irpf_*` y `m2_alquiler_irpf_*`, con la dimensión `contratos: todos | nuevos`.
   - **Cálculo:** factor = (alquiler / m² de los nuevos) / (alquiler / m² de todos), de la misma zona y del último año.
     - **Municipios:** su factor y, sin tabla propia, el de la fila de la Comunidad («Madrid, Comunidad de», suma de los municipios de la tabla). Hoy los 37 municipios con alquiler tienen el suyo.
     - **Distritos:** cada código postal por su factor antes de la media ponderada de D-214, y sin tabla propia, el de Madrid. Hoy los 54 tienen el suyo.
     - **Sin factor propio ni de reserva:** el valor queda desconocido, nunca la cifra antigua con la etiqueta nueva.
     - **Trazabilidad:** `inputs.new_contracts` guarda el factor, de dónde sale y el valor de todos los contratos.
   - **Texto:** «Alquiler ≈ 1.276 €/mes por 77 m² (16,6 €/m², contratos firmados en 2024; un anuncio de hoy puede pedir más)».
     - La nota va en el catálogo (`fit.note`) y no en el código, así que el código desplegado y los datos nunca se contradicen.
     - Sin nota, se mantiene «media de los contratos vigentes».
   - **Efecto con 77 m² (datos del 12 nov):** Fuencarral-El Pardo pasa de 1.107 a 1.276 €, Salamanca de 1.465 a 1.797 € y Madrid de 1.163 a 1.400 €.
     - Caso de la familia (1.500 €): la condición que más zonas quita sigue siendo el colegio a 10 min, y ahora +150 €/mes añade 3 zonas (antes, ninguna). Salamanca, Chamartín y Centro quedan como «casi», porque fallan solo en el presupuesto.
   - **Golden** (`evidence/gate-04/2026-11-12/golden-search-alquiler-nuevo.txt`): 8/8.
     - En familia y persona sola la primera zona pasa a estar a 39 y 43 min en transporte público (Latina y Leganés, más baratas). El límite de esas dos expectativas sube de 35/40 a 45 min.
     - A cambio se añaden dos comprobaciones: que +150 €/mes añade zonas (familia) y que el presupuesto es la condición que más quita (persona sola).
   - **Textos de D (a la vez):** los hechos de minutos a pie dicen «a unos 9 min andando», sin «desde la mitad de sus calles».
     - El hospital a más de 30 min como distancia («a unos 3,4 km») no es un texto de la API: lo pinta la web con el extra `min_a_pie_hospital` (línea B).
   - **Orden en producción:** primero se despliega `fit-0.6` y después se sincroniza. El código desplegado (`fit-0.5`) no conoce la nota, así que con los datos nuevos diría «media de los contratos vigentes» junto a la cifra de los contratos nuevos.
7. **Revisión (`reviewer`, Fase 2b):**
   - sin bloqueantes;
   - el valor y el factor tienen que ser del mismo año: si una edición nueva de cualquiera de los dos llega sola, el cálculo se para con un mensaje que pide cargar ambas y actualizar `fit.note`. Un test comprueba que el año de la nota es el de las tablas de la AEAT;
   - una página con más de un «Ejercicio» se rechaza, y la tabla de municipios exige la fila de la Comunidad (el factor de reserva);
   - el golden de la familia baja a 41 min (con 39 observados) para no tapar una regresión;
   - queda declarado que un factor de reserva no baja la confidence: hoy no se usa en ninguna zona. **Corregido por D-242 §3:** desde el 15 nov lo usan los 126 municipios que rellena la referencia del Ministerio (ninguno tiene tabla propia de la AEAT). Para ellos el factor de reserva es la mediana de los 37 factores municipales, 1,155, no la fila de la Comunidad (D-243 §11); el alquiler de la Comunidad (`alquiler_m2_mensual`) conserva la fila «28» como reserva, que no usa ningún municipio.


## D-229 — Cifras de impacto: gente que vive donde falta y «dónde invertir primero» (2026-11-12)
Fase de mejora, punto 3 (`<workspace>/prompts/FASE_MEJORA.md`): es lo que más puntos da según el jurado simulado. Método `impact-0.1`. Código:
- `hi_domain/gap_impact.py`;
- `hi_api/services/gap_impact.py`;
- ruta `GET /api/v1/gaps/impact`;
- campo `people` en cada fila de `/gaps/{level}/{code}`.

Evidencia: `evidence/gate-04/2026-11-12/impact-cifras.txt`. Es reversible: ruta y campo nuevos, opcionales y sin cambios en lo que ya existía.

1. **Gente afectada:**
   - **Qué es:** la población objetivo de la fila que vive en una zona en FALTA.
     - Escuela infantil: niños de 0 a 4 años.
     - Colegio: niños de 5 a 14 años.
     - Centro de salud y farmacia: habitantes.
     - Mayores: personas de 65 años o más.
     - Vivienda: hogares de 4 o más personas.
   - **De dónde sale:** es el mismo denominador que guarda el indicador de la fila (D-213 §4). Viene del censo de la CM y, en los distritos, del padrón escalado (D-209, D-216). No se estima nada.
   - **Unidades:** los 2SFCA guardan el denominador por cada `per` personas y los demás métodos, en personas. La conversión está en una sola función (`people_scale`).
   - **Coherencia con el catálogo:** un test comprueba que la etiqueta («niños de 0 a 4 años») coincide con las dimensiones de población de la feature principal de cada fila.
2. **Zonas:** las del buscador (D-215): los municipios, con Madrid capital por sus 21 distritos cuando la fila tiene valores por distrito y entera cuando no (vivienda). `madrid_level` dice cuál se usa. Los estados salen de los mismos mapas en caché que `/gaps?level=&row=` (la caché pasa de `search.py` a `gap_map.py`), así que una zona contada aquí sale FALTA en el mapa y en su lista; lo comprueba un test.
3. **«Dónde invertir primero»:**
   - **Orden:** las zonas en FALTA, de más a menos gente afectada.
   - **Significación (D-213, D-217):** cada zona trae su ratio frente a los municipios parecidos (el de su grupo si se compara con sus vecinos) y `p_value`. Es la probabilidad exacta de Poisson, unilateral, de que una zona con la tasa de referencia tenga tan poco. Es la misma prueba que decide FALTA: p < 0,025 equivale a que la cota de Garwood al 95 % quede por debajo de lo esperado (test).
   - **Frase:** «Viven aquí 9.433 niños de 0 a 4 años. Tienen 57 por cada 100 que tienen los municipios parecidos, y una diferencia así sale por azar menos de 1 entre 100 veces».
4. **Cifras con los datos del 12 nov:**
   - **Escuelas infantiles:** 25.551 niños de 0 a 4 años (el 9,8 %) en 3 distritos (Puente de Vallecas 9.433, Carabanchel 9.150 y Villaverde 6.968).
   - **Centros de mayores:** 54.581 personas de 65 años o más (el 4,1 %) en 6 municipios, encabezados por Torrejón de Ardoz y Pozuelo de Alarcón.
   - **Farmacias:** 667.172 personas (el 9,4 %) en 5 municipios: Getafe, Torrejón de Ardoz, Parla, Rivas-Vaciamadrid y Valdemoro.
   - **Vivienda para familias:** 99.483 hogares de 4 o más personas (el 14,8 %) en 25 municipios, encabezados por Fuenlabrada, Leganés y Alcorcón.
   - **Colegios y centros de salud:** ninguna zona tiene una falta clara.
5. **Límites declarados:**
   - **Contar a toda la población objetivo:** se cuenta a toda la de la zona, aunque dentro de ella unas calles estén mejor servidas que otras.
   - **Zona comparada con sus vecinos:** cuenta su propia gente, no la del grupo.
   - **Lo que no se calcula:**
     - cuántos centros harían falta: la oferta del 2SFCA es compartida entre zonas y ese número se leería mal;
     - un ranking de zonas en JUSTO.
6. **Frase de la web «Aquí hay {n} por cada 100 que hay en municipios parecidos» (pregunta de D):** la calcula la web con lo que ya da la API, `n = round(100 × ratio_to_reference)`. Si la zona se compara con sus vecinos, se usa el `ratio_to_reference` de `comparison_group`. El `explanation` de `/gaps` no cambia.
7. **Revisión (`reviewer`, Fase 2b):**
   - sin bloqueantes;
   - el porcentaje del resumen sale de la misma cuota acotada que `share_in_falta` y se omite si el total es desconocido;
   - `p_value` se redondea hacia abajo, a 3 cifras: una zona en FALTA nunca muestra 0,025;
   - `zones` cuenta también las zonas SIN DATOS.
   - Queda declarado que las consultas de recuentos no filtran por versión, igual que los mapas de `/gaps`: hoy hay una fila por zona y feature.

## D-230 — Zonas pequeñas: «No comparable», suelo del denominador cuando es un recuento y el motivo real cuando no vive nadie (2026-11-12)
Fase de mejora, punto 7. Refina D-213 y D-217 con el mismo umbral, sin ajustar ninguna zona a mano. Código:
- `hi_api/services/gap_reference.py` (`assess`);
- `hi_api/services/gaps.py` y `gap_map.py`;
- `hi_domain/gap_impact.py` (textos);
- `hi_features/fca.py` (`rows_for`, `census_by_zone`).

Evidencia: `evidence/gate-04/2026-11-12/zonas-pequenas.md`.
1. **«0,0 frente a 28,0 = JUSTO» (La Acebeda, colegio).** Una zona poco fiable (`reliable: false`) y sin grupo de vecinos no puede decir si le falta algo. Su explicación empieza por «No comparable: aquí viven muy pocos niños de 5 a 14 años (3) para saber si falta.» y sigue con las cifras.
   - El estado no cambia de valor: `GapStatus` no gana un valor nuevo, porque la web lo trata como un conjunto cerrado.
   - **Pendiente de B:** pintar «No comparable» en vez del estado cuando `reliable` es `false` y `comparison_group` es `null`.
2. **Vivienda en pueblos pequeños (La Acebeda: 10.700 viviendas por 100 hogares, CUBIERTO).**
   - **Regla:** cuando el denominador de la fila es un recuento (hogares de 4 o más personas, `metric_ratio`), y no una población por cada `per` (2SFCA), también tiene que llegar al suelo de 3,69 de D-213. Por debajo, el recuento es compatible con cero hogares al 95 % y la comparación no dice nada: la zona queda poco fiable y «No comparable».
   - **Efecto:** pasa a 2 municipios de 179, entre ellos La Acebeda, con 1 hogar grande. Ninguna FALTA cambia.
   - **Grupos de vecinos:** este suelo no entra en ellos; un grupo se forma solo por los casos esperados (D-217).
3. **0 niños de 0 a 4 años.**
   - **Qué cambia en los datos:** las filas 2SFCA de una zona donde el censo no tiene a nadie de la edad de la fila salen `NOT_APPLICABLE`, no `SOURCE_NO_COVERAGE`.
   - **Texto:** la API explica «No viven niños de 0 a 4 años en esta zona según el censo, así que no hay nada que comparar».
   - **Lo que no cambia:** una zona con gente pero sin calles donde colocarla sigue `SOURCE_NO_COVERAGE`.
   - **Para B:** hoy la web dice para `NOT_APPLICABLE` «Este dato no tiene sentido en esta zona.». Debería enseñar la `explanation` de la fila o el mismo texto.
4. **Datos:** se recalculan las 5 features 2SFCA. Los valores no cambian; solo el motivo de un nulo (La Acebeda, escuela infantil) y la versión del registro de centros en el linaje. Es compatible con el código desplegado: se puede sincronizar en cualquier orden.

## D-231 — Fuentes: cada dataset dice dónde se publica, y las dos tablas de camas se sirven como contexto (2026-11-12)
Fase de mejora, punto 10 (parte de A). Es aditivo y reversible.
1. **`source_name` en cada `DatasetRef`** (`/datasets`, `/gaps`, `/search` y MCP): es el nombre del registro de fuentes.
   - Ejemplos: «Portal de Datos Abiertos de la Comunidad de Madrid», «Portal de Datos Abiertos del Ayuntamiento de Madrid» (el padrón y el panel de distritos), «OpenStreetMap (extracto Geofabrik Madrid)», el Ministerio de Sanidad y la Agencia Tributaria.
   - **Para B:** la web dice «en el portal de datos» en todos los enlaces (`openHint` en `provenance.ts`). Debería decir «en {source_name}».
2. **Camas (los 2 datasets CM que contamos y no se veían).**
   - **Qué eran:** «Dotación de camas por dependencia» y «Hospitales y datos asistenciales» solo publican el total de la región (D-217 §4). Estaban cargados como métricas, pero ninguna ruta los servía.
   - **Qué se hace:** pasan a dos features de nivel región, `camas_instaladas_por_1000_hab` (3,0 en 2023) y `hospitales_total` (85), en `GET /api/v1/features/{id}/values?level=ccaa`.
   - **Para B:** pintarlas en la nota del hospital («En toda la Comunidad hay 85 hospitales y 3,0 camas instaladas por cada 1.000 habitantes (2023)») con sus dos enlaces.
   - Mientras la web no las enseñe, la cifra pública de datasets CM debería contar 2 menos (decisión de D y Mariano).
   - No entran en «Qué falta» (D-218 §7).

## D-232 — Barrios de Madrid dentro de un distrito: `POST /api/v1/search/barrios` (`fit-0.7`) (2026-11-12)
Petición de Mariano («poca diferenciación… datos por barrios dentro de distritos, como ver solo Simancas»), con el diseño aprobado por `datamad-10`. Es la fase 1 del diseño: los barrios de un distrito, ordenados con el mismo motor que `/search` (card BARRIO-001: sus commits «Fase 1» son los datos, «Fase 2» la ruta y «Fase 2b» la revisión). La fase 2 del diseño (los 131 barrios en el ranking de toda la región) y «Qué falta» por barrio quedan fuera y se deciden con Mariano. Reversible: un nivel más en features que ya existían, una ruta nueva y campos opcionales en el dominio. Código: `hi_api/services/barrios.py`, `hi_features/walk.py` (`zone_of_node`, `section_parents`), `hi_features/methods.py` (`postcode_weighted_mean`), `hi_features/commute.py` (`origin_zones`), `hi_ingestion/pipelines/district_panel/`, `admin_boundaries/official_names.py` y `hi_domain/fit.py`. Evidencia: `evidence/gate-03/2026-11-12/barrios-datos.md` (`scripts/barrio_summary.py`), `evidence/gate-04/2026-11-12/golden-search-barrios.txt` y `evidence/gate-01/2026-11-12/official_names/`.
1. **Secciones a barrios.** La geografía ya asigna cada sección a su barrio: el fichero de secciones de la CM trae el barrio de cada una (`CDTBARRIO`) y el barrio es la unión de sus secciones. Comprobado: las 2.443 secciones de Madrid están en uno de los 131 barrios y ninguna tiene su punto interior fuera de él. El código de barrio no es un prefijo del de la sección (la 2807905013 está en el barrio 28079051), así que el cálculo usa el padre de la sección en `geo_admin_unit`.
2. **Nombres oficiales.** La tabla de barrios de la CM es anterior a la reforma de 2017: deja sin nombre Ensanche de Vallecas, Valderrivas y El Cañaveral y llama «Ambroz» a Valdebernardo. Los nombres salen ahora del panel de indicadores del Ayuntamiento, la misma fuente que los distritos (D-212). El pipeline del panel guarda las filas de barrio de «Total hogares» y «Tamaño medio del hogar» (parser 1.3.0, 917 observaciones de cada una), con su nombre. `admin-names` cambia 17 nombres, entre ellos «Palos de la Frontera» y «Villaverde Alto - Casco Histórico de Villaverde». Un barrio sin nombre en ninguna fuente bloquea el cambio (comprobación crítica). Los hogares por barrio quedan cargados para la fase 2.
3. **Minutos a pie.** Es el mismo `network_walk_time` en el nivel barrio: la mediana de las calles del barrio, nunca la mediana de las medianas de sus secciones (test). Se calcula en las 8 features del buscador y en los 7 «% de calle» que las acompañan, para que la coherencia mediana/% de Gate 3 siga valiendo en todas las zonas. Resultado: 131 de 131 con valor. Ejemplo: en San Blas-Canillejas el colegio está a 8,1 min de mediana del distrito, pero en Rejas a 35,4 (CLAUDE.md §11).
4. **Alquiler.** Es el proxy de D-214 con el factor de contratos nuevos de D-228, con los códigos postales de los lugares del barrio.
   - Un barrio tiene muchos menos lugares que un distrito (entre 0 y 56, mediana 16, frente a 51–242). La confidence es 0,6 como máximo y 0,3 si la media descansa en menos de 5 lugares con alquiler publicado (11 barrios).
   - Sin ningún lugar con código postal (Sol), la fila es `SOURCE_NO_COVERAGE` y la condición sale `UNKNOWN` con el motivo en llano: «Sin datos de alquiler para este barrio: el alquiler se publica por código postal y ningún colegio, centro de salud o centro social del barrio lo lleva en su dirección». Con lugares pero sin alquiler publicado para sus códigos, la fila es `SOURCE_MISSING` y el texto dice «la fuente no publica el alquiler de los códigos postales de sus colegios, centros de salud y centros sociales» (hoy ningún barrio; vale también para los distritos). Nunca toma el alquiler del distrito.
   - Límite declarado: un código postal cubre varios barrios, así que dentro de un distrito el alquiler cambia poco (San Blas-Canillejas: de 14,9 a 16,0 €/m²).
5. **Trayecto al trabajo.** Se aparta en una cosa del diseño, que decía «desde el centro del barrio». El motor de CORE-009 ya mide desde cada sección, y el valor de una zona es la mediana de sus secciones (D-220 §3), así que el barrio se mide igual que el distrito. Es más fiel que un único punto.
   - Los barrios son orígenes, nunca destinos: los 579 destinos no cambian. Son 75.849 filas más (131 × 579), 67.518 con minutos. Las de municipios y distritos no cambian (73.783 con minutos, como en D-220).
   - **Reserva:** si un barrio no está en la matriz (por ejemplo, el código desplegado antes que los datos), usa el trayecto de su distrito con la confidence × 0,8 como preferencia. El hecho lo dice: «… (trayecto medido para todo el distrito, no solo para este barrio)», y `warnings` cuenta cuántos barrios lo usan. No dice «desde el centro del distrito» porque el del distrito también es la mediana de sus secciones.
   - **Un trayecto prestado nunca decide un límite:** con `max_minutes`, la condición de ese barrio sale `UNKNOWN` con los minutos del distrito y la nota en la explicación. Lo que dice el distrito no basta para afirmar PASS o FAIL en uno de sus barrios.
6. **Ruta y contrato.** `POST /api/v1/search/barrios` recibe `{scenario, distrito}` (`BarrioSearchRequest`; un distrito que no es de Madrid da 422 y uno que no existe, 404) y devuelve `BarrioSearchResult`: el contrato de `/search` con `distrito`. Un validador exige que todas sus zonas sean barrios de ese distrito.
   - Mismas condiciones, % de encaje, hechos, casi y Reality Check, que se reenvía a la misma ruta con el mismo `distrito`.
   - `gap_highlights` va vacío: «Qué falta» sigue por distrito.
   - Comprar sale `UNKNOWN`, como en los distritos (D-227); el texto nombra ya «los distritos y barrios de Madrid».
   - Un distrito sin barrios en la geografía (hoy ninguno) responde vacío con un aviso `INSUFFICIENT_DATA`, nunca en silencio.
7. **`fit-0.7` en el dominio.** `Commute.note` (dónde se midió el trayecto si no es en la zona) y `ZoneData.rent_missing` (por qué no hay alquiler). La búsqueda de toda la región no cambia: los 8 golden dan lo mismo y su fixture solo cambia la versión.
8. **Golden** (`barrio_scenarios` en `search_scenarios.yaml`; 9/9 OK). La familia del caso demo en San Blas-Canillejas evalúa 8 barrios: 7 cumplen todo, entre ellos Simancas (97 %, colegio a 7 min, 37 min hasta la Castellana y unos 1.228 €/mes). Rejas sale como «casi» porque falla el colegio a 10 min. Hay 5 % distintos, del 55 % al 97 %, y todos los trayectos son del propio barrio.
9. **Orden en producción.** Los datos nuevos (filas de barrio en `feature_value` y `commute_time` y los 17 nombres) son compatibles con el código desplegado: todas sus lecturas filtran por nivel o buscan por zona. Se pueden sincronizar en cualquier orden, pero la ruta necesita el despliegue. En Supabase son unas 76.000 filas más en `commute_time` y unas 2.000 en `feature_value`.
10. **Revisión (`reviewer`, Fase 2b):**
   - sin bloqueantes;
   - un trayecto prestado del distrito ya no decide un límite (§5) y el texto del alquiler que falta sigue al motivo real de la fila (§4);
   - el tope de 0,3 cuenta los lugares con alquiler publicado, no todos;
   - el test de nombres solo toca las filas del panel y restaura su nombre; un barrio fuera del panel con un nombre roto sigue bloqueando;
   - el contrato del panel exige `expected_barrios` si guarda barrios, y `BarrioSearchResult` exige que `distrito` sea un distrito;
   - quedan como están, declarados: la ruta lee las features de los 131 barrios y filtra en Python (unas 1.300 filas, menos que `/search`), y un barrio con dos nombres en ediciones distintas del panel bloquea `admin-names` (fallo seguro y visible; hoy no pasa).

## D-233 — La tarjeta de transporte separa autobús y Metro/Cercanías, sin cambiar la puntuación (2026-11-14)
Feedback de usuarios del 14 nov: quien se mueve en autobús quiere ver las paradas de autobús, y la tarjeta solo decía «Parada de transporte público a unos 2 min andando» (cualquier modo mezclado). Es aditivo y reversible.
1. **Dos features nuevas, sin puntuar.** `min_a_pie_bus` (EMT, interurbanos y urbanos del resto de municipios) y `min_a_pie_metro` (Metro, Metro Ligero y Cercanías).
   - Mismo método que `min_a_pie_transporte` (`network_walk_time`, mediana de las calles, 4 km/h), mismas reglas de nulos y confianza y los mismos niveles (municipio, distrito y barrio).
   - No hizo falta una subcategoría nueva: las paradas ya se guardan por modo (`emt`, `autobus_interurbano`, `autobus_urbano`, `metro`, `metro_ligero`, `cercanias`) y la fórmula las elige con `subcategories`, como `min_a_pie_estacion_sin_escaleras` (D-223).
   - **No puntúan.** Su `fit` es `{role: transit_mode, mode: bus|metro}`: sin `need` ni `priority`, así que la búsqueda no las convierte en criterio. La necesidad «transporte» sigue puntuando con `min_a_pie_transporte`. El ranking y las cifras del pitch no se mueven: 27 zonas cumplen y Latina es la 1.ª al 98 %, igual con y sin las features (comprobado con el caso del ejemplo contra la base local).
2. **Hecho de la tarjeta** (`hi_domain.fit.transit_walk_text`, `fit-0.7` sin cambio de versión: solo cambia el texto).
   - Las dos: «Parada de autobús a unos 2 min andando · Metro o Cercanías a unos 8 min». Una sola: solo esa («Metro o Cercanías a unos 8 min andando»). Ninguna: el texto de siempre.
   - Un modo sin minutos, o a más de 60 min (el tope que ya se muestra), se deja fuera: el Metro más cercano de un pueblo está en otro municipio y no es un paseo (Navacerrada: autobús a 6 min, Metro a 93 → solo el autobús).
   - `indicator` sigue siendo `min_a_pie_transporte`: la web detecta los minutos andando por el prefijo `min_a_pie_` (`hasWalkingFact`) y la procedencia no cambia. La condición «cerca» (`near:transporte`) tampoco.
3. **Regla de despliegue: primero el código, luego el sync.** Sin las features en la base, el código escribe el texto de siempre (test y comprobación local: resultado idéntico antes de calcularlas). Con el código desplegado y las features aún sin sincronizar no cambia nada visible.
   - **Sincronizar antes de desplegar rompe `/search` y `/search/barrios` (500).** El código anterior a este PR (39644a9) manda todo rol de `fit` desconocido al caso «prioridad a pie» y falla con `transit_mode`.
   - **Este PR lo arregla hacia delante:** `indicators_by_zone` solo trata los roles que conoce e ignora el resto con un aviso en el log. Desde este despliegue, un rol desconocido se ignora (test unitario): los siguientes roles nuevos pueden sincronizarse sin romper.
   - **Rollback:** volver a un despliegue anterior a este PR, con las features ya sincronizadas, rompe `/search`. Antes hay que borrar las 2 filas de `feature_registry` (`min_a_pie_bus`, `min_a_pie_metro`); las de `feature_value` caen por CASCADE.
4. **Sync.** Tablas `feature_registry` (2 filas) y `feature_value` (9.948 filas: 4.974 por feature, 131 de barrio, 246 de distrito, 179 de municipio, 4.417 de sección y 1 de región); `make supabase-sync` copia las tablas enteras. Valores locales: Latina bus 2,1 y Metro 8,3 min; Tetuán 2,1 y 7,0; Centro 2,1 y 4,4; Navacerrada 5,7 y 93,4.
5. **Texto por modo y veredicto.** El texto sale de la mediana de cada modo y el veredicto de la condición, de la mediana combinada (`min_a_pie_transporte`): pueden diferir en 1 min (barrio 28079016: combinado 2,0, PASS, y «autobús a unos 3 min»). Es esperable, no un error.

## D-234 — Comprar en Madrid capital: precio estimado por distrito y barrio, y un Reality Check que no culpa al presupuesto de lo que es falta de datos (`fit-0.8`) (2026-11-14)
Feedback de usuarios de prueba del 14 nov (W1), con la solución aprobada por Mariano. Al buscar «Comprar», ningún distrito ni barrio de Madrid tenía precio: el valor tasado del Ministerio solo cubre municipios de más de 25.000 habitantes (D-227 §3). Salían «sin datos» y el aviso proponía «+40.000 €», que no añadía ninguna zona. Es reversible: una feature nueva, tres métricas nuevas y campos opcionales. Código:
- `hi_features/methods.py` y `compute.py` (`anchored_relative_value`);
- `hi_contracts/catalog/feature.py` (`FitBinding`, rol `price_m2_estimate`);
- `hi_api/services/search.py` (`zone_price`) y `barrios.py`;
- `hi_domain/affordability.py`, `fit.py` y `reality_check.py`;
- la web (`lib/fit.ts`, `RealityCheck.tsx`, `SearchResults.tsx`, `SearchCard.tsx`, `FitDetails.tsx` y «Cómo lo calculamos»).

Evidencia: `evidence/gate-04/2026-11-14/compra-estimada.md`, `golden-search-compra-estimada.txt` (9/9), `casos-compra-estimada.txt`, `evidence/gate-01/2026-11-14/ayto_panel_indicadores_distritos_barrios/` y las capturas de `evidence/gate-06/2026-11-14-buy-estimate/`.
1. **Método** (feature `precio_compra_estimado_m2`, método `anchored_relative_value`).
   - **Fórmula:** €/m² de un distrito = valor tasado de Madrid (4.993,3 €/m², `cm_valor_tasado_vivienda_municipios`) × su valor catastral por m² / la media de los 21 ponderada por sus inmuebles residenciales.
   - **Valor catastral por m²:** el valor catastral medio por inmueble residencial entre su superficie construida media.
   - **Barrios:** se reparten igual a partir de la estimación de su distrito. La media ponderada de los distritos vuelve al valor de la ciudad, y la de los barrios a la de su distrito (test de integración).
   - **Sin datos:** una zona sin valor catastral, sin superficie o sin inmuebles queda `SOURCE_MISSING`, nunca con la media ni con 0.
   - **Resultado:** 21 de 21 distritos (de 2.971 €/m² en Puente de Vallecas a 7.771 en Salamanca) y 131 de 131 barrios (de 2.033 a 9.945).
2. **Fuentes.** El nivel de precio sale del dataset CM del valor tasado; el reparto, del panel de indicadores del Ayuntamiento (complementario, no CM), que ya se cargaba (D-212, D-232).
   - **Indicadores:** el pipeline guarda tres indicadores más del Catastro, en distrito y barrio: valor catastral medio, superficie construida media y número de inmuebles de uso residencial (métricas `valor_catastral_medio_residencial`, `superficie_construida_media_residencial` y `inmuebles_residenciales`).
   - **Gate 1:** parser 1.4.0, mismo fichero (sha `11a758e6`), 5.584 observaciones, 0 en cuarentena y calidad superada.
   - **Cifra de datasets CM:** no cambia.
3. **Siempre dicho como estimación.**
   - **Confidence:** 0,5, que la web enseña como «Dato aproximado».
   - **Texto de la API:** la condición y el hecho dicen «Comprar ≈ 411.000 € por 68 m² (6.051 €/m², precio estimado: valor tasado de Madrid repartido según el valor catastral del distrito; Ministerio de Vivienda y Catastro vía Ayuntamiento)», o «del barrio» en un barrio. El indicador cita los dos datasets.
   - **El valor tasado sigue siendo solo de municipios:** `valor_tasado_vivienda_m2` no se reparte. Ahora también da una fila SIN DATOS a cada barrio, como ya hacía con los distritos.
4. **Validación** frente a los precios de oferta de idealista en 12 distritos. Es un portal privado y solo se usa para validar, nunca como dato. Se puede repetir: la tabla de referencias, con su URL y fechas, está en `evidence/gate-04/2026-11-14/referencias-precio-distritos.csv`, y el cálculo en `scripts/validate_buy_estimate.py`, que falla si el Spearman baja de 0,9 o si un distrito pasa del 30 %.
   - **Orden:** Spearman 0,95.
   - **Nivel:** el estimado es de media 0,88 veces el precio de oferta, lo esperable de una tasación frente a un anuncio.
   - **Error por distrito,** quitada esa diferencia común: entre −19 y +19 %, ninguno por encima del 30 %. El agente anterior informó 0,96 en 13 distritos, pero no dejó la fuente.
   - **Sesgo declarado:** el valor catastral comprime el rango. Los distritos caros quedan algo bajos y los baratos algo altos (Villa de Vallecas, San Blas-Canillejas y Villaverde).
   - **Límites en la feature:** el catastro sale de ponencias antiguas y la superficie construida incluye zonas comunes.
5. **Búsqueda (`fit-0.8`).**
   - **Una sola versión para el lote:** `fit-0.8` es la misma versión de D-240 (días de oficina, teletrabajo y familia) y de D-236; los PR #59, #60 y #62 se despliegan juntos (D-240 §3). Con D-240 juntas:
     - el desempate de «Casi encajan» lee los minutos hasta el primer lugar al que se va (`lead_trip`); después va el coste (D-234) y por último el id;
     - el hueco que D-240 reserva al coste en los hechos (`capped`) lo ocupa el precio estimado al comprar (test).
   - **Rol propio para la estimación:** el valor tasado se enlaza como `fit: {role: price_m2}` y la estimación como `fit: {role: price_m2_estimate}` (revisión del PR #59). Un código que no conoce el rol lo ignora con un aviso en el log, en vez de leerlo como un precio publicado.
   - **Lectura explícita:** `indicators_by_zone` tiene una rama propia para `price_m2_estimate`, que va a `price_estimate` y nunca pisa la publicada, lleguen en el orden que lleguen (test).
   - **Qué precio usa una zona:** `zone_price` toma el valor tasado publicado si lo hay, después la estimación, y si no hay ninguno, la fila que dice por qué. `ZoneData.price_estimated` lleva la nota al texto.
   - **Desempate por coste, solo en «Casi encajan» (`near_miss_key`).** Va después de la confidence y de los minutos al trabajo, y antes del código de zona.
     - **Por qué ahí:** las zonas que se pasan del presupuesto para comprar sacan todas un 0 % en él y empatan en lo demás (misma confidence 0,5 y sin trabajo). Sin el coste decidía el código de zona, y Tetuán (≈ 411.000 €) quedaba fuera de los cinco «casi» con 400.000 €. Con él, los «casi» empiezan por la zona más cercana al tope: Arganzuela (406.000 €), Tetuán, Centro, Retiro y Chamberí.
     - **«Zonas que encajan» sigue la clave de D-239** (servicios cotidianos a pie y sus minutos, después confidence, trabajo e id), sin coste. Si el coste fuera delante, con mucho presupuesto volverían primero los pueblos baratos, que es lo que corrige D-239. Detrás tampoco aporta nada: tras los servicios a pie no queda ningún empate exacto entre las zonas que encajan (comprobado con 400.000 € y 1.000.000 € para comprar, 10.000 €/mes de alquiler y el ejemplo).
     - **El invariante del pitch no cambia:** 27 zonas, Latina 1.ª al 98 %. El golden fija su orden (`ranked_order` y `near_miss_order`, 9/9).
6. **Reality Check.** Una condición limita donde FALLA. Donde es UNKNOWN falta el dato, y ningún cambio de la persona lo arregla.
   - **`binding_constraint`:** solo cuenta los FAIL. Puede ser `null` aunque no cumpla nada, si solo hay zonas sin datos.
   - **`unknown_by_constraint`** (nuevo, opcional): cuántas de las `zones_unknown` tienen cada condición UNKNOWN.
   - **Relajaciones:** no se ofrece relajar una condición que ninguna zona incumple si no añade zonas. Una que sí añade zonas, como quitar el límite de un trayecto sin calcular, se sigue ofreciendo (test).
   - **Web:** con «Comprar» dice el motivo (`rc.sin_dato.compra`: «En 151 zonas no podemos comprobarlo todo: sin precio de compra publicado en 151 municipios (solo lo tienen los de más de 25.000 habitantes)…»). Bajo el presupuesto va `presupuesto.compra.fuente`, y la tarjeta de una zona sin datos lleva `zona.compra.sin_precio`.
   - **Revisión del PR #59 (R-01 y R-03):**
     - La web cuenta como «municipios» solo las zonas de `all_zones` que son municipios, no tienen precio, no fallan nada y no cumplen todo. Si entre ellas hay distritos o barrios, dice «zonas».
     - La tarjeta da el motivo por nivel y solo si la zona no trae precio.
     - La ayuda de «Dato aproximado» ya no dice «El dato es oficial»: «Es una aproximación: la zona tiene poca población, la fuente no está completa o el dato es una estimación. Tómalo como orientativo.»
6b. **El precio de cada zona, a la vista** (ampliación pedida por el coordinador, por la prueba con usuarios del 14 nov: «si tuviera un precio aproximado por zona, se entendería mejor»).
   - **Contrato (aditivo y retrocompatible):** `RankedZone.estimated_cost_confidence` y, en `all_zones` (`ZoneMatch`), `estimated_cost_eur` y `estimated_cost_confidence`. La confidence es la de su precio o su alquiler: 0,5 en la estimación. Sin coste, las dos van a `null`, nunca a 0.
   - **Web:** junto al % de cada fila («Zonas que encajan», «Casi encajan» y los barrios) sale «≈ 385.000 €» o «≈ 1.101 €/mes». Bajo el nombre de la tarjeta de zona sale «Comprar ≈ 385.000 €», para cualquier zona evaluada.
   - **Fiabilidad:** si el precio no es un dato fiable, lleva las mismas palabras que la tarjeta («Dato aproximado»).
   - **Sin precio:** no va nada.
   - **El orden y los % no cambian:** el ejemplo del pitch sigue en 27 zonas con Latina 1.ª al 98 %.
7. **Casos reales** (pareja, API local).
   - **400.000 €:** cumplen 41 zonas: 27 municipios y 14 distritos. Con la clave de D-239, el top 10 son 6 distritos y 4 municipios: Puente de Vallecas, Usera, Carabanchel, Latina, Villaverde, Coslada, Parla, Móstoles, San Blas-Canillejas y Leganés. Tetuán no cumple por poco (≈ 411.000 €) y sale 2.º en «casi».
   - **400.000 € dentro de Tetuán:** cumplen 4 de 6 barrios: Valdeacederas (≈ 348.000 €), Berruguete (≈ 378.000 €), Almenara y Bellas Vistas.
   - **1.000.000 € con trabajo en Cuatro Torres:** cumplen 48 y los 10 primeros son distritos (Chamberí, Tetuán, Chamartín y Fuencarral-El Pardo al 100 %). Con 45 minutos como máximo cumplen 13 y los 10 primeros también son distritos, de Chamberí a Fuencarral-El Pardo.
8. **Despliegue: desplegar → sincronizar → smoke.** Con el rol propio, volver a un despliegue anterior también es seguro tras el sync, sin borrar filas.
   - **Código nuevo con los datos de antes** (desplegado y sin sincronizar): los distritos y barrios salen sin precio. Los textos no los llaman municipios ni prometen una estimación:
     - `rc.sin_dato.compra` cuenta por nivel y dice «zonas»;
     - la tarjeta dice que el valor tasado se publica para Madrid entero, no por distrito;
     - la condición dice lo mismo (`PURCHASE_MISSING_IN_CITY`), nunca «solo municipios de más de 25.000 habitantes».
   - **Código anterior con los datos nuevos** (sync antes de desplegar, o rollback a un despliegue desde `ad4a8f2`): `indicators_by_zone` no conoce `price_m2_estimate` y lo ignora con el aviso «fit bindings ignored by this version». Los distritos siguen UNKNOWN como hoy, y no hace falta borrar filas. Las 131 filas SIN DATOS de barrio del valor tasado y las tres métricas tampoco le molestan.
   - **Corrección de una versión anterior de este texto (R-04):** decía que «nada garantiza ese orden», pero sí lo garantiza: la consulta de la búsqueda ordena por `feature_id`. Con el rol propio, ese orden ya no importa.
   - **Tablas del sync** (`make supabase-sync PROFILE=demo` copia las tablas enteras):
     - `metric_registry`: 3 filas nuevas;
     - `feature_registry`: 1 fila nueva y 1 cambiada (fuentes y nivel barrio del valor tasado);
     - `feature_value`: 283 filas más (152 de la estimación y 131 SIN DATOS de barrio del valor tasado);
     - `dataset_version`: la versión del panel cambia a parser 1.4.0.
     - Las 3.192 observaciones nuevas de `metric_observation` solo van con `PROFILE=full`; la API no las lee.
   - **Recalcular en `housing`:** los comandos están en el PR (catálogo, panel y las dos features).
9. **Resuelto por D-239.** Antes de D-239, sin trabajo ni prioridades y comprando con 400.000 €, los 10 primeros eran municipios al 100 %: el precio publicado (confidence 0,8) desempataba antes que el estimado (0,5). Con los servicios a pie por delante de la confidence, suben los distritos (6 de 10, ver §7).

## D-236 — Ocio: bares, restaurantes, gimnasios y cultura de OpenStreetMap, que solo puntúan si la persona marca «Ocio» (2026-11-14)
Motivo: feedback de usuarios de prueba. Antes de mudarse miran qué ocio tienen cerca, y una persona de entre 40 y 50 años echó en falta la cultura («museos, etc.») como algo que le importa. Encargo aprobado por Mariano, con el mismo modelo que las zonas verdes (D-222). Aditivo y reversible: un dataset complementario (`osm_ocio`), un tipo de pipeline (`osm_pois`), 4 features y una prioridad. Código: `hi_ingestion/pipelines/osm_pois/`, `hi_domain/fit.py` (`leisure_fact`, `fit-0.8`), `apps/web/src/components/search/LeisureField.tsx`, `apps/web/src/lib/map/facilities.ts`. Evidencia: `evidence/gate-01/2026-11-14/ocio.md`, `evidence/gate-03/2026-11-14/ocio-features.md`, `evidence/gate-04/2026-11-14/ocio-invariante.md`, `evidence/gate-06/2026-11-14-leisure/`.
1. **Fuente y licencia.** El mismo extracto de OpenStreetMap (Geofabrik) que la red peatonal (D-210) y los parques (D-222), bajo **ODbL**: lo derivado cita «© OpenStreetMap contributors» (el mapa ya lo muestra). Fuente complementaria: no cuenta como dato CM. El portal de la Comunidad no publica un censo con coordenadas de bares, restaurantes, gimnasios, cines ni museos de toda la región. Sí publica el directorio de bibliotecas (sin coordenadas) y los museos por municipio (tabla 1923960): se usan para **validar** la cobertura de cultura (§3), no se cargan.
2. **Grupos y etiquetas** (`data/catalog/pipelines/osm_ocio.yaml`; nodos y áreas no cerrados al público, `access` ≠ `no`/`private`; de cada local solo nombre, punto y etiqueta):
   - **Bares y cafeterías:** `amenity=bar`, `pub` y `cafe`.
   - **Restaurantes:** `amenity=restaurant`. La comida rápida (`fast_food`) no cuenta.
   - **Gimnasios y deporte:** `leisure=fitness_centre` y `sports_centre` (polideportivos municipales incluidos).
   - **Cultura:** `tourism=museum`, `amenity=library`, `theatre`, `cinema` y `arts_centre`. Era «Cines y teatros» (cines, teatros y centros culturales) hasta el feedback de la cultura: museos y bibliotecas entraron el mismo día, antes de publicarse nada.
   - Resultado del 14 nov (parser `osm-pois-1.2.0`): 16.493 locales; 6.197 bares y cafeterías, 7.670 restaurantes, 1.738 gimnasios y centros deportivos y 888 de cultura (195 museos, 260 bibliotecas, 259 teatros, 76 cines y 98 centros culturales). 971 sin nombre en OSM («Bar sin nombre»). Quality Gate: entre 8.000 y 60.000 locales, ids únicos, todas las etiquetas con algún local y menos del 2 % en cuarentena.
   - Un local con dos etiquetas toma la primera del catálogo, que pone la cultura delante del deporte y del comer y beber: un museo con cafetería es museo. Un nodo dibujado dentro del área del mismo local (misma etiqueta y nombre, a 50 m o menos) cuenta una vez y se queda el área: 14 nodos fuera.
3. **Cobertura.** OSM lo mantienen voluntarios y en los pueblos pequeños faltan locales.
   - Municipios con algún local: el 100 % de los de más de 20.000 habitantes tiene bares, restaurantes y gimnasios; de los de menos de 1.000, solo el 50 % tiene algún bar y el 24 % algo de cultura en OSM.
   - Contra la CM: 77 de los 97 municipios con biblioteca pública según su directorio tienen alguna en OSM (86–100 % por encima de 5.000 habitantes, 35 % entre 1.000 y 5.000). 32 de los 54 municipios con museo según la tabla de la CM tienen alguno en OSM; Madrid, 109 según la CM y 99 en OSM.
   - Tampoco es perfecto en ciudades: Parla tiene 13 bares y cafeterías en OSM. Un tiempo largo puede querer decir «no está en el mapa», no «no hay». La web lo dice («en los pueblos pequeños puede faltar algún local») y cada feature lo declara en `limitations`.
4. **Features** (`min_a_pie_bar`, `min_a_pie_restaurante`, `min_a_pie_gimnasio`, `min_a_pie_cultura`): minutos a pie hasta el local más cercano de cada grupo, con el método, la velocidad (4 km/h), las calles de origen, las reglas de nulos y los niveles de `min_a_pie_parque` (sección, municipio, distrito, barrio y región). Un local cuenta en un solo grupo (test de catálogo). Centro: bar 0,7 min, restaurante 0,6, gimnasio 3,7, cultura 2,3; Patones: 86, 69, 122 y 81. Mediana regional: 10,3, 8,4, 11,8 y 18,9 min.
5. **En el buscador (`fit-0.8`): solo puntúa si la persona marca «Ocio».**
   - «Ocio» es una prioridad de «Me importa» (`PriorityKey.OCIO`). Al marcarla se abre un configurador: una casilla por grupo y «A [5/10/15] min andando como mucho», común a todas. Empieza con bares y cafeterías y restaurantes. Cada casilla marcada viaja en `nearby` como una necesidad (`NeedKey.BARES`, `RESTAURANTES`, `GIMNASIOS`, `CULTURA`).
   - Es **un solo criterio** para todos sus grupos, en el puesto en que se marcó: cuatro casillas nunca pesan más que las otras prioridades. Su utilidad es la media de los grupos con dato, cada uno contra sus minutos (1 hasta la ventana, 0 al triple). Un grupo sin dato baja la confianza, nunca la nota. Un local a más del triple de la ventana puntúa 0 con confianza ≤ 0,5 (en un pueblo, OSM puede no tenerlo). Un hecho: «Ocio a pie: bares y cafeterías a unos 3 min, restaurantes a unos 4 min, cultura a unos 11 min».
   - **«Imprescindible» empieza sin marcar**: «Me importa» ordena, no filtra, y con la cobertura de §3 un filtro por defecto echaría pueblos por locales sin mapear. Marcado, cada grupo es una condición `near:<grupo>` (PASS/FAIL/UNKNOWN, se puede relajar como las demás).
   - Sin la prioridad marcada, el ocio no existe para la búsqueda: con «Ocio» y ninguna casilla no se mide nada, y una búsqueda sin ocio da lo mismo con y sin los datos (test). Los grupos no son filas de «Qué falta» ni entran en los hechos de contexto.
   - **Grupos de ocio sin la prioridad `ocio`.** Pueden llegar desde la API o el MCP. Se ignoran (`hi_domain.fit.ignored_leisure`): no son criterio ni condición, y la respuesta lo avisa con un `warnings` `INVALID_PROFILE`. Con `required` a `True` por defecto, si no, filtrarían zonas por locales que OSM puede no tener. Lo dice el docstring de `NeedKey` y tiene tests (dominio y API).
   - **El tipo del hecho sale solo de los grupos con dato.** Es punto fuerte si todos los que tienen dato están dentro de sus minutos; un grupo sin dato no lo convierte en punto débil.
   - **En el Reality Check, los grupos se relajan juntos** («+5 min a pie hasta el ocio» y, al tope, «Ocio cerca como preferencia, no como requisito»), porque en la web comparten minutos e «Imprescindible». Sale una sola opción, no una por casilla. La condición de gimnasios se llama «Gimnasios y deporte», como la casilla.
   - **El desempate de D-239 nunca lee el ocio.** `EVERYDAY_NEEDS` son los 6 servicios cotidianos (escuela infantil, colegio, centro de salud, farmacia, mayores y transporte), no `tuple(NeedKey)`. Con los 4 grupos dentro, la pareja con 10.000 €/mes y sin prioridades tenía Centro como primera en vez de Chamberí.
     - Test: dos zonas empatadas que solo difieren en ocio conservan su orden, y cada `NeedKey` es cotidiano o de ocio.
     - Golden: ese caso con el top 10 de D-239, 10 de 10 OK con y sin datos de ocio (`evidence/gate-04/2026-11-14/golden-search-ocio.txt`).
   - `indicators_by_zone` (API) lee los cuatro grupos como necesidades a pie, igual que el colegio, y solo acepta un `fit` con `priority` para las prioridades que se miden andando a un lugar propio (zonas verdes, sin escaleras). Un `fit` atado a `ocio` o a `seguridad` se ignora con el aviso de cualquier enlace desconocido (test).
6. **En la web.**
   - El chip «Ocio» (icono `Wine`) solo sale cuando `osm_ocio` está en `GET /datasets`.
   - En «Todos los centros» de la vista de zona hay 4 tipos más: «Bares y cafeterías», «Restaurantes», «Gimnasios y deporte» y «Cultura».
     - Comparten un color en el mapa (`--fac-ocio`) y salen cuando `osm_ocio` está en `/datasets`.
     - **No van en la petición única de `/places` de la zona.** Cada tipo se pide aparte al pulsar su botón, y «Todos» solo enciende los 7 servicios.
     - Medido en Centro: la petición de la zona pasa de 2.862 lugares (1,12 MB) a 179 (76 KB). «Cultura» se pide al pulsarla: 133 lugares, 53 KB.
     - Con 0 locales, el recuento dice lo que falta en el mapa, no en la zona: «OpenStreetMap no tiene ningún bar ni cafetería en Patones».
     - Bajo cada recuento va «Según OpenStreetMap, un mapa hecho por voluntarios: puede faltar algún local o salir sin nombre».
   - Textos en `pitch/textos_web.md` (`importa.ocio*`, `hecho.ocio*`, `centros.recuento.*`).
7. **Invariante del pitch** (rehecho con el código fusionado sobre `d5fe735`: D-238, D-239 y el lote 2b, `fit-0.8`). El ejemplo de la web, sin ocio, da lo mismo que producción: 27 zonas; Latina, Moratalaz, Ciudad Lineal y Puente de Vallecas al 98 %; el mismo top 10; y «Casi encajan» en el mismo orden (Chamartín, Salamanca, Centro, Chamberí, Retiro). La respuesta entera es igual salvo `datasets`, que añade `osm_ocio`: la lista cita los datasets de todas las features que lee la búsqueda, como ya hacía con `osm_parques`. El caso de 10.000 €/mes da el top 10 de D-239 en local y en producción.
8. **Despliegue y sync: desplegar → sincronizar → smoke.**
   - **Desplegar primero es seguro.** Sin `osm_ocio` en la base, la web no ofrece el chip «Ocio» ni los tipos de ocio, y la búsqueda no cambia.
   - **Vuelta atrás con las filas ya sincronizadas.**
     - A `ad4a8f2` o posterior es seguro: `indicators_by_zone` ignora los enlaces `need: bares|restaurantes|gimnasios|cultura` que no conoce, con el aviso de D-233, y esa web ni pide ni enseña el ocio.
     - A un despliegue anterior a `ad4a8f2` hay que retirar antes estas filas y las 2 de D-233: ese código manda cualquier rol desconocido al caso «prioridad a pie» y `/search` da 500.
   - **Tablas que sincronizar** (`make supabase-sync PROFILE=demo` copia las tablas enteras desde `housing`):
     - `dataset_registry`: 1 fila nueva, `osm_ocio`;
     - `dataset_version`: 1 fila;
     - `place_master`: +16.493 filas de `osm_ocio`;
     - `feature_registry`: 4 filas;
     - `feature_value`: +19.896 filas (4.974 por feature).
   - **Retirar las filas:**
     - Borrar las 4 de `feature_registry` (`min_a_pie_bar`, `min_a_pie_restaurante`, `min_a_pie_gimnasio`, `min_a_pie_cultura`); las de `feature_value` caen por CASCADE.
     - Después, los lugares de `place_master` con `official_dataset_id = 'osm_ocio'`, la fila de `dataset_version` y la de `dataset_registry`.
     - Para volver antes de `ad4a8f2`, también las 2 filas de `feature_registry` de D-233 (`min_a_pie_bus`, `min_a_pie_metro`).
   - **Cálculo en la base principal** (`housing`), desde la raíz del repo, con el mismo extracto que la red peatonal:
     ```bash
     export DATABASE_URL=postgresql+psycopg://housing:housing@localhost:5440/housing
     uv run hi-ingest catalog sync
     uv run hi-ingest run osm_ocio --local data/bronze/datasets/osm_red_peatonal/e6fa128706ac/madrid-latest.osm.pbf
     uv run hi-features compute --feature min_a_pie_bar --feature min_a_pie_restaurante --feature min_a_pie_gimnasio --feature min_a_pie_cultura
     ```

## D-237 — «Entorno» de la zona: ruido de la calle, calidad del aire y aparcamientos, como contexto que no puntúa (2026-11-14)
Viene de la prueba con usuarios del 14 nov: «pensando en comprar una casa, el ruido también importa», «facilidad de aparcar», «parking público». La calidad del aire la aprobó Mariano el mismo día.

Es aditiva y reversible: nueve datasets, cuatro features sin `fit` ni `gap_row`, campos opcionales en la API y un bloque nuevo en la vista de zona. El buscador y «Qué falta» no cambian.

Revisada en el PR #65 (R-01 a R-14). Evidencia:
- `evidence/gate-01/2026-11-14/`: Gate 1 de los nueve;
- `evidence/gate-06/2026-11-14-environment/`: capturas, buscador dorado y contraste del ruido.
1. **Fuentes y licencias.**
   - **Ruido:** Mapa Estratégico de Ruido 2021 del Ayuntamiento de Madrid (`ayto_mapa_estrategico_ruido_2021`).
     - Está en el Geoportal (geoportal.madrid.es), no en datos.madrid.es. Su ficha enlaza CC BY 4.0 (fuente nueva `ayuntamiento_madrid_geoportal`, leída el 14 nov).
     - Es un ráster de 5 m en EPSG:25830 con el ruido del tráfico rodado calculado a 4 m de altura (CNOSSOS-EU).
     - Del ZIP (44 MB, cuatro GeoTIFF de 184 MB) se guardan Ld y Ln como una rejilla compacta en Silver (16 MB).
     - El ZIP se queda en Bronze (CLAUDE.md §15, R-12). A la base solo llegan los indicadores.
   - **Aparcamientos:**
     - Los de disuasión del CRTM (`crtm_aparcamientos_disuasion`): ficha `aparcamientos_disuasion` del portal de la Comunidad, licencia CRTM-LDA. Cuenta como dato CM (D-196).
       - Entran los 71, en 30 municipios: 31.692 plazas, 63 gratuitos.
       - `IDFEMPLAZAMIENTO` se repite en 17 pares de aparcamientos distintos, así que la clave es `FID`.
     - Los del Ayuntamiento (`ayto_aparcamientos_publicos` y `ayto_aparcamientos_residentes`, datos.madrid.es, CC BY 4.0): 21 públicos y disuasorios municipales, y 273 mixtos y de residentes.
       - El tipo sale del principio del nombre.
       - Los cerrados no entran y los mixtos van una sola vez.
     - **Duplicados (R-10):** Aviación Española y Estadio Metropolitano los publican los dos. Se quedan las filas del CRTM, que traen plazas y si son de pago, y se excluyen las del Ayuntamiento (`exclude_patterns`). Están a 12 m y 126 m.
     - La atribución del CRTM nombra ahora los aparcamientos: «en bruto», las plazas; «explotados», los minutos.
   - **Aire (NO₂ de 2025):**
     - Red de la Comunidad, tres fichas del portal CM (CC BY 4.0):
       - estaciones (`cm_calidad_aire_estaciones`, 28);
       - datos horarios de 2025 (`cm_calidad_aire_horario_2025`);
       - municipios por zonas de calidad del aire (`cm_calidad_aire_zonas`, 7 zonas y 179 municipios).
     - Madrid capital, red del Ayuntamiento (datos.madrid.es, CC BY 4.0):
       - estaciones (`ayto_calidad_aire_estaciones`, 24, de ellas 23 con NO₂);
       - datos horarios «desde 2025» (`ayto_calidad_aire_horario`), de los que se lee solo 2025. El nombre del fichero cambia cada día, pero la URL del recurso responde con cualquier nombre.
     - Media anual por estación con las horas marcadas `V`. Un valor marcado válido sin número va a cuarentena.
     - Comprobado contra el investigador: Getafe 25,6, Leganés 29,5, Coslada 27,1 y Rascafría 1,6 µg/m³.
   - Entran 4 conjuntos CM más. Con la base del 14 nov, `/datasets` da 51, de ellos 35 CM.
2. **Umbrales.**
   - **Ruido (R-02, R-03):**
     - Qué se cuenta: % de la longitud de calle residencial por encima de **65 dB Ld** (día, de 7 a 19 h) y de **55 dB Ln** (noche, de 23 a 7 h). Son los objetivos de calidad acústica de las zonas residenciales del RD 1367/2007 (anexo II, tabla A). La OMS se cita solo como referencia.
     - Qué calles: las mismas que los minutos a pie (residencial, de convivencia, sin clasificar, peatonal y terciaria).
     - Cómo se lee: cada 10 m a lo largo de cada tramo, ponderado por su longitud. Nunca solo en los nodos: un nodo es un cruce, donde suma el tráfico de dos calles.
     - Contraste en `ruido-contraste.md`. Chamberí pasa de 77,5 % (Lden en los nodos) a 42,4 % de día, y Usera de 28,5 % a 14,1 %. Es el nivel calculado en la calle, no en la fachada, así que sigue muy por encima de los vecinos expuestos de la tabla 7 de la memoria (Chamberí, 6,9 %; Usera, 3,3 %).
     - La web dice «Calles con ruido alto: X % de las calles de día, Y % de noche» y «calculado», nunca «medido» ni «vecinos» (R-07). La ayuda y «Cómo lo calculamos» explican que no es el % de vecinos.
   - **Aire (R-08):** el texto da la media con «(límite UE: 40; 20 desde 2030)». El 40 es el límite de la Directiva 2008/50/CE y el 20, el de la Directiva (UE) 2024/2881 desde 2030.
     - Dice «estación de tráfico» cuando lo es.
     - Una estación cuenta si tiene un 85 % de horas válidas: el 90 % de la Directiva 2008/50/CE (anexo I) menos calibración y mantenimiento.
   - **Aparcamiento:** por encima de 30 min andando, la web no da minutos: dice que ninguno de los publicados en abierto está a menos.
3. **Asignación de la estación.**
   - Un municipio, distrito o barrio con estación propia usa la suya. Si tiene varias, la más cercana al centro de sus calles residenciales.
   - Sin estación propia, usa **la más cercana de su misma zona de calidad del aire** de la Comunidad (Madrid es la zona 1 y solo usa la red del Ayuntamiento). Dentro de la zona, **una de fondo antes que una de tráfico** (R-08): una estación prestada de tráfico mide una avenida de otra zona.
     - Usera toma Méndez Álvaro (21,2 µg/m³, a 2,7 km) y no Plaza Elíptica (tráfico).
     - Tetuán toma Tres Olivos y no Plaza Castilla.
     - Acebeda toma El Atazar (23,5 km).
   - La zona de cada municipio sale de la ficha CM por nombre. Si falla, se prueba sin artículo o con la primera parte de un nombre doble, y solo vale si señala un único municipio. Cubre 179 de 179.
   - El valor siempre va con su estación. `detail` de `GET /features/no2_media_anual/values` trae `station`, `station_code`, `own`, `distance_km` y `traffic`, en el mismo `FeatureValueDetail` que D-241.
   - Confidence: 0,9 con estación propia y 0,6 con la de otra zona.
   - 16 de los 21 distritos tienen estación propia (4 de tráfico).
4. **Cobertura.**
   - **Ruido:** solo Madrid capital (la ciudad, 21 distritos y 131 barrios). En el resto, `SOURCE_NO_COVERAGE` y «sin dato publicado», nunca 0.
   - **Aire:** los 179 municipios, los 246 distritos de la geografía y los 131 barrios.
   - **Aparcamiento:** los minutos salen para todas las zonas. La facilidad de aparcar en la calle no tiene dato abierto: no se inventa y se dice.
   - **Botón «Aparcamientos»** en «Todos los centros»:
     - solo sale cuando `/datasets` trae sus datasets, para que no haya un 0 falso antes del sync (R-05);
     - «Todos» no lo enciende, porque es contexto (R-06);
     - sigue en la petición de la zona, porque el bloque «Entorno» lo necesita.
5. **Por qué no puntúa.**
   - El ruido mide la calle y no la vivienda, y solo existe en una de cada 179 zonas.
   - El aire de una sola estación por zona no distingue una calle tranquila de una avenida.
   - Los aparcamientos publicados son solo una parte de los que hay.
   - Como la seguridad percibida (D-224, D-226) y el contexto de D-235, son contexto: `context_only`, sin `fit` ni `gap_row` (tests de `tests/data`). `search.indicators_by_zone` nunca los lee.
6. **API (aditiva).**
   - `GET /features/{id}/values` trae `detail` (`FeatureValueDetail`, el mismo de D-241) con los campos de la estación.
   - `/places` (`places-1`) añade `access_fee` (`free`, `paid` o `mixed`, del `PAGO` del CRTM) y las plazas del CRTM como `capacity` («plazas»).
   - Parser `places-1.8.1`: tipo por prefijo del nombre, filas fuera por patrón y aparcamientos deduplicados de nuevo.
7. **Web.**
   - Bloque «Entorno» en la vista de municipio, distrito o barrio, debajo de «Vivienda nueva y lo que viene» (D-241), con los textos `zona.entorno.*` de `pitch/textos_web.md`.
   - Tipo «Aparcamientos» en «Todos los centros», con contador, color propio (`--fac-aparcamiento`, AA) y lista con plazas y si es gratuito.
   - Las estaciones de calidad del aire son lugares `other` que no salen en «Todos los centros».
8. **Desplegar → sincronizar → smoke (R-09).**
   - Primero el código, luego `make supabase-sync PROFILE=demo` y después el smoke con `/search`.
   - **Se puede volver a un despliegue anterior sin romper nada.** El código anterior no lee estas features (no tienen `fit` ni `gap_row`) ni pide la categoría `other` a `/places`, y los campos nuevos de la API son opcionales.
   - Lo único que quedaría mal es el contador y la lista de fuentes, que citarían datos que la pantalla anterior no enseña. Para evitarlo, se retiran por `official_dataset_id` y `dataset_id`, nunca por categoría (en `other` puede haber más cosas):
     - los lugares de los 5 datasets de lugares: `crtm_aparcamientos_disuasion`, `ayto_aparcamientos_publicos`, `ayto_aparcamientos_residentes`, `cm_calidad_aire_estaciones` y `ayto_calidad_aire_estaciones`;
     - los `feature_value` y `feature_registry` de las 4 features;
     - los 9 datasets de `dataset_registry` y `dataset_version`, y la fuente `ayuntamiento_madrid_geoportal`.
9. **Segunda revisión del PR #65** (lista, con mejoras opcionales). R-11, R-13, R-14 y R-15 de la primera eran solo informativos: no queda nada pendiente de ellos. Además:
   - «Todos» no enciende «Aparcamientos», pero tampoco lo apaga si ya estaba encendido, igual que el ocio (`allServicesOn`).
   - Un disuasorio que no publica si es gratuito nunca cuenta como de pago. Con la misma regla que las plazas, «(N gratuitos)» solo sale si todos lo publican; si no, «de N no consta si es gratuito». Por ejemplo, Fuencarral-El Pardo tiene tres del CRTM gratuitos y Pitis, del Ayuntamiento, sin dato.

## D-238 — «¿Dónde?»: toda la Comunidad, Madrid capital por barrios, alrededores o pueblos (2026-11-14)
Decisión de Mariano (14 nov) tras la prueba con usuarios: cuatro personas pidieron buscar solo en una parte de la región. Es aditiva y reversible: un campo opcional del escenario, sin datos nuevos ni cambio de método (`fit-0.7` no cambia).
1. **Criterio y fuente.** Las tres partes agrupan las 11 zonas estadísticas (NUTS 4) del Instituto de Estadística de la Comunidad de Madrid:
   - «Madrid capital» es la zona 01 (Municipio de Madrid);
   - «Alrededores de Madrid», las cuatro metropolitanas (02 Norte, 03 Este, 04 Sur y 05 Oeste Metropolitano): 40 municipios;
   - «Pueblos», las otras seis (Sierra Norte, Nordeste, Sudeste, Sudoeste, Sierra Sur y Sierra Central): 138 municipios.
   - Fuente: «Nomenclátor imprimible de la Comunidad de Madrid. 2025», §3.4 «Zonificación estadística y relación de municipios» (https://gestiona3.madrid.org/iestadis/fijas/estructu/general/territorio/descarga/nomenme25.pdf), consultado el 14 nov. La tabla de 2010 del mismo Instituto pone los mismos municipios en cada zona.
   - Por qué esta: es oficial y de la Comunidad, cubre los 179 municipios sin huecos ni solapes y es la que usa el Instituto en sus propias tablas. Se descartan las coronas del Consorcio de Transportes, que son zonas de tarifa, y un radio en kilómetros, que sería un criterio nuestro.
   - Se declara una consecuencia: Aranjuez, Ciempozuelos y Valdemoro son «alrededores» (Sur Metropolitano), y Meco o Villalbilla, «pueblos». Es la zonificación del Instituto, no la nuestra.
2. **Mapeo estático versionado.** `data/catalog/zoning/search_scope.yaml` copia la tabla tal como se publica (código de la Comunidad y nombre de los 179 municipios) con su fuente. Está comprobada municipio a municipio contra el PDF: 179 de 179, misma zona y mismo nombre. El código de la Comunidad pasa a INE con `ine_municipality_from_cm`, y los 179 municipios de la base están en el mapeo, sin ninguno de más ni de menos.
   - La imagen de la API no lleva `data/`, así que `scripts/export_search_scope.py` genera `hi_domain/geo/zoning_data.py`.
   - `make lint`, la CI y `tests/data` comprueban que el módulo generado está al día.
3. **Contrato.** `ScenarioState.scope` (`SearchScope`: `all`, `madrid`, `alrededores`, `pueblos`) es opcional y vale `all` por defecto. Esquemas JSON y tipos de la web regenerados (`make schemas`, `npm run -w apps/web contracts`).
4. **Búsqueda** (`hi_api/services/scope.py`).
   - `all` es la de siempre: municipios, y Madrid por distritos.
   - `alrededores` y `pueblos` dejan solo sus municipios.
   - `madrid` ordena los 131 barrios de la capital en lugar de los 21 distritos, con lo mismo que `/search/barrios` (D-232): `load_barrios` sin distrito, los mismos `FIT_VALUES` e `indicators_by_zone`, y el trayecto del distrito para el barrio que no tiene el suyo (D-232 §5).
   - El Reality Check conserva el ámbito en `relaxed_scenario`. «Qué falta» sigue por distrito: `gap_highlights` va vacío en los barrios. La explicación del MCP mira toda la región, donde sea que buscó la persona.
5. **Por qué barrios en la capital.** Con 21 distritos la capital diferencia poco: en el caso del ejemplo, los cuatro primeros empatan al 98 %. Es la fase 2 del diseño de D-232, que quedó fuera («los 131 barrios en el ranking»), acotada a «Madrid capital». Los barrios ya tienen indicadores, trayectos y nombres oficiales. En «Toda la Comunidad», Madrid sigue por distritos, para no comparar barrios con municipios enteros.
6. **Retrocompatibilidad.** La web omite `scope` con «Toda la Comunidad», así que el ejemplo, los enlaces compartidos y la API desplegada siguen igual.
   - **Eco del ámbito.** La API devuelve siempre `scope` (con `all` si no se envió) en cada escenario que repite: `SearchResult.scenario`, cada `relaxed_scenario` del Reality Check, `BarrioSearchResult.scenario` y `ZoneExplanation.scenario`. La web lo quita antes de reenviar. Al aplicar una opción de «¿Y si cambias algo?» quita el `all`. En «Los barrios que mejor encajan» no envía el ámbito, porque el distrito ya dice dónde buscar.
   - **Comprobado contra producción** con el caso del ejemplo: 27 zonas; Latina, Moratalaz, Ciudad Lineal y Puente de Vallecas al 98 %, y el mismo top 10. También son idénticos los hechos, `all_zones`, los «casi» y las opciones. La única diferencia es ese eco de `scope`. Vuelto a comprobar tras D-239 (PR #56): mismo orden de `results` y de `near_misses`.
   - No hay datos nuevos que sincronizar: basta el despliegue.
7. **Web.**
   - Selector «¿Dónde?» al principio de «Tu búsqueda», con radios nativos en 2 × 2.
   - Con «Madrid capital», el mapa pide los contornos de los 131 barrios (unos 90 KB, simplificados como los distritos) y los pinta con su encaje en lugar de los distritos. Las zonas fuera del ámbito quedan sin pintar.
   - La lista y la tarjeta dicen «Lucero · Latina»: el distrito sale de las 7 primeras cifras del código del barrio.
   - La tarjeta de un barrio enseña el «Qué falta» de su distrito, con el aviso de que es del distrito entero, y lleva a la vista del distrito.
   - Textos en `pitch/textos_web.md` (`donde.*`, `resultados.de.*`, `zona.barrio.*`, `mapa.aria.encaje.barrios`). Capturas en `evidence/gate-06/2026-11-14-scope-barrios/`.
8. **Pruebas reales** (base local, solo lectura).
   - **Ejemplo con «Madrid capital»:** 131 barrios, 78 cumplen todo. Lucero y Campamento (Latina) al 99 %; Media Legua y Vinateros (Moratalaz), Atalaya y Costillares (Ciudad Lineal), Pinar del Rey (Hortaleza), Los Cármenes (Latina), Numancia y San Diego (Puente de Vallecas) al 98 %. Son barrios de los distritos que encabezan la búsqueda por distritos. Sol sale sin datos porque no tiene alquiler (D-232 §4).
   - **Pareja, alquiler hasta 10.000 €, transporte y salud, «Madrid capital»:** 130 de 131 cumplen y 106 empatan al 100 %, porque el transporte y el centro de salud quedan a un paseo en casi toda la capital. Con el desempate de D-239 (servicios a pie), arriba quedan barrios muy servidos: Almendrales, Embajadores, Gaztambide, Trafalgar, Argüelles, Arapiles, Lista, Prosperidad, Guindalera y Chopera. La lista avisa: «Encajan 106 barrios igual de bien…» (`resultados.empate`).
   - **La misma pareja en «Alrededores de Madrid»:** 40 municipios, 34 cumplen. Móstoles, Parla, Torrejón de Ardoz, Alcalá de Henares, Alcorcón, Leganés, Coslada y Fuenlabrada al 100 %, Getafe al 99 % y Collado Villalba al 98 %. Los 6 restantes salen sin datos de alquiler.
   - **En «Pueblos»:** 138 municipios y solo 2 cumplen (Navalcarnero al 94 % y Arroyomolinos al 90 %), porque 136 no tienen alquiler publicado y su presupuesto sale UNKNOWN (D-214). Sin límite de presupuesto entran los 138.
9. **Comprar en un barrio** sale UNKNOWN, como en los distritos, hasta que llegue el precio de compra estimado de D-234.
10. **Revisión del PR #58.** No hubo bloqueantes. Se cambió lo siguiente:
    - **«Pueblos» con alquiler** ya no parece un fallo. La ayuda del selector avisa de que casi ningún pueblo publica su alquiler. Bajo el resultado sale cuántos pueblos dan «Sin datos» y por qué: la Comunidad solo publica el alquiler de los municipios de más de 20.000 habitantes, que son 37 de 179. La tarjeta de un municipio sin alquiler lo dice como posibilidad, igual que con «Comprar».
    - **«Lo que más limita tu búsqueda».** `binding_constraint` cuenta como excluida toda zona donde la condición no es PASS, también si es UNKNOWN (semántica de la API, sin cambio). La web solo nombra esa condición si sus FAIL son al menos tantos como las zonas sin datos. Así, con un presupuesto de alquiler que no falla en ningún pueblo, ya no dice «Alquiler». En el ejemplo sigue saliendo «Colegio…» (151 FAIL frente a 15 sin datos).
    - **Las palabras siguen al ámbito:** «salen 78 barrios», «salen 2 pueblos», «Encajan 106 barrios igual de bien», «El 1.º que más encaja».
    - **Una zona fuera del ámbito** dice en su tarjeta «Fuera de tu búsqueda (Madrid capital).».
    - **Si fallan los contornos de los barrios**, la leyenda lo dice con «Reintentar», y la siguiente búsqueda por barrios los vuelve a pedir.
    - **Al pasar el mapa de barrios a distritos**, el barrio elegido se convierte en su distrito. Al pasar de distritos a barrios, el distrito elegido se suelta.
    - **Otros cambios:** la ayuda del selector va en `aria-describedby`; la herramienta MCP `buscar_zonas` explica `scope` y que `explicar_zona` no explica barrios; y `==` en lugar de `is` con `SearchScope`.

## D-239 — Desempate del ranking por servicios a pie y hospitales públicos o privados (2026-11-14)
Feedback de usuarios de prueba del 14 nov: con mucho presupuesto el buscador recomienda «siempre pueblos y en el mismo orden», y no se distinguen los hospitales públicos de los privados. Dos cambios pequeños y reversibles, sin tocar la puntuación (`fit-0.7` no cambia de versión). Evidencia: `evidence/gate-06/2026-11-14-tiebreak-hospitals/`.

**A. Desempate en «Zonas que encajan» (`hi_domain.fit.ranking_key`, `everyday_walk`).**
1. **Causa.** El orden ya usaba el encaje sin redondear, no el %. El empate es real: cada utilidad satura en 1,0 (el coste por debajo del 75 % del presupuesto, cada servicio dentro de su ventana), así que con 10.000 €/mes y nada marcado las 57 zonas que encajan tienen exactamente 1,0. Entre empatadas decidían la confianza (la del alquiler: 1,0 en los municipios y 0,8 en los distritos de Madrid), de ahí «siempre pueblos», y después el id de la zona. Ese id lleva el código INE, y los códigos INE de los municipios siguen el orden alfabético: de ahí «Alcalá de Henares, Alcobendas, Alcorcón, Algete, Aranjuez…».
2. **Regla nueva, solo para empates exactos del encaje sin redondear y solo en «Zonas que encajan».** A igualdad, primero la zona con más servicios cotidianos a un paseo: la media de las utilidades a pie de los seis servicios que mide el buscador (escuela infantil, colegio, centro de salud, farmacia, centro de mayores y transporte), cada uno con su ventana por defecto (D-210), los haya marcado la persona o no. Si también empatan (todo dentro de su ventana), la que los tiene más cerca: menos minutos de media, con el tope de 60 por servicio. Después, como antes: más confianza, menos minutos al primer sitio de trabajo y el id.
   - Es neutral: no añade ningún criterio que la persona no haya pedido al %; solo ordena lo que el % deja igual. Y se explica en una frase: «a igualdad, primero donde hay más cosas a un paseo».
   - Solo cuentan los servicios con dato en la zona; una zona sin ninguno va detrás de las empatadas que sí lo tienen. No es un 0 en la puntuación: es solo el orden del empate.
   - Va delante de la confianza: entre zonas al 100 % la confianza difería (1,0 frente a 0,8, o en milésimas) y decidía el orden sin decir nada a la persona.
   - **«Casi encajan» conserva su orden (`near_miss_key`):** todas fallan algo y, si empatan, manda la confianza del dato, como hasta ahora (D-220). Los servicios a pie no las reordenan.
   - Vale igual para los barrios de un distrito (`/search/barrios` usa las mismas dos claves).
3. **Alternativas descartadas:**
   - ordenar las empatadas por población o por alquiler: introduce una preferencia que nadie pidió («más grande» o «más barato» no es «mejor»);
   - bajar la saturación para que no haya empates: cambia la puntuación y el pitch;
   - orden aleatorio: el mismo caso daría listas distintas;
   - aplicar el desempate también a «Casi encajan»: cambiaba el orden de las cinco del ejemplo al 93 % (Chamberí primera en vez de Chamartín), que cita el guion, y el de los barrios que casi encajan en 5 distritos;
   - poner los servicios a pie detrás de la confianza, o justo antes del id: conserva el ejemplo, pero con mucho presupuesto siguen saliendo primero los municipios, por la confianza del alquiler.
4. **Web (`resultados.empate`).** Si más de 10 zonas que cumplen todo tienen el mismo % que la primera, la lista avisa: «Encajan N zonas igual de bien: marca qué te importa o dónde trabajas para afinar el orden.». Se calcula en la web con `all_zones`: no cambia el contrato.
5. **Invariante del pitch, comprobado el 14 nov.** API de esta rama sobre la base local (solo lectura) frente a la respuesta de producción con el caso del ejemplo:
   - 27 zonas que encajan y 15 sin dato;
   - top 10 idéntico: Latina 98, Moratalaz 98, Ciudad Lineal 98, Puente de Vallecas 98, Fuencarral-El Pardo 97, Usera 97, Carabanchel 97, Hortaleza 97, San Blas-Canillejas 97 y Villaverde 97;
   - «Casi encajan» idéntico: Chamartín, Salamanca, Centro, Chamberí y Retiro, al 93 %;
   - la respuesta entera (`data`) es igual byte a byte, y `/search/barrios` también, en los 21 distritos.

   Tests: sin empates exactos el orden es el del encaje (propiedad); un encaje mayor nunca cede ante una zona mejor servida aunque las dos se lean con el mismo %; y en «Casi encajan» un empate sigue yendo a la confianza. El golden de búsqueda fija el orden exacto del ejemplo: el top 10 (`ranked_order`) y las cinco de «Casi encajan» (`near_miss_order`). Así un sync futuro no puede reordenar el caso del pitch sin que se note.
6. **Los dos casos del feedback** (pareja, alquiler hasta 10.000 €/mes; antes es producción, después es esta rama):
   - **Sin prioridades** (57 zonas, todas al 100 %; aviso con 57):
     - antes: Alcalá de Henares, Alcobendas, Alcorcón, Algete, Aranjuez, Arganda del Rey, Arroyomolinos, Boadilla del Monte, Ciempozuelos y Colmenar Viejo;
     - después: Chamberí, Tetuán, Puente de Vallecas, Salamanca, Centro, Usera, Arganzuela, Ciudad Lineal, Carabanchel y Retiro, con los seis servicios dentro de su ventana y a unos 5–6 min de media.
   - **Con transporte y salud** (57 zonas, 24 al 100 %; aviso con 24):
     - antes: Móstoles, Parla, Torrejón de Ardoz, Alcalá de Henares, Alcorcón, Leganés, Coslada, Fuenlabrada, Arganzuela y Salamanca;
     - después: el mismo top 10 que sin prioridades.

**B. Hospitales públicos y privados.**
1. **Fuente: el dato ya estaba.** El registro de centros sanitarios de la Comunidad de Madrid (`cm_centros_sanitarios`, datos abiertos de la CM) publica la «dependencia funcional» de cada centro, y la carga la guarda desde D-218 como `dependency` en cada lugar. De los 85 hospitales, 34 son del Servicio Madrileño de Salud y 51 privados: 40 «Privado No Benéfico», 8 «Privado Benéfico (Iglesia)» y 3 mutuas.
2. **Criterio: «público» es la red del Servicio Madrileño de Salud (SERMAS) y «privado», el resto.** Quien busca sanidad pública quiere saber a qué hospital le manda su tarjeta sanitaria.
   - Cinco hospitales de la red pública los gestiona una empresa: «Hospital público · gestión privada».
   - Sustituye la regla de D-218. «Privado» es todo lo que no está en la red, aunque tenga un convenio o concierto ordinario con el SERMAS (p. ej. la Fundación Instituto San José, `data/catalog/corrections/places.yaml`): puede recibir pacientes derivados, pero no es hospital de referencia de la tarjeta sanitaria. «Gestión privada» solo va con «público».
   - En el registro, cuatro ya figuran como del SERMAS (concesiones). La Fundación Jiménez Díaz figura como «Privado No Benéfico», pero está en la red por concierto singular: pasa a público.
   - **Lista estática** (`hi_domain.facilities.PRIVATE_MANAGEMENT`), por el código del Catálogo Nacional de Hospitales con el que se cruzó cada lugar (D-218), el único código oficial que lleva:

     | CODCNH | Hospital | Fórmula |
     |---|---|---|
     | 280421 | Fundación Jiménez Díaz | Concierto singular |
     | 281348 | Rey Juan Carlos (Móstoles) | Concesión |
     | 281236 | Infanta Elena (Valdemoro) | Concesión |
     | 281359 | General de Villalba | Concesión |
     | 281337 | Torrejón | Concesión |
   - **Fuentes** (comunidad.madrid, consultadas el 14 nov):
     - «Hospitales de la red del Servicio Madrileño de Salud» (actualizada el 26 may 2026): los cinco están en la red;
     - «Control y seguimiento de centros y servicios de gestión indirecta» (actualizada el 27 oct 2026): los cinco están en «Hospitales con concesión de gestión de servicio público, convenio o concierto singular».
   - **Fuera, a propósito:**
     - el Hospital Central de la Defensa Gómez Ulla: está en ese mismo grupo, pero por convenio con otra Administración (Defensa), así que es gestión pública; además no está en el registro;
     - los 7 hospitales PFI (Henares, Infanta Cristina, Infanta Leonor, Infanta Sofía, Sureste, Tajo y Puerta de Hierro): solo están en concesión la obra y los servicios no sanitarios; la asistencia la presta el SERMAS.
   - La lista va en código porque el despliegue de la API no lleva `data/` (`.vercelignore`). Cambiarla es desplegar. Si una edición nueva del catálogo cambiara un código, ese hospital vuelve a lo que diga el registro: nunca se adivina (test).
3. **Contrato `/places` (aditivo, sigue `places-1`):**
   - `dependency` (`publica` o `privada`) en las propiedades del lugar, para todo centro sanitario del registro. Antes solo iba dentro de `capacity`, es decir, solo en los hospitales cruzados con el catálogo. La Fundación Jiménez Díaz pasa a `publica` en el lugar.
   - `capacity.dependency` no cambia: sigue siendo el valor del registro (D-218), así que el contrato es aditivo de verdad, y una web anterior no dice «gestión pública» de la Fundación Jiménez Díaz.
   - `management` (`publica` o `privada`), solo en hospitales: quién lo gestiona. Privada en los privados y en los cinco de la lista; pública en el resto de los públicos.
   - Un valor que el contrato no conoce se omite: nunca rompe la respuesta (test).
   - Resultado con los datos locales: 35 hospitales públicos (30 los gestiona el SERMAS y 5 una empresa) y 50 privados.
4. **Web («Todos los centros» y etiqueta del mapa).**
   - Cada hospital dice «Hospital público», «Hospital público · gestión privada» u «Hospital privado» (también en los especializados, de media y larga estancia y de salud mental).
   - Los públicos van primero en la lista, y el recuento los reparte («5 hospitales en Chamartín: 2 públicos y 3 privados»). Los de gestión privada cuentan como públicos.
   - Bajo el recuento, `centros.hospital.dependencia` explica las tres palabras.
   - Sustituye a «gestión pública» y «gestión privada» detrás de las camas, que casi nadie veía.
   - Con una API anterior a este cambio, la web lee el dato de `capacity`: funciona antes y después del despliegue, aunque hasta entonces la Fundación Jiménez Díaz sale como privada.
5. **Nombre del Rey Juan Carlos.** El registro no lo nombra («Hospital general (Móstoles)», CH0105). El catálogo da el nombre de la concesionaria («ID Dalud Móstoles Sa»), que no se usa (D-218 §5).
   - Corrección versionada en `data/catalog/corrections/places.yaml` (D-221), con la página del hospital en la red del SERMAS: «Hospital Universitario Rey Juan Carlos · C/ Gladiolo s/n. · 28933 · Móstoles», la misma calle y el mismo código postal del cruce.
   - Se aplica en la próxima carga del registro: hasta entonces sale como «Hospital general (Móstoles)», ya con «Hospital público · gestión privada».
6. **Lo que no se hace, y por qué.**
   - **Dos tipos de centro separables** («Hospitales públicos» y «Hospitales privados» como botones distintos): pide un color nuevo en el mapa y un sitio para el hospital sin clasificar. No es barato a una semana de la congelación; la etiqueta, el orden y el reparto del recuento ya los distinguen.
   - **«El hospital más cercano es público»:** `min_a_pie_hospital` es la mediana de las calles de la zona hasta el hospital general más cercano a cada calle, así que no hay un único hospital del que decir si es público. Hacerlo bien es una feature nueva (`min_a_pie_hospital_publico`, misma fórmula con `attributes: {dependency: [publica]}`, fila extra de centros de salud): cálculo, sync y texto. Queda propuesta, sin hacer.
7. **La puntuación no cambia.** La necesidad de salud sigue midiendo el centro de salud, y los minutos al hospital siguen siendo un dato de contexto con todos los hospitales generales (D-217 §5).
8. **Orden en producción.**
   - Desempate y etiquetas: basta desplegar, sin sync.
   - Nombre del Rey Juan Carlos, después del despliegue (primero el código y después el sync):
     1. Carga del registro con `make ingest DATASET=cm_centros_sanitarios`.
     2. Comprobar en el resumen de la ejecución que solo cambia CH0105. Si cambia algo más, recalcular las features antes del sync, o aplazar el sync.
     3. `make supabase-sync` y smoke de `/places` y `/search`, incluido el golden de búsqueda (`scripts/golden_search.py`, que ya comprueba el orden exacto del ejemplo).
   - Fixture regenerado en solo lectura: `places.hospitales_madrid`, con `dependency` y `management` y los nombres con tilde de D-221.

## D-235 — Otros datos de la zona: infracciones penales, antigüedad de las viviendas y renta, como contexto que no puntúa (2026-11-14)
Feedback de los usuarios de prueba del 13 y 14 nov, aprobado por Mariano: en la vista de cada zona quieren ver los delitos, lo antiguas que son las viviendas y la renta. Abre la opción de D-224 §3. Es aditivo y reversible: datos nuevos y una tarjeta nueva, sin tocar el encaje, el orden ni «Qué falta». Evidencia: `evidence/gate-01/2026-11-14/` (Gate 1 de los tres datasets) y `evidence/gate-06/2026-11-14-context/` (cobertura, ejemplos, invariante del pitch y capturas).
1. **Qué se enseña.** Una tarjeta «Otros datos de la zona» (`zona.contexto.*` de `pitch/textos_web.md`) al final de la columna de la zona: una línea corta por dato, con su fuente y su año, en tinta normal. La fuente dice por dónde llega el dato: «Ministerio del Interior, vía Instituto de Estadística de la Comunidad de Madrid» e «INE, panel del Ayuntamiento de Madrid» (revisión R-04). Sin colores de estado ni de alarma, sin ranking, sin comparar zonas y sin palabras como «peligroso», «inseguro», «rica» o «pobre» (test). Pie: «Son datos informativos: no cambian el encaje ni el orden de las zonas». Una línea cuyo dato la API no tiene (404) no sale en toda la visita; cualquier otro fallo solo oculta esa línea y no se recuerda, así que se vuelve a pedir en la visita siguiente (revisión R-05). Sin ninguna línea, no sale la tarjeta.
2. **Infracciones penales conocidas por cada 1.000 habitantes** (`infracciones_penales_por_1000_hab`).
   - **Fuente:** «Hechos conocidos de infracciones penales por tipología en municipios mayores de 20.000 habitantes por municipio» (portal CM, CC BY 4.0; Instituto de Estadística con las Estadísticas de Criminalidad del Ministerio del Interior). 2016–2025; 2025 es provisional y no se usa, así que se enseña 2024.
   - **Qué se cuenta:** la criminalidad convencional, el total menos la cibercriminalidad, como proponía D-224 §3: las estafas y otros delitos por internet no ocurren en un sitio y pesan del 12 % (Humanes) al 40 % (Boadilla) del total. Sobre los vecinos del mismo año (censo anual a 1 de enero de 2024), no los del último año publicado (`same_period`). Sin fila de región: 37 municipios no son la Comunidad (`regional_reference: false`).
   - **Distritos y barrios de Madrid:** la fuente no los publica. Llevan la cifra de toda la ciudad con la etiqueta «Dato de toda la ciudad de Madrid; no se publica por distrito». Nunca se reparte entre distritos (CLAUDE.md §11).
   - **Sin estigmatizar:** aviso fijo bajo la cifra, «Mide hechos conocidos por la policía, sin los delitos por internet; sube donde hay mucha gente de paso». Los municipios de menos de 20.000 habitantes salen «sin dato» con el motivo, nunca 0.
   - **Ingesta:** la tabla no trae código de territorio y escribe los nombres a mano (dobles espacios, «Rozas de Madrid», «San Fernado de Henares», «Mejorada»). Nuevo tipo de pipeline `cm_municipio_concept`: lee las filas cuyo concepto empieza por uno de `concepts` (aquí el total y la cibercriminalidad, como dimensión `tipologia`) y resuelve cada nombre a su código INE con la lista del YAML. Tres checks críticos impiden perder una cifra en silencio (revisión R-01): `expected_municipios` (los 37 de la lista salen en la tabla); `quarantine_empty` (una sola fila con un nombre desconocido hace fallar el run, aunque la proporción de cuarentena que se tolera en otras tablas no se supere), y `latest_year_complete` (en el último año leído, cada uno de los 37 tiene su total y su cibercriminalidad, así que una fila renombrada o quitada por la fuente también lo hace fallar; hay test con la de Getafe de 2024). Parser `stat_tables-1.1.0`. En los recuentos, las filas de otros conceptos se llaman `out_of_scope`, como en el panel, y las 74 del año provisional (37 totales y 37 de cibercriminalidad), `excluded_status`. El aviso no crítico `totals_are_additive` sale en rojo a propósito: la cibercriminalidad es una parte del total, no un reparto completo.
3. **Antigüedad de las viviendas.** Son medidas distintas, con etiquetas distintas, y nunca en la misma escala (test).
   - **Municipios: «Viviendas construidas desde 2001: N %»** (`viviendas_desde_2001_pct`). Fuente: `censo_anual_vivienda_por_antiguedad` (Censo anual de la Comunidad de Madrid, Instituto de Estadística a partir del Catastro; portal CM, CC BY 4.0), 2023. Las de año conocido son el denominador: «No consta» (45 en toda la región) queda fuera. Los 14 intervalos más «No consta» tienen que sumar el total de la fuente (`denominator_total`, revisión R-10); si no, el porcentaje sale «sin dato» (`ESTIMATION_NOT_ALLOWED`) en vez de un porcentaje sobre un denominador incompleto. Hoy cuadran en los 179 municipios, en 2022 y en 2023.
   - **Por qué este y no el Censo de viviendas 2021** (`censo_2021_viviendas_familiares_por_anyo`), como recomendó la línea D: el anual da los 179 municipios sin suprimir ni redondear; el de 2021 suprime 28 y redondea a múltiplos de 3. Es la misma serie que `cm_viviendas_superficie`: en 2023 el total coincide con ella en los 179 municipios y en la región (2.979.188). Frente a las 2.950.410 viviendas familiares del Censo de 2021 es un 1,0 % más; la fuente no dice si cuenta solo las familiares, y así lo dice la limitación.
   - **Distritos y barrios de Madrid: «Año medio de construcción de los edificios de viviendas»** (`ano_medio_construccion_residencial`). Catastro, a 1 de enero de 2025, del panel de indicadores de distritos y barrios del Ayuntamiento (CC BY 4.0).
4. **Renta.** Solo informativa: sin filtro, sin orden y sin lenguaje de «zona rica».
   - **Municipios: «Renta disponible bruta por persona»** (`renta_per_capita`, ya cargada desde el 21 oct): Indicador de Renta Disponible Bruta Municipal del Instituto de Estadística de la Comunidad de Madrid (portal CM), 2024. Hay dataset en el portal CM, así que no hace falta el ADRH del INE.
   - **Distritos y barrios de Madrid: «Renta neta media por hogar … (INE, panel del Ayuntamiento de Madrid, año)»** (`renta_neta_media_hogar`): renta neta media anual de los hogares (Urban Audit, INE), del panel del Ayuntamiento, 2023. Es por hogar y neta, no por persona y bruta: no es comparable con la de los municipios.
   - Un barrio elegido en el mapa dentro de un distrito enseña su antigüedad y su renta («… en Recoletos»).
5. **Por qué no puntúa ninguno.**
   - Los delitos, por D-224: se cuentan donde se conocen, no donde vive quien los sufre; solo cubren 36 de las 199 zonas del buscador y no hay cifra por distrito.
   - La renta y la antigüedad no dicen si una zona le conviene a un hogar. Ordenar por renta empujaría a las familias según el dinero de sus vecinos, y una vivienda antigua puede estar rehabilitada.
   - Garantía en el código: las cinco features tienen `context_only` y ni `fit` ni `gap_row`. `test_zone_context_never_scores_filters_or_enters_the_gaps` lo comprueba, así que la búsqueda (`FIT_VALUES` solo lee features con `fit`) y «Qué falta» no las ven. No pasan por `indicators_by_zone` y no necesitan rama nueva.
6. **Cobertura** (base local `housing_contexto`, 14 nov):
   - Infracciones: 37 municipios con cifra, de 20,7 (Tres Cantos) a 116,2 (Humanes de Madrid); Madrid, 58,6. Los otros 142 municipios, «sin dato» explícito. Los 21 distritos y los 131 barrios enseñan la cifra de la ciudad con su etiqueta.
   - Viviendas desde 2001: 179 de 179 municipios, de 7,6 % (Robregordo) a 88,7 % (Arroyomolinos). Año medio: 21 de 21 distritos (de 1926, Centro, a 1999, Vicálvaro) y 131 de 131 barrios.
   - Renta por persona: 179 de 179 municipios (de 13.995 € en Cenicientos a 47.217 € en Pozuelo de Alarcón). Renta por hogar: 21 de 21 distritos y 131 de 131 barrios.
   - Ejemplos: Madrid 58,6 · 16,5 % · 27.188 €. Pozuelo de Alarcón 21,6 · 32,7 % · 47.217 €. Parla 47,7 · 43,6 % · 14.349 €. Rascafría sin dato · 21,6 % · 20.532 €. Salamanca: cifra de Madrid · año medio 1953 · 69.147 € por hogar. Usera: cifra de Madrid · 1978 · 34.651 € por hogar.
7. **Invariante del pitch.** El caso de ejemplo (`exampleScenario`) sale igual contra la base con los datos nuevos: 27 zonas; Latina, Moratalaz, Ciudad Lineal y Puente de Vallecas al 98 %; «Casi encajan» Chamartín, Salamanca, Centro, Chamberí y Retiro.
8. **Despliegue y sync.**
   - **Orden:** el de siempre, desplegar → sincronizar → smoke. Aquí el orden no rompe nada. Con el código desplegado y los datos sin sincronizar, la web pide las features nuevas, recibe 404 y oculta esas líneas: la renta por persona ya está en producción y sale sola. Con los datos sincronizados antes que el código, nadie los pide.
   - **Rollback:** la regla «tras el sync no hay vuelta atrás sin retirar estas filas» (D-233 §3) **no aplica**: ninguna feature tiene `fit` y el código anterior las ignora. Se puede volver a cualquier despliegue anterior sin tocar los datos.
   - **Tablas** (`make supabase-sync PROFILE=demo` copia las tablas enteras): `dataset_registry` +2, `dataset_version` +2, `metric_registry` +4, `feature_registry` +4 (y la `spec` de `renta_per_capita` cambia: `context_only` y dos limitaciones), `feature_value` +662 (179 + 179 + 152 + 152). `metric_observation` (+8.674) solo va en el perfil `full`.
   - **Efecto visible del sync:** `GET /datasets?cm_only=true` pasa de 27 a 29 conjuntos CM, y con él el contador del pie. Las frases del pitch con «27 conjuntos» (`guion.md`, `formulario.md`) cambian cuando se sincronice; `datasets_cm.md` ya dice 29.
9. **Panel del Ayuntamiento:** parser `madrid_district_panel-1.6.0` («1.4 D-234 · 1.5 D-235 · 1.6 unión»), con el mismo análisis y la unión de los indicadores de D-234 (valor catastral, superficie e inmuebles residenciales) y los dos de D-235, sobre el mismo Bronze (`11a758e6249d`). En `housing_contexto`: SUCCESS, 7.560 observaciones de 9 métricas. Las 7 que ya leía D-234 coinciden fila a fila con `housing` (parser 1.4.0), y el precio estimado de D-234 recalculado también. `housing` está en 1.4.0: al fusionar hay que releer el panel con 1.6.0 (comandos en la PR #61); con 1.4.0 no se relee y faltan el año medio y la renta.

## D-240 — Días de oficina, teletrabajo y un segundo lugar: la familia o los amigos (`fit-0.8`) (2026-11-14)
Feedback de usuarios de prueba del 14 nov e ideas de Mariano. Quien va pocos días a la oficina no quiere que el trayecto pese como si fuera cada día, y quien teletrabaja del todo, que no puntúe. Varios querían además vivir cerca de su familia o de sus amigos. Es reversible: un peso por días en el dominio, `days_per_week` admite 0 y la web pregunta los días y un segundo lugar. Código: `hi_domain/fit.py` (`counts`, `days_weight`, `criteria` y `constraint_checks`), `hi_contracts/public/scenario.py`, `apps/web/src/lib/scenario.ts` y `apps/web/src/components/search/PlaceField.tsx` (antes `WorkField.tsx`). Evidencia: `evidence/gate-06/2026-11-14-family-telework/`.

1. **Regla de días (`days_per_week`, «¿Cuántos días vas a la oficina?»).**
   - **3 o más días:** el trayecto pesa como siempre, con su peso por orden (D-215). El caso de ejemplo va 4 días, así que sus cifras no cambian.
   - **1 o 2 días:** el trayecto pesa la mitad de su peso por orden y los demás criterios no cambian. Como el % divide por el peso de los criterios con dato, el trayecto cuenta menos frente a lo demás. Ejemplo del test: con un colegio a un paseo (utilidad 1) y un trayecto de 90 min (utilidad 0), la zona sale al 67 % yendo cada día y al 80 % yendo 1 o 2 días.
   - **0 días («Teletrabajo total»):** es nuevo en el contrato (`days_per_week` va ahora de 0 a 7). El trayecto no puntúa: la zona se puntúa como si no hubiera lugar de trabajo, y el peso por orden se reparte entre los demás criterios.
   - **El límite (`max_minutes`) se aplica igual con cualquier número de días, también con 0.** Es una condición que la persona pone a propósito, por ejemplo para poder llegar en 45 min el día que la llamen. La web mantiene «Tardar como mucho» con teletrabajo total y no borra el límite al cambiar los días.
   - **Con 0 días y límite, la tarjeta enseña los minutos** como un hecho más, sin peso (`limited_trips`), detrás de los que puntúan. Así la persona ve cuánto tarda cada zona con el límite que ha puesto. Sin límite no sale nada: ese trayecto ni puntúa ni limita.
   - **La regla vale para cualquier lugar**, no solo para el trabajo: la web solo pregunta los días del trabajo, pero el contrato los admite en todos. Por eso dos perfiles dorados cambian de peso con `fit-0.8`: `golden_senior` (su hijo en Getafe, 2 días) y `golden_reduced_mobility` (el hospital La Paz, 1 día) pesan ahora su trayecto a la mitad. Sus expectativas se siguen cumpliendo (9 de 9).
   - Constantes: `FEW_DAYS_PER_WEEK = 2` y `FEW_DAYS_WEIGHT = 0.5`. La web repite el 2 (`FEW_OFFICE_DAYS`) solo para decidir qué ayuda enseña.
   - **Descartado:**
     - un peso proporcional a los días (días/5): es más difícil de decir en una frase y cambiaba el % del ejemplo, que va 4 días;
     - quitar también el límite con teletrabajo total: si la persona lo pone, se respeta.
2. **Un segundo lugar, «Cerca de mi familia o amigos».**
   - **No hizo falta tocar la API ni el contrato del lugar.** `anchors` ya era una lista (hasta 3) con `kind: "family"`, y el dominio y la API ya calculaban un trayecto por lugar, con su condición `commute:<i>` (D-220). Cada lugar busca su destino en la matriz: la estación a 600 m o menos o, si no, el centro de la zona que lo contiene. Por eso vale desde cualquier punto de la Comunidad.
   - **Comprobado** con tests del dominio (dos trayectos, cada uno con sus minutos y su límite, y el segundo lugar conserva su índice aunque el primero no puntúe) y con la API local sobre la base (solo lectura), partiendo del caso de ejemplo:
     - la familia en Getafe Central con 30 min como mucho deja 5 zonas: Villaverde, Leganés, Getafe, Fuenlabrada y Parla;
     - un punto cualquiera (lon −3,38, lat 40,49) con 45 min deja 2: Torrejón de Ardoz y Alcalá de Henares;
     - ningún aviso de destino sin calcular, y cada zona trae los dos trayectos. Con tres prioridades y presupuesto, el de la familia cede su hecho al alquiler (punto 8), pero su condición sigue saliendo cuando falla.
   - **Orden.** La web pone siempre el trabajo primero y la familia después, sea cual sea el orden en que se elijan. Así el trabajo conserva el índice 0 (`commute:0`) y más peso por orden. Los criterios quedan así: prioridades, trabajo, familia, servicios deseados y presupuesto. Si solo hay familia, va en el índice 0.
   - Los días solo se preguntan para el trabajo. La familia va con el valor del contrato (5) y pesa como siempre.
   - **Proxy declarado:** el trayecto a la familia se mide con la misma matriz que el del trabajo, llegando a las 9:00 de un día laborable. A la familia se suele ir a otras horas y en fin de semana, con menos frecuencia de paso. Lo dicen la ayuda del campo («Opcional. Miramos cuánto tardarías en transporte público llegando a las 9:00 de un día laborable.») y el hecho de la tarjeta («28 min en transporte público hasta Getafe Central (Cercanías), llegando a las 9:00»).
   - **Desempate.** Los minutos que desempatan (D-220, D-239) son los del primer lugar al que la persona va (`lead_trip`). Con teletrabajo total en el trabajo son los del siguiente lugar al que va o, si no hay ninguno, los del primero con límite. Sin ninguno, el empate pasa directo al id de la zona. Con el trabajo primero y al menos 1 día es `commute:0`, como antes.
3. **`fit-0.8`.** La puntuación cambia con 0, 1 o 2 días, así que sube la versión. Con 3 o más días el % es igual que en `fit-0.7`, con o sin un lugar de familia; solo puede cambiar qué hechos salen (punto 8). Los PR #59, #60 y #62 se fusionan como una sola versión `fit-0.8` (D-234, D-236 y D-240). `pitch/metodologia.md` y los fixtures se actualizan después del despliegue.
4. **Invariante del pitch, comprobado el 14 nov.** API de esta rama sobre la base local (solo lectura) frente a producción, con el caso del ejemplo (4 días, sin límite y sin familia):
   - 27 zonas que encajan y 15 sin dato;
   - top 10 idéntico: Latina 98, Moratalaz 98, Ciudad Lineal 98, Puente de Vallecas 98, Fuencarral-El Pardo 97, Usera 97, Carabanchel 97, Hortaleza 97, San Blas-Canillejas 97 y Villaverde 97;
   - «Casi encajan» idéntico: Chamartín, Salamanca, Centro, Chamberí y Retiro, al 93 %;
   - la respuesta entera (`data`) es igual salvo `methodology_version` (`fit-0.8` frente a `fit-0.7`), y `/search/barrios` también, en los 21 distritos;
   - golden de búsqueda (`scripts/golden_search.py`): 9 de 9.
5. **Qué cambia con los días en el caso de ejemplo** (misma API local):
   - **3 días:** igual que con 4.
   - **1 o 2 días:** siguen 27 zonas. Alcorcón y Leganés entran en el top 10 en lugar de Fuencarral-El Pardo y Hortaleza, y Latina, Moratalaz y Puente de Vallecas suben al 99 %.
   - **Teletrabajo total:** siguen 27 zonas y las 10 primeras están al 100 %, así que el orden lo deciden los servicios a pie (D-239). Empieza por Usera, Latina, Moratalaz y Villaverde.
   - **Teletrabajo total con 45 min como mucho:** 10 zonas. El límite es la condición que más quita (`commute:0`), como yendo 4 días con el mismo límite.
6. **Web.**
   - **«¿Cuántos días vas a la oficina?»** va bajo el lugar de trabajo: de 5 a 1 días o «Teletrabajo total». Con 1 o 2 días, y con teletrabajo total, una línea explica qué pasa (`trabajo.dias.*`). Hasta que la persona lo cambia no se envía, y el contrato pone 5.
   - **«Cerca de mi familia o amigos»** es el mismo campo que «Trabajo en» (estaciones y zonas, combobox ARIA 1.2), con su propio «Tardar como mucho». `WorkField.tsx` pasa a ser `PlaceField.tsx`, con `kind` (`work` o `family`), y las estaciones se piden una sola vez para los dos campos.
   - **«Qué falta» sin zona:** la lista de distritos y municipios va plegada tras «Ver las 199 zonas» (`aria-expanded` y `aria-controls`), como «Ver las 10 primeras». «Madrid (toda la ciudad)» sigue a la vista y, al escribir un nombre, sus zonas salen aunque esté plegada. La lista de `/zonas` no se pliega.
7. **Orden en producción.** Basta desplegar: no hay datos nuevos ni sync. La API anterior rechaza `days_per_week: 0` (422), así que la web y la API van en el mismo despliegue, como siempre.
   - `scripts/smoke_demo.sh` tiene una comprobación nueva, `telework`: el caso de ejemplo con `days_per_week: 0` debe dar 200 y `fit-0.8`. Antes del despliegue, producción da 422. Con las tres de «¿Dónde?» (D-238), el smoke tiene 13 comprobaciones (12 con `SMOKE_API_ONLY`).
8. **Revisión del PR #60.**
   - **Hechos de la tarjeta.** Son 5 como mucho, en orden de importancia. Con tres prioridades, trabajo y familia, el alquiler era el sexto y desaparecía de la tarjeta. Ahora, si hay presupuesto, el coste siempre se queda y sale el menos importante de los demás: en ese caso, el trayecto a la familia (`capped`).
     - Con 5 hechos o menos no cambia nada: el caso del pitch es igual.
     - Un test de propiedad lo comprueba: con presupuesto, el coste siempre está entre los hechos, con cualquier combinación de prioridades, lugares, días y límites.
     - Descartado: juntar los dos trayectos en un hecho, porque cada uno tiene su tipo (punto fuerte o débil) y su fiabilidad.
     - La condición del límite a la familia sigue saliendo cuando falla, con sus minutos (`trabajo.tarda`).
   - **Accesibilidad.** El selector de días está unido a su ayuda con `aria-describedby`. El límite del trabajo se llama «Tardar como mucho hasta el trabajo, en transporte público», como el de la familia; el e2e (`infra/deploy/e2e/e2e_prod.mjs`) y `apps/web/scripts/check-search.mjs` lo buscan con ese texto.
   - **Sin escenarios dorados nuevos.** Teletrabajo con 45 min y familia con 30 min (opcional en la revisión) no se añaden ahora: el test de los perfiles dorados exige que no lleven límite y que cada uno sea un perfil de `user_profiles.yaml`. Los cubren los tests del dominio y la evidencia de casos.

## D-241 — Vivienda nueva y lo que viene: contexto que no puntúa (2026-11-14)
Feedback de usuarios de prueba del 14 nov: «¿las casas son nuevas o viejas?» y «¿qué proyectos nuevos se van a hacer en Madrid?». Aprobado por Mariano. Completa D-235, que da la antigüedad de todo el parque (el % de viviendas desde 2001 por municipio y el año medio de construcción por distrito): aquí, lo que se vende nuevo y lo que viene. Es aditivo y reversible: cuatro datasets, cinco features sin `fit` ni `gap_row`, un campo opcional en `GET /features/{id}/values` y una tarjeta en la vista de zona. `fit-0.8` no cambia. Código: `hi_ingestion/pipelines/zone_context/`, `hi_domain/urbanism.py`, `hi_domain/geo/names.py` (`title_case`), `hi_features/methods.py` (`metric_window_share`, `metric_items`), `hi_contracts/catalog/manual.py`, `apps/web/src/lib/newHousing.ts` y `components/zone/NewHousing.tsx`. Evidencia: `evidence/gate-01/2026-11-14/` (los 4 datasets) y `evidence/gate-06/2026-11-14-new-housing/`.
1. **Fuentes y licencias.**
   - **Compraventas de vivienda nueva y de segunda mano por municipio** (`cm_transacciones_nueva_usada`, portal de datos abiertos de la CM, CC BY 4.0, «Fecha Actualización 08-09-2026»; Estadística de Transacciones Inmobiliarias del Ministerio de Transportes, Movilidad y Agenda Urbana). Ya estaba en el catálogo sin usar. Por trimestre, hasta el 2.º de 2026 (provisional). Se carga solo la serie de compraventas desde 2024; las tasas de variación y la media anual se pueden recalcular desde ella.
   - **Valor tasado de la vivienda libre por antigüedad** (`cm_valor_tasado_vivienda_antiguedad`, portal CM, CC BY 4.0, «Fecha Actualización 02-06-2026»; Ministerio de Vivienda y Agenda Urbana). Media anual en €/m² de hasta 5 años y de más de 5 años, con código de municipio.
   - **Plan Vive** (`cm_plan_vive_promociones`, página de la Comunidad de Madrid, sin fichero). Su aviso legal permite reutilizar «a condición de que no se altere el contenido…, se mencione la fuente, se indique la fecha de extracción…». Fuente nueva `comunidad_madrid_web`; no es dataset del portal de datos abiertos y no cuenta como tal.
   - **PGOUM 97. Estado de desarrollo de los ámbitos (VEDA)** (`ayto_pgoum_desarrollo_ambitos`, datos.madrid.es, CC BY 4.0, versión de julio de 2026). Complementario, como el padrón (D-209). El fichero se llama «01_01_2026», pero su columna de fecha y su ficha dicen 1 de julio de 2026: se usa la de la columna.
2. **Cobertura (datos del 14 nov).**
   - Compraventas: 179 de 179 municipios; Madrid sale entero, sin distritos. 177 con porcentaje; La Acebeda y Horcajuelo de la Sierra no tuvieron ninguna compraventa en el año (`NOT_APPLICABLE` con sus cuentas, nunca 0 %).
   - Valor tasado: en 2025, 20 municipios con los dos valores y 28 con el de más de 5 años. Sin distritos.
   - Plan Vive: 26 entradas (25 municipios y Madrid), 11.845 viviendas en 72 promociones. La página no da fichero ni el reparto de las 1.616 de Madrid entre Valdebebas y Los Ahijones: VEDA pone cada sitio en su distrito (Hortaleza y Vicálvaro), y los dos enseñan la entrada entera con la nota «La Comunidad no publica cuántas de estas viviendas hay en cada uno de los dos sitios», que viaja en el dato. Un municipio que la página no nombra tiene 0, no «sin datos».
   - VEDA: 666 ámbitos en los 21 distritos. Se quedan los de uso residencial (o residencial y terciario) con alguna fase sin terminar: 57 en 19 distritos. Los 6 sin uso característico (suelo urbanizable no sectorizado, como la Nueva Centralidad del Este) quedan fuera. Puente de Vallecas y Moratalaz tienen 0, confirmado.
3. **El cruce de nombres (compraventas).** La tabla no trae código: solo «Acebeda (La)». El nombre se compara con los municipios de la geografía (`geo_admin_unit`, que viene de la tabla de municipios de la CM con su código) con `name_key`: sin mayúsculas, tildes ni signos, así que el orden del artículo da igual («ACEBEDA, LA» y «Acebeda (La)»). Casan los 179: 178 iguales y «Alamo (El)», sin tilde en la fuente. Lo comprueba también la tabla CM de museos por municipio, que trae el mismo nombre con el código: coinciden los 179. Un nombre que no casa va a cuarentena y bloquea la carga, y también si falta un municipio (checks críticos `nothing_quarantined` y `every_municipio_published`). Se descartó la lista de nombres a mano del pipeline `cm_municipio_concept` (PR #61): con 179 municipios, la geografía es la fuente, no una lista.
4. **Por qué no puntúa.**
   - Ninguna cifra mide lo que pide una persona: la obra nueva vendida no dice cuántos pisos quedan ni a qué precio; el valor tasado por antigüedad no es el precio de compra (que sigue siendo el valor tasado total, D-227, y el estimado de D-234); el Plan Vive tiene sus propios requisitos de acceso; y un ámbito de VEDA dice dónde se prepara suelo, no cuántas viviendas habrá ni cuándo.
   - Por eso no tienen `fit` ni `gap_row` (test de catálogo), no filtran, no ordenan y no entran en «Qué falta». La búsqueda no las lee (`FIT_VALUES` solo trae features con `fit`).
5. **Cálculo.**
   - `compraventas_obra_nueva_pct`: las compraventas nuevas entre todas, sumadas en los 4 últimos trimestres publicados (del 3.er trimestre de 2025 al 2.º de 2026), igual para todas las zonas. Si falta un trimestre, la zona sale desconocida. `detail` guarda las dos cuentas, el último día y si algún trimestre es provisional (el 2.º de 2026 lo es). Ejemplos: Getafe 650 de 2.311 (28 %), Valdemoro 168 de 1.126 (15 %), Pozuelo 101 de 820 (12 %), Alcobendas 28 de 1.067 (2,6 %) y Madrid 1.512 de 40.086 (3,8 %).
   - `valor_tasado_vivienda_nueva_m2` y `…_usada_m2`: los dos valores de 2025, confidence 0,8 como D-227. Pozuelo 5.432 y 4.788 €/m² (+13 %), Alcobendas +14 %, Madrid +9 %, Getafe +1 %, Alcorcón −7 %.
   - `plan_vive_viviendas` y `ambitos_residenciales_en_desarrollo`: método `metric_items`, el valor (suma de viviendas o número de ámbitos) y sus elementos en `detail.items`. Etapas de VEDA, de la fase más avanzada en marcha: «urbanización en obras» (las obras de urbanización están en ejecución), «en tramitación» (otra fase en marcha) y «sin empezar». Vicálvaro: Los Berrocales, Los Ahijones, Los Cerros y Camino Viejo de Vicálvaro, en obras. Los nombres vienen en mayúsculas: se pasan a minúsculas sin añadir tildes, con las siglas declaradas (PMM, ONCE, UVA…) y sin el prefijo común «Desarrollo del Este - ».
   - Plan Vive se transcribe a mano en `data/catalog/manual/plan_vive.yaml`. Cada entrada cita la página (`says`) y el contrato rechaza la que no contenga su municipio, ubicación, viviendas y fase: nada de memoria. La carga lee el fichero versionado, nunca la página; su linaje guarda la URL y la fecha consultada. Ninguna entrada estaba incompleta el 14 nov (`excluded` vacío).
6. **API (aditivo).** `FeatureValueRow.detail` (opcional) en `GET /features/{id}/values`, solo en las filas que lo guardan (`inputs.detail`); las demás no traen el campo. El código desplegado ahora lo ignora: con los datos sincronizados y el código anterior, la web nueva no enseña las líneas que lo necesitan.
7. **Web.** Tarjeta «Vivienda nueva y lo que viene» en la vista de municipio y de distrito, debajo de «Otros datos de la zona» (D-235), como la percepción de seguridad (D-226): una frase por dato con su fuente y su fecha, sin colores de estado ni de alarma, y el pie «Son datos informativos: no cambian el encaje ni el orden de las zonas». En un distrito, las compraventas y la tasación son de la ciudad, con «En toda la ciudad de Madrid,» y «La fuente no lo da por distritos». Se quita el «Aquí se construye:» del encargo: con un 3 % de obra nueva diría lo contrario de la cifra. La cita del Plan Vive lleva su fecha de extracción (`provenance.ts`) y los datasets salen en `/datasets`: los CM pasan de 29 (con D-235) a 31.
8. **Invariante del pitch.** Golden 9/9 contra `housing_vivienda`, con `ranked_order` y `near_miss_order` del ejemplo. `POST /search` (toda la Comunidad y Madrid capital por barrios) y `POST /search/barrios` en los 21 distritos dan la misma respuesta byte a byte con y sin las filas de D-241 (borradas dentro de una transacción que se deshace).
9. **Orden en producción: desplegar → sincronizar → smoke.** Las features no tienen `fit`, así que sincronizar antes no rompe `/search`, pero el código desplegado no sirve `detail` y la tarjeta saldría vacía o a medias. **Tras el sync no hay vuelta atrás sin retirar estas filas:** volver a un despliegue anterior con ellas en la base deja en `/datasets` y en el contador del pie 2 conjuntos CM que la web de entonces no enseña (D-231). Para retirarlas: borrar las 5 filas de `feature_registry` (las de `feature_value` caen por CASCADE) y las versiones de los 4 datasets en `dataset_version`, o volver a sincronizar desde una base sin ellas.
10. **Descartado.**
    - Repartir las compraventas o la tasación de Madrid entre distritos (CLAUDE.md §11).
    - Leer la página del Plan Vive en cada carga (scraping): cambia sin aviso y su aviso legal pide la fecha de extracción.
    - Contar viviendas en los ámbitos de VEDA: el fichero no las trae.
    - Usar VEDA para puntuar «dónde habrá más vivienda»: sería una predicción sin dato de cuándo ni cuántas.
11. **Revisión (`reviewer`).** Sin bloqueantes. Aplicado:
    - VEDA: un check crítico exige una sola fecha en todo el registro (`one_register_date`). Con dos fechas, los ámbitos de la más antigua saldrían del recuento de su distrito sin avisar.
    - Compraventas: si a la serie le falta un trimestre, no hay ventana (todas las zonas sin dato), porque «los 4 últimos» abarcarían más de un año.
    - `metric_items`: un ítem sin valor deja la suma desconocida, nunca más corta, y los empates se ordenan por código (mismo orden en cada cálculo).
    - Web: un fallo de red puntual no se guarda para toda la visita (la tarjeta se vuelve a pedir en la siguiente zona), y el aviso dice «Incluye datos aún provisionales», que vale aunque sea más de un trimestre.
    - El mínimo de `pydantic` sube a 2.12 (`exclude_if`), y un test exige que la fecha de la cita del Plan Vive sea la `consulted` de su tabla.
    - Queda como está, declarado: `inputs.counts` e `inputs.detail` repiten las dos cuentas (D-213 lee la primera, la API la segunda).

## D-242 — Alquiler donde la Comunidad no lo publica: la referencia del Ministerio de Vivienda (SERPAVI), con el rango de la mitad de los contratos (`fit-0.8`) (2026-11-15)
Feedback de usuarios de prueba del 14 nov, con la solución aprobada por Mariano (opción A del orquestador). Solo 37 de 179 municipios tenían alquiler: con «Pueblos» (D-238) casi todo salía «Sin datos» (2 de 138 cumplían), y una persona dijo que el precio por zona no le quedaba claro. Es reversible: un dataset complementario, una feature con rol propio y un campo opcional del contrato. Código:
- `hi_ingestion/pipelines/serpavi/` (tipo `serpavi_rent`) y `hi_contracts/catalog/pipeline.py` (`SerpaviRentPipeline`);
- `hi_features/reference_rent.py` y `compute.py` (`reference_rent_fill`);
- `hi_contracts/catalog/feature.py` (rol `rent_m2_fill`, con `note` y `source`) y `public/search.py` (`CostRange`);
- `hi_api/services/search.py` (`zone_rent`) y `barrios.py`;
- `hi_domain/affordability.py`, `fit.py` y `search.py`;
- la web (`lib/fit.ts`, `PriceTag.tsx`, `SearchCard.tsx`, `FitDetails.tsx`, `lib/provenance.ts` y «Cómo lo calculamos»).

Evidencia: `evidence/gate-01/2026-11-14/mivau_serpavi_alquiler/` (Gate 1) y `evidence/gate-06/2026-11-15-serpavi/` (golden, cobertura, los 37 cocientes y capturas a 1440 y 390 px).
1. **Fuente.** «Sistema Estatal de Referencia del Precio del Alquiler de Vivienda» (SERPAVI) del Ministerio de Vivienda y Agenda Urbana, base de datos 2011-2024 publicada el 9 de marzo de 2026 (XLSX de 71 MB del CDN del Ministerio). Es la misma explotación de fuentes tributarias que el dato CM (IRPF y Catastro), pero publica la **mediana y los percentiles 25 y 75** del alquiler mensual por m² y el número de viviendas alquiladas como vivienda habitual, en vivienda colectiva (pisos) y unifamiliar, por municipio, distrito censal y sección censal, con códigos INE.
   - **Fuente complementaria, no CM** (`ministerio_vivienda`, dataset `mivau_serpavi_alquiler`): solo rellena donde el dato CM no existe. La cifra de datasets CM no cambia.
   - **Qué mide:** los alquileres de vivienda habitual vigentes declarados en el IRPF, no los contratos firmados en un año. Por eso la cifra que enseñamos es una **elaboración propia**: la fuente de la tarjeta dice «Elaboración propia a partir del Ministerio de Vivienda (SERPAVI), 2024» y la nota, «referencia del Ministerio de Vivienda llevada a contratos firmados en 2024» (revisión R-02 del PR #71).
   - **Licencia:** reutilización autorizada citando la fuente y la fecha de la última actualización, según el aviso legal del Ministerio recogido por la línea de investigación; la reutilización se rige por la Ley 37/2007. `mivau.gob.es` responde 403 a clientes automáticos (14 y 15 nov, también con WebFetch), así que no se ha podido releer el aviso desde aquí; el fichero se descarga sin restricciones del CDN. `commercial_use` queda sin declarar (`null`) y el YAML de la fuente lo marca «pendiente de verificación manual» (pendiente de Mariano); la fuente sigue `CLEAR` para no apagarla en la demo. **Cerrado el 15 nov (D-243 §12):** el aviso legal, comprobado en el navegador, permite usos comerciales y no comerciales; `commercial_use: true`. La cita (`attribution_text` de la fuente, `pie.mivau`) lleva la fecha de actualización y enlaza a la página del SERPAVI. El pie suma «Ministerio de Vivienda» en `pie.contador` y `pie.independiente`.
2. **Ingesta (Gate 1 superado).** Pipeline `serpavi_rent`, parser `serpavi_rent-1.0.0`: lee las hojas de municipios, distritos y secciones, solo la provincia 28 y los años desde `period_min` (2024). Una columna que falta para un año leído para el pipeline.
   - Métricas `alquiler_m2_mensual_serpavi` (dimensiones `tipologia` y `estadistico`: mediana, p25, p75) y `contratos_alquiler_serpavi` (`tipologia`).
   - 38.728 observaciones: 179 municipios, 246 distritos censales y 4.416 secciones; 0 en cuarentena; los cuartiles nunca desordenados (5.656 comprobados, crítico). Una sección es de otro seccionado (2800504018): conserva su código sin enlace a la geografía (aviso no crítico).
   - Una celda vacía es SOURCE_MISSING, nunca 0: la fuente no publica la mediana con menos de 10 viviendas.
   - El XLSX se borra de Bronze tras procesarlo y queda su `manifest.json` (sha256 `f00ca4d7…`).
   - **Cobertura 2024:** 163 de 179 municipios con mediana (137 de pisos y 26 solo de casas; 125 con 30 contratos o más de la tipología que se usa); los 21 distritos de Madrid; 2.428 de sus 2.442 secciones.
3. **Método de relleno** (feature `alquiler_m2_mensual_referencia`, método `reference_rent_fill`).
   - **Fórmula:** €/m² = mediana SERPAVI de pisos (o de casas si no hay de pisos) × cociente de calibración × factor de contratos nuevos de D-228, aplicado igual que al dato CM: el del municipio si tiene tabla de la AEAT y, si no, el de la Comunidad. Los percentiles 25 y 75 solo se multiplican por el factor de contratos nuevos: el cociente corrige el centro (media frente a mediana), no la dispersión (revisión R-02). Se guardan en `inputs.reference_rent.quartiles`.
   - **Factor de reserva (revisión R-03):** ninguno de los 126 municipios rellenos tiene tabla propia de la AEAT, así que todos toman la fila de la Comunidad, 1,2085. Esa fila suma los 37 municipios de la tabla y la domina Madrid; la mediana de sus 37 factores es 1,155. Con ella, el alquiler de esos pueblos sale entre un 4 y un 5 % más alto que con un factor mediano (1,2085 / 1,155 = 1,046). Queda así, declarado en `limitations`, y se prueba en el banco de fórmulas (F4). Corrige D-228 §7, que decía que el factor de reserva no se usaba. **Cambiado el 15 nov (D-243 §11):** el factor de reserva pasa a ser la mediana de los 37 factores municipales (1,155).
   - **Cociente:** media CM / mediana SERPAVI en los municipios con los dos datos del mismo año (2024): 37 municipios, **mediana 1,039** (de 0,969 en Torrelodones a 1,081 en Madrid; media 1,031; ponderada por contratos 1,067, porque pesa Madrid). Se usa la mediana: no la arrastra Madrid y aguanta valores extremos. Se recalcula al calcular la feature, queda en `inputs.reference_rent.calibration` y para el cálculo si hay menos de 20 municipios con los dos.
   - **Distritos de Madrid:** su propia fila SERPAVI (el distrito censal es el municipal), con el factor de Madrid. Hoy no se usan: los 21 tienen dato CM.
   - **Barrios:** media de las secciones del barrio ponderada por sus contratos (una media de medianas, no la mediana del barrio; declarado). Su rango es la media de los rangos de sus secciones, no el rango del barrio, y se dice: la nota añade «el rango es la media de los de sus 7 secciones censales» y la fuente, «…; rango: media de sus 7 secciones censales» (Sol; revisión R-02). El cruce sección → barrio es el padre de la sección en `geo_admin_unit` (D-232); 2.442 de 2.443 secciones de Madrid casan con el seccionado de 2021 del SERPAVI.
4. **Precedencia: CM > SERPAVI.** `zone_rent` toma el alquiler CM cuando tiene valor, tal cual, con su nota y sin rango. Solo si no lo tiene usa la referencia. Sin ninguno, la fila CM con su motivo.
   - **Qué rellena hoy:** 126 municipios y un barrio. Sol no tiene ningún lugar con código postal (D-232 §4) y ahora toma la media de sus 7 secciones. Los demás barrios conservan su alquiler de D-232: no se pisa.
   - **Rol propio (`rent_m2_fill`), como D-234:** el código anterior lo ignora con el aviso «fit bindings ignored by this version», así que volver atrás es seguro sin borrar filas.
5. **Confianza.** 0,7 («Dato aproximado»): es otro estadístico de la misma fuente, escalado. 0,4 («Dato poco seguro») con menos de 30 contratos detrás de la mediana (38 municipios). 0,5 como máximo si son casas (26 municipios): con el €/m² de una casa, el coste de los m² del hogar se queda corto, y el texto lo dice («precio de casas unifamiliares, porque se alquilan pocos pisos»).
6. **Rango visible.**
   - **API:** el hecho de coste y la condición dicen «Alquiler ≈ 571 €/mes por 68 m² (8,4 €/m², referencia del Ministerio de Vivienda llevada a contratos firmados en 2024; un anuncio de hoy puede pedir más); la mitad de los contratos, entre 500 y 790 €». Los percentiles van para los m² del hogar y en decenas de euros. La nota y la fuente viajan con el dato (`fit.note`, `fit.source`).
   - **Contrato aditivo:** `estimated_cost_range` (`CostRange`: `low_eur`, `high_eur`, `source`) en `RankedZone` y `ZoneMatch`, solo al alquilar con la referencia; `null` en el resto.
   - **Web (`PriceTag`):** bajo «Alquiler ≈ … €/mes» y su fiabilidad de la tarjeta, dos líneas: «La mitad de los contratos, entre … y … €/mes» y, más pequeña, la fuente. Las filas siguen con «≈ … €/mes» y la fiabilidad (D-234).
   - **Textos de «Pueblos» de D-238:** `donde.ayuda.pueblos`, `resultados.pueblos_sin_alquiler` y `zona.sin_alquiler` ya no dicen que casi ningún pueblo publica el alquiler. Los 16 sin dato dicen que tienen tan pocas viviendas alquiladas que no se publica. Solo cuando `mivau_serpavi_alquiler` está en `/datasets` (revisión R-06), como la casilla de «Ocio» de D-236: antes del sync se quedan los textos de D-238.
   - **«Cómo lo calculamos»** explica el relleno sin escribir el cociente a mano («la subimos ligeramente para llevarla al nivel de la cifra de la Comunidad», revisión R-10).
7. **`fit-0.8` no cambia.** La fórmula del % es la misma; una zona antes sin alquiler ahora lo tiene, con su indicador, sus datasets y su linaje.
8. **Invariante del pitch** (`exampleScenario`, base local `housing_serpavi`).
   - **Igual:** `results` y `near_misses`, byte a byte salvo la clave nueva `estimated_cost_range: null`. Siguen fijados por `ranked_order` y `near_miss_order`: Latina, Moratalaz, Ciudad Lineal y Puente de Vallecas (98 %) … Villaverde; «Casi encajan» Chamartín, Salamanca, Centro, Chamberí y Retiro (93 %).
   - **Cambian los recuentos.** Encajan 42 zonas (antes 27): 15 pueblos con alquiler, del 76 % al 90 % (Villanueva del Pardillo, Velilla de San Antonio, Casarrubuelos…). Sin datos: 0 (antes 15). «+5 min a pie hasta colegio» suma 49 zonas (antes 17); «+150 €/mes», 3 (igual). Leyenda: «42 · 157 · 0». En 111 municipios que fallan el colegio, el % pintado sube de 1 a 7 puntos.
   - **Cifras y capturas que cambian** (las actualiza D en F6, con la fórmula; esta decisión no toca esos ficheros):
     - `pitch/guion.md` l. 64 y pasos 2.1, 2.2 y 2.4 (27 zonas, 15 sin datos, 44 y 17, 30 y 3, «En 15 zonas…»);
     - `pitch/slides.md` l. 96 y las capturas C1 y C3 (l. 194, 235, 238, 243 y 245);
     - `pitch/metodologia.md` l. 62;
     - `pitch/video_respaldo.md` l. 82 y 92;
     - `pitch/preguntas.md` l. 237 y 331.
   - **`golden_student`** (500 €/mes para 61 m²): ahora encajan unos 59 pueblos baratos y lejanos (antes unos pocos municipios). Se quita `max_results: 5` y queda `binding: budget` con `budget_step_adds_zones: 1`: el caso sigue comprobando que lo que limita es el presupuesto. Golden 10/10.
   - **Nota (revisión R-09, sin cambio de código):** `golden_student` ya no detecta que sus primeros resultados estén a más de 2 h en transporte de la universidad (los pueblos baratos de la sierra). Lo mira el banco de fórmulas (F4).
9. **Casos reales** (pareja, alquiler 1.500 €, transporte y salud; base local, solo lectura):
   - **«Pueblos»:** cumplen **122 de 138** (antes 2), y quedan 16 sin datos. Las 10 primeras, al 100 %: Casarrubuelos, Tielmes, El Álamo, Daganzo de Arriba, Serranillos del Valle, Belmonte de Tajo, Valdelaguna, Morata de Tajuña, Villanueva de Perales y Sevilla la Nueva.
   - **«Toda la Comunidad»:** cumplen 181 (antes 55). El top 10 apenas cambia: los 7 primeros son los mismos; Casarrubuelos entra 8.º y sale Móstoles; siguen Coslada y Parla.
   - **«Alrededores de Madrid»:** cumplen los 40 (antes 34).
10. **Despliegue: desplegar → recalcular → sincronizar → smoke.**
    - **Código nuevo con los datos de antes** (desplegado y sin sync): no hay filas `rent_m2_fill`, así que la búsqueda no cambia; y como `mivau_serpavi_alquiler` aún no está en `/datasets`, la web enseña los textos de «Pueblos» de D-238 («casi ninguno publica su alquiler…»), no los nuevos (revisión R-06). El pie ya nombra al Ministerio de Vivienda, cuyo valor tasado (D-227) ya se usa vía la Comunidad.
    - **Datos nuevos con el código anterior** (rollback): ignora el rol con un aviso en el log; los pueblos vuelven a «Sin datos» y no hace falta borrar filas.
    - **Recalcular en `housing`:** `make ingest DATASET=mivau_serpavi_alquiler` y `uv run hi-features compute --feature alquiler_m2_mensual_referencia`; después, `uv run python scripts/serpavi_summary.py` debe dar 163 municipios con referencia, 126 rellenos y un cociente de 1,0388.
    - **Tablas del sync** (`make supabase-sync PROFILE=demo` copia las tablas enteras): `source_registry` +1, `dataset_registry` +1, `dataset_version` +1, `metric_registry` +2, `feature_registry` +1 y `feature_value` +331 (179 municipios, 21 distritos y 131 barrios). Las 38.728 observaciones de `metric_observation` solo van con `PROFILE=full`; la API no las lee.
    - **Smoke:** `/search` con el ejemplo (golden: mismo orden), «Pueblos» con alquiler y `/datasets` con la cita del Ministerio.
## D-243 — Fórmula de encaje «cerca y plazas» (`fit-0.9`), el % con banda y el factor de reserva de SERPAVI en la mediana (2026-11-15)
Decisión de Mariano (F5, 15 nov) entre las tres finalistas del banco de fórmulas (F4): la A, «cerca y plazas», con el tope por trayecto (`f4_a_recomendada`), el % enseñado con banda y número, y 1,155 como factor de reserva del alquiler de SERPAVI. El banco corre fuera del repo, contra la base local en solo lectura; qué comprueba y con qué evidencia externa está en `pitch/banco_formula.md`. Código: `hi_domain/fit.py` y `search.py`, `hi_api/services/search.py` y `barrios.py`, `hi_contracts/public/search.py` (`MatchBand`) y `hi_features/methods.py` y `compute.py`. Evidencia: `evidence/gate-06/2026-11-15-fit09/`.

1. **Por qué** (cifras del banco con los datos del lote 4 y la fórmula `fit-0.8`):
   - **El % contradecía a la ficha.** Para una pareja con un bebé y 1.400 €, Puente de Vallecas salía 1.ª al 100 % y su «Qué falta» decía FALTA en escuelas infantiles. En una rejilla de 1.000 búsquedas sintéticas, 578 zonas salían al 90 % o más con FALTA en algo que la persona marcaba.
   - **No ordenaba.** En esa búsqueda empataban 45 zonas al 100 %; en la rejilla, el 29 % de las búsquedas tenía más de 10 zonas empatadas con la 1.ª.
   - **Con solo un presupuesto, el % medía lo que sobra.** Bellas Vistas «encajaba» al 5 %, y una zona que se pasaba salía al 0 % en «Casi encajan».
   - **Recomendaba sitios a los que no se llega.** Un estudiante con 500 € veía pueblos a más de 2 h de la URJC al 61-67 %.
2. **Qué cambia.** Cada pieza es una constante con nombre en `hi_domain/fit.py`:

   | Pieza | Regla | Parámetros |
   |---|---|---|
   | Cada minuto cuenta (`walk_utility`) | 1 en la puerta, 0,9 en el borde de la ventana y 0 al triple, lineal. Vale para los minutos a pie, el trayecto en transporte público frente a su ventana (30 min o el límite de la persona) y el desempate de D-239 | `WALK_UTILITY_AT_WINDOW = 0.9` |
   | Lo imprescindible puntúa (`_criteria_keys`) | Un servicio «imprescindible» de «Lo quiero a un paseo» también es criterio: detrás de los deseados y delante del presupuesto. «Ocio» sigue siendo un solo criterio (D-236) | – |
   | Cercanía y plazas (`with_capacity`) | Un servicio con fila en «Qué falta» vale 0,6 × cercanía + 0,4 × capacidad. La capacidad vale 0 a 0,4 veces la referencia y 1 desde la referencia. Es la ratio que enseña la fila (D-217): la del grupo de vecinos si se compara en grupo, y ninguna si la zona sola es «poco fiable» (entonces solo cuenta la cercanía). Transporte y ocio no tienen fila | `CAPACITY_WEIGHT = 0.4`, `CAPACITY_RATIO_ZERO = 0.4` |
   | Presupuesto con suelo y cola (`budget_utility`) | 1 hasta el 75 % del presupuesto (como antes), 0,6 justo en él (antes 0) y, pasado, baja hasta 0 al 25 % más. La cola solo mueve «Casi encajan»: la condición ya deja fuera esas zonas | `BUDGET_UTILITY_AT_LIMIT = 0.6`, `BUDGET_OVERRUN_TO_ZERO = 0.25` |
   | Trayecto imposible (`limit`) | Un trayecto de 3 días o más a la semana con nota 0 (3 veces su ventana o más, 90 min con la de 30, o sin llegar a las 9:00) deja el encaje en la mitad. Sin trayecto calculado no limita nada (nunca un 0) | `LIMIT_DAYS = 3`, `UNREACHABLE_FACTOR = 0.5` |
   | Tope por falta | FALTA en «Qué falta» en un servicio que la persona marca («Me importa» o «a un paseo», imprescindible o no): como mucho 0,894, que se lee 89 % (nunca «muy bien») | `SHORTAGE_CAP = 0.894` |
   | Tope por trayecto | Un trayecto de 3 días o más de más de 2 veces su ventana (60 min con la de 30): como mucho 0,744, que se lee 74 % (nunca «bien»). Sale de la evidencia externa del banco (encuesta de movilidad y bienestar) | `LONG_TRIP_WINDOWS = 2.0`, `LONG_TRIP_CAP = 0.744` |
   | Orden por el % que se ve (`ranking_key`) | En «Zonas que encajan», primero el % redondeado; a igual %, el desempate de D-239 (servicios cotidianos a un paseo y sus minutos) y después el encaje sin redondear, la confianza, los minutos al primer sitio y el id. «Casi encajan» conserva su orden (`near_miss_key`) | – |

   - **Orden de los límites:** primero la mitad, después el tope por falta y por último el tope por trayecto, como en el banco. Tras la mitad (0,5 como mucho) no se alcanza ningún tope.
   - **«Qué falta» no cambia:** sigue el método `gap-0.3` (D-217); la fórmula lee su estado y su ratio.
3. **Hechos nuevos en la tarjeta** (`facts`). Va el límite que fija el %, uno solo y el primero:
   - «Tardas 1 h 30 o más en llegar a {lugar}: el encaje se queda en la mitad», o «No llegas a {lugar} a las 9:00 en transporte público: el encaje se queda en la mitad»;
   - «Faltan escuelas infantiles: como mucho 89 %». Con varias filas, «Faltan centros de salud y colegios: …»; en un barrio, «… en Puente de Vallecas: …»;
   - «Más de 1 h de trayecto hasta {lugar}: como mucho 74 %».
   - Las duraciones siguen a la ventana de la persona: con «como mucho 45 min» salen «Más de 1 h 30 de trayecto» y «Tardas 2 h 15 o más».
   - **Siempre caben:** el límite, el hecho del trayecto del que habla y el coste se quedan; si pasan de 5, se va el criterio menos importante, como en D-240.
   - **Sin repetir:** cuando no se llega a las 9:00, el límite sustituye al hecho propio del trayecto («Con los horarios publicados no se llega…»), que diría lo mismo (revisión R-02).
   - Textos en `pitch/textos_web.md` (`hecho.limite.*`).
4. **El % en palabras.** Contrato aditivo: `match_band`, opcional, en `RankedZone` y `ZoneMatch` (`MatchBand`):
   - `muy_bien` desde 90, `bien` de 75 a 89, `regular` de 60 a 74 y `poco` por debajo de 60;
   - se calcula en el dominio a partir del % que se ve (`match_band`, con las constantes `MUY_BIEN_FROM`, `BIEN_FROM` y `REGULAR_FROM`); `null` si el % es desconocido;
   - **solo para una zona que cumple todas las condiciones** (decisión del orquestador, 15 nov): una de «Casi encajan», o cualquier `ZoneMatch` con `passes_all: false`, va con `match_band: null`. Si no, Chamartín saldría «muy bien» al 92 % pasándose del presupuesto. Esas zonas se leen por lo que les falta («se pasa ≈ …»), y su `match_pct` no cambia: sigue ordenando «Casi encajan» y pintando el mapa;
   - por eso `null` tiene dos sentidos: un % desconocido o una zona que no cumple todo. La web los distingue con `match_pct` y `passes_all`, que ya mira (revisión R-11);
   - los dos topes caen justo debajo de una banda (89 % y 74 %);
   - la web lo deriva con los mismos umbrales si no llega: **no se cambian sin avisar a la línea B**;
   - esquemas y tipos de la web regenerados (`make schemas`, `npm run -w apps/web contracts`). Los dos fixtures de búsqueda llevan la banda de su propio % donde la zona cumple todo y `null` donde no (revisión R-07); no se regeneran porque sus % siguen siendo de `fit-0.7` y los tests de la web los leen.
5. **«Qué falta» dentro de la búsqueda** (`hi_api/services/search.py`, `gap_data`). Antes `/search` cargaba el estado de 3 filas por hogar (las de la tarjeta) y en barrios ninguna.
   - Ahora cada zona trae el estado y la ratio de las cinco filas de servicio (`ZoneData.supply`), las marque la persona o no. Los mapas ya estaban en caché (`cached_row_map`), y así los datos de una zona no dependen de quién busca.
   - Solo se citan (datasets y avisos) las filas que usa la respuesta: las 3 de la tarjeta y las de los servicios marcados. La explicación del MCP (`explicar_zona`) cita las mismas (revisión R-03).
   - **Coste:** con la caché vacía (la primera búsqueda de cada proceso, o tras un sync) se leen 5 filas en lugar de 3. Medido en local con el ejemplo: 71 consultas y 0,44 s frente a 43 y 0,36 s; con la caché llena, 1 consulta. Contra Supabase, por el pooler, la primera búsqueda puede tardar alrededor de 1 s más (revisión R-10).
   - **Barrios:** toman las filas de su distrito, con su nombre, como proxy declarado, igual que su tarjeta (D-238 §7). `/search/barrios` las cita.
6. **Estabilización de ratios: probada y descartada** (revisión F4.7b del orquestador).
   - **Qué se probó:** sustituir la ratio por una estabilizada (empirical Bayes de Poisson-gamma, (O + k)/(E + k), con k = 3,69 casos esperados, el suelo de D-213). La pregunta era si Titulcia (1.400 habitantes, 1 escuela infantil para 51 niños) salía 2.ª para el bebé por el denominador pequeño.
   - **No la mueve:** estabilizada sigue en 1,18 veces la referencia y 2.ª al 98 %. En A las plazas valen lo máximo desde la referencia, así que encoger hacia 1 no baja una zona que está por encima.
   - **Empeora la rejilla:** 207 pueblos de menos de 5.000 habitantes en los top 5 frente a 187, 73 trayectos imposibles frente a 55, y el bebé menos estable con ruido (solape de 0,65 frente a 0,70).
   - No se implanta. Si algún día se adopta, va también en «Qué falta»: la tarjeta y el % leen la misma ratio, que hoy es la de D-217 en los dos.
7. **Resultados en el banco** (A con el tope por trayecto; entre paréntesis, `fit-0.8`):
   - expectativas: pitch 6/6 (5/6), ajuste 37/42 (20/42), control 17/20 (16/20) y la evidencia externa, de validación, 20/24 (19/24);
   - rejilla: 0 zonas al 90 % o más con FALTA (578), más de 10 empatadas con la 1.ª en el 8 % de las búsquedas (29 %) y 55 trayectos imposibles en los top 5 (103);
   - robustez frente al error de los datos: 0,85 de solape del top 10 y un 8 % de cambio material de la 1.ª en las personas; 0,84 y 7 % en la rejilla;
   - el tope por trayecto no tiene coste medido: cambia el % de 1.096 zonas de la rejilla, todas a más de 60 min.
8. **Paridad con el banco.** La implantación da los mismos órdenes y % que el preset `f4_a_recomendada` sobre el código de `5c22ded`.
   - En las 26 personas y las 1.000 búsquedas de la rejilla, el encaje sin redondear de todas las zonas coincide (diferencia máxima 0), con los mismos top 10, «casi» y recuentos. Pasa antes y después de recalcular el alquiler con 1,155.
   - Los informes `run` y `rejilla` del banco salen idénticos salvo en dos comprobaciones que fuerzan la ratio de plazas desde el banco (`Ctx.forced`), que `fit-0.9` lee de `ZoneData`. Si se le pasa el mismo forzado, también salen idénticos.
   - **Diferencia deliberada:** el banco convierte en criterio cualquier casilla de ocio imprescindible; aquí no, porque «Ocio» es un criterio con todas sus casillas y sin «Ocio» se ignoran (D-236). Ninguna persona ni búsqueda del banco marca ocio, así que no cambia ninguna cifra.
9. **Efecto en el ejemplo del pitch** (base local con el lote 4 y el factor 1,155):
   - Encajan las mismas 42 zonas, 157 no cumplen y ninguna sale sin dato.
   - **Top 10:** Puente de Vallecas 94, Latina 94, Usera 93, Moratalaz 93, Tetuán 92, Ciudad Lineal 92, Villaverde 92, Carabanchel 90, Coslada 90 y Leganés 90, todas «muy bien». Antes, Latina 1.ª al 98 % con cuatro empatadas.
   - **«Casi encajan»:** Chamartín 92, Arganzuela 92, Centro 91, Chamberí 91 y Retiro 91, todas por el presupuesto (antes Chamartín, Salamanca, Centro, Chamberí y Retiro al 93 %). Quedan a 1 o 2 puntos de las que encajan por la cola del presupuesto; no llevan banda y la web dice lo que les falta.
   - **Reality Check igual:** «+5 min a pie hasta colegio» suma 49 zonas y «+150 €/mes», 3.
   - **Desglose de Latina** (94 %): colegio a 6 min −1,1 · parada a 2 min −1,1 · centro de salud a 10 min −0,9 · 39 min a la Castellana −3,0 · alquiler 0. Antes solo restaba el trayecto (98 %).
   - **Golden:** fija `ranked_order`, `ranked_pct`, `near_miss_order` y `zones_passing` del ejemplo. `results_within_km` pasa de 15 a 16 porque Leganés (a 15,2 km de Azca en línea recta) entra en el top 10. El caso con 10.000 € y nada marcado reordena un poco su empate: Chamberí, Tetuán, Salamanca, Puente de Vallecas, Centro, Arganzuela, Usera, Ciudad Lineal, Carabanchel y Retiro. Golden 10/10.
   - **Otros casos:** para el bebé con 1.400 €, Moratalaz 1.ª al 98 % y Puente de Vallecas al 78 %; para el estudiante con 500 €, pueblos a 60-90 min arriba (Morata de Tajuña 68 %) y los que no llegan, al 31-32 % con el hecho de la mitad.
10. **Lo que no se hace en la fórmula:**
    - **Límite duro de trayecto por defecto:** Mariano eligió el tope (más de 1 h, como mucho 74 %), no una condición que deje sin resultados al estudiante.
    - **Pendiente (producto, no se cierra aquí):** el texto de la web «Sin un lugar de trabajo también salen pueblos; dinos dónde trabajas o elige Madrid capital» (propuesta de F4.7b para Titulcia), y validar los parámetros nuevos en la 2.ª ronda con usuarios (preferencias «A mejor que B», que el banco ya carga).
11. **Factor de reserva de SERPAVI: 1,155** (R-03 de D-242).
    - **Antes:** ninguno de los 126 municipios rellenos tiene tabla propia de la AEAT, así que tomaban la fila de la Comunidad (1,2085), que domina Madrid.
    - **Ahora:** toman la mediana de los factores de los 37 municipios de la tabla (`fallback: {median: true}`, `factor_from: mediana_municipios`, 1,1551). Su alquiler baja un 4,4 % (1,155 / 1,2085).
    - **Efecto en el banco:** el ejemplo del pitch, el bebé, la compra de P1 y los barrios no cambian. En la rejilla cambia el top 10 de 97 de 1.026 búsquedas y el recuento de 78, sobre todo con alquileres de 700 a 1.000 €. El estudiante con 500 € pasa de 59 a 68 zonas.
    - `scripts/serpavi_summary.py` dice qué factor usan los rellenos.
    - La feature pasa a la **versión 2**: cambia el método. El cálculo borra las filas de la feature antes de escribir (no quedan filas de la versión 1) y `feature_registry` tiene una fila por feature, que se actualiza (comprobado en `housing_fit09`: versión 2 en el registro y 331 filas, todas de la versión 2).
12. **Licencia del Ministerio de Vivienda.** La línea D comprobó en el navegador el aviso legal (https://www.mivau.gob.es/ministerio/aviso-legal): permite usos comerciales y no comerciales, citando la fuente y la fecha de la última actualización y sin sugerir respaldo. En `ministerio_vivienda.yaml`, `commercial_use: true` y el enlace correcto. Cierra el pendiente de D-242 §1.
13. **Riesgos:**
    - Es el cambio más grande a 8 días de la congelación, y cambia el guion («Puente de Vallecas y Latina, al 94 %») y las capturas.
    - Con ruido en los datos la 1.ª del pitch cambia a menudo (48 % de las réplicas del banco), siempre por otra zona con el mismo %. La web debe decir «empatan» (línea B).
    - Con ±2 min, el transporte como 1.ª prioridad mueve varios puntos.
    - Las plazas de un barrio son las de su distrito, y las de escuela infantil son escuelas por niño: nadie publica plazas (D-217).
    - Si se marca poco, salen pueblos pequeños bien dotados (Titulcia 2.ª al 98 % para el bebé). Desaparecen al poner dónde se trabaja o elegir «Madrid capital».
    - El suelo del presupuesto hace el top más sensible a ±5 % de presupuesto (7 de 10 en común en el ejemplo).
    - Los parámetros nuevos (0,9, 0,6, +25 %, ×0,5, 89 % y 74 %) salen de las bandas y de umbrales que ya había. No están validados con usuarios.
14. **Cómo volver atrás:** revertir el PR y desplegar.
    - **Contrato:** `match_band` es opcional. La web nueva con la API vieja lo deriva de `match_pct`, y la web vieja con la API nueva lo ignora (tipos de TypeScript, sin validación en tiempo de ejecución). Los hechos nuevos son textos como los demás.
    - **Factor:** volver a `fallback: {level: ccaa, code: "28"}` y recalcular `alquiler_m2_mensual_referencia`.
    - **Por piezas, solo algunas** (revisión R-05): `WALK_UTILITY_AT_WINDOW = 1` quita «cada minuto cuenta»; `CAPACITY_WEIGHT = 0`, las plazas; `BUDGET_UTILITY_AT_LIMIT = 0`, el suelo y la cola del presupuesto; `LIMIT_DAYS = 8`, los dos límites de trayecto con sus hechos; `SHORTAGE_CAP = 1`, el tope por falta. `UNREACHABLE_FACTOR = 1` no sirve, porque el hecho seguiría diciendo «la mitad». «Lo imprescindible puntúa», el orden por el % y `match_band` no tienen constante. La vuelta atrás de verdad es revertir el PR.
15. **Despliegue:** desplegar → recalcular → sincronizar → smoke.
    - **API nueva con los datos de antes:** funciona igual; el % ya es `fit-0.9`, y el alquiler de los pueblos sigue con 1,2085 hasta recalcular. El ejemplo del pitch no cambia con el factor.
    - **Recalcular en `housing`:** `uv run hi-features compute --feature alquiler_m2_mensual_referencia`, que sincroniza también el catálogo (la fuente del Ministerio y `limitations`). Después, `uv run python scripts/serpavi_summary.py` debe dar «126 con mediana_municipios (1.1551)» y la calibración en 1,0388.
    - **Sync:** `make supabase-sync PROFILE=demo` (`source_registry`, `feature_registry` y `feature_value`).
    - **Smoke de despliegue:** `scripts/smoke_demo.sh` exigía `fit-0.8` y, con `fit-0.9`, `make deploy-demo` acababa con error tras desplegar. Ahora acepta `fit-0.8` o posterior (revisión R-01).
    - **Smoke:** `scripts/golden_search.py` contra la base sincronizada (10/10) y `/search` con el ejemplo.

## D-244 — «Somos mayores»: un tipo de hogar para quien ya tiene 65 años o más (2026-11-15)
Prueba en persona del 15 nov con una persona mayor, en el móvil: «difícil de entender, muchos datos juntos». La auditoría (`prompts/UX_AUDITORIA_MOVIL.md`, §3 C4) encontró que el formulario no tenía sitio para ella: la opción que parecía la suya, «Con mayores a cargo», suma una persona más al hogar (más m², más precio y menos zonas). Decidido por Mariano con el orquestador; el flujo de la web es el que Mariano decidió tras la revisión del PR #79 (R-01 y R-02). Es aditivo y reversible: un campo opcional en el contrato, una línea del dominio y la web. **`fit-0.9` no cambia: la fórmula no lee el campo.** Código: `hi_contracts/public/scenario.py` (`Household.seniors`), `hi_domain/search.py` (`highlight_rows`), `apps/web/src/lib/scenario.ts` (`setOlderHousehold`, `setOlderPlace`, `retiredExampleScenario`), `lib/gaps.ts` (`householdRows`, `topRows`), `components/search/SearchCard.tsx`, `PlaceField.tsx` (`OlderPlaceField`) y `ExampleButton.tsx`. Evidencia: `evidence/gate-06/2026-11-15-ux-1/`.

1. **Qué es.** `Household.seniors: bool = False`, «Every adult is 65+ («Somos mayores»)». Dice quiénes son los adultos del hogar (1 o 2 personas de 65 años o más). **No suma personas:** el hogar sigue siendo el de «Solo/a» o «En pareja», con sus m² (D-214: 61 o 68 m²). Es distinto de `seniors_in_care`, que sí cuenta a una persona mayor que vive con el hogar y a la que se cuida («Con una persona mayor a la que cuidas»).
2. **El flujo de la web** («Somos mayores» es un botón más de «¿Quién va a vivir en la casa?», con la línea «Para personas de 65 años o más. Elige también si vives solo/a o en pareja.»). Al marcarlo:
   - **Lugar.** En lugar de «Trabajo en», el formulario pregunta, a la vista y no plegado, «¿Cerca de dónde queréis vivir? (opcional)», con dos opciones y el mismo buscador de sitios que el trabajo:
     - «Donde vivimos ahora»: un lugar `kind: other` con la etiqueta «donde vivimos ahora», en minúscula porque la API la dice a media frase («27 min en transporte público hasta donde vivimos ahora, llegando a las 9:00»), y nunca el nombre del sitio elegido;
     - «Cerca de nuestra familia»: un lugar `kind: family` con el nombre del sitio.
     Va con `max_minutes: 30` («Tardar como mucho», que se puede cambiar o quitar) y `days_per_week: 3`, así que el trayecto pesa como el de un sitio al que se va a menudo y los topes de D-243 se cuentan sobre esos 30 min. «Trabajo en» pasa, plegado, a «Más opciones», y «Cerca de mi familia o amigos» no sale (la familia ya está en la pregunta).
   - **Ámbito por defecto.** Si no hay ningún sitio y «¿Dónde?» está en «Toda la Comunidad», pasa a «Madrid capital» (`scope: madrid`). Se puede cambiar, y nunca pisa una elección. Sin sitio, en toda la Comunidad salían arriba pueblos pequeños bien dotados (D-243 §13: con el ejemplo anterior, 155 zonas y Anchuelo y Morata de Tajuña al 98 %).
   - **Preelegidos,** detrás de lo que ya hubiera y en este orden: «Centro de salud» (`salud`), «Metro o tren sin escaleras» (`sin_escaleras`) y «Transporte» (`transporte`). Todos se pueden quitar.
   - **Sin aviso de trabajo:** la lista no enseña «¿Trabajas fuera de casa? Dinos dónde…» (`resultados.sin_lugar`), y el aviso de empate dice «… o elige cerca de dónde queréis vivir…» en lugar de «… o dónde trabajas…».
   - **Tarjeta (R-01, y la regla de «lo que le falta que le afecte» de la entrega 2, adelantada por Mariano).** «Lo que le falta a esta zona» enseña primero las filas que importan al hogar, sea cual sea su estado, y después el estado (`householdRows` y `topRows` en `lib/gaps.ts`, con el hogar de la búsqueda, `result.scenario.household`, para que la tarjeta y la lista respondan al mismo hogar; antes de buscar, por estado, como siempre). Las filas del hogar son las de `highlight_rows` (el `gap_highlights` de `/search`), sin la de vivienda: escuela infantil con un hijo de 0 a 2 años (o sin edades), colegio con hijos, centro de salud y farmacia siempre, y centros de mayores con `seniors` o `seniors_in_care`. Entre ellas va primero lo que falta (FALTA, luego JUSTO) y después el orden del hogar; una «No comparable» del hogar va antes que cualquier otra fila y se enseña tal cual. Las demás filas solo rellenan si quedan menos de 3 del hogar con dato, por estado, y las de niños nunca rellenan en un hogar sin hijos. Vale para todos los hogares. Así, en Barajas, la 1.ª del ejemplo, una pareja jubilada ve centro de salud (No comparable), farmacias (CUBIERTO) y centros de mayores (No comparable), y no «Colegios · JUSTO» ni escuelas infantiles; una familia con un bebé sigue viendo arriba la escuela infantil; y una pareja sin hijos no la ve aunque sea la FALTA de la zona. La lista completa sigue en «Ver todo lo que falta». En el dominio, `highlight_rows` pone los centros de mayores delante con `seniors`; la tarjeta usa la misma regla, pero ordena las filas de `/gaps` de cualquier zona, también las que no están en la lista.
   - **Al desmarcarlo** se quitan `seniors` y el lugar «donde vivimos ahora» (`kind: other`, que solo crea este flujo y que ningún campo enseña sin «Somos mayores»: filtraría sin verse, revisión H1 del PR #79). Se quedan, a la vista y para que la persona los cambie: «Madrid capital», las tres prioridades y un lugar de la familia, que pasa a «Cerca de mi familia o amigos» en «Más opciones».
   - **Ejemplo de la portada:** «Ejemplo: pareja jubilada que quiere vivir cerca de su familia»: 2 personas, «Somos mayores», alquiler hasta 1.200 € al mes, «Cerca de nuestra familia» en Ciudad Lineal (la estación de metro de `/api/v1/places`, un sitio público; nunca una dirección particular), 30 min como mucho, 3 días, «Madrid capital» y los tres preelegidos. Con la API `fit-0.9` sobre `housing` (15 nov, solo lectura) salen **22 de los 131 barrios**, de Alameda de Osuna y Casco Histórico de Barajas (92 %) a Ventas, Pueblo Nuevo, Quintana y San Pascual (89 %), Arcos y Rosas (87 %)…; lo que más limita es el trayecto, y «Sin límite de tiempo hasta Ciudad Lineal (metro)» añade 62.
3. **Qué no hace.**
   - No cambia el % ni el orden por sí solo: ningún criterio ni condición lee el campo. Un test lo comprueba: la misma búsqueda con y sin `seniors` da las mismas zonas, los mismos % y los mismos recuentos de «¿Quieres ver más zonas?». Lo que cambia los resultados es lo que el flujo marca (el sitio, el ámbito y las prioridades), y todo se ve y se puede cambiar en el formulario.
   - No cambia los m², el precio ni los hechos de la tarjeta.
   - No marca la farmacia ni «Lo quiero a un paseo»: «¿Qué quieres tener cerca?» no tiene farmacia y un servicio a un paseo entra como «Solo zonas que lo tengan», es decir, como filtro. Que la farmacia ordene o filtre es una decisión aparte (auditoría, opción 3).
   - No es una etiqueta sobre la persona ni infiere nada de ella (CLAUDE.md §13): es una respuesta que la persona da y puede quitar. «Donde vivimos ahora» no se guarda ni se envía con nombre.
4. **Contrato.** Aditivo (el ejemplo y el lugar usan `kind: family` y `kind: other`, que ya existían): una búsqueda guardada o compartida antes significa lo mismo (`seniors: false`). La respuesta de `/search` lo devuelve dentro de `scenario`. Una API anterior rechaza el campo (`extra="forbid"`): la web y la API van en el mismo despliegue, como siempre. `kind: other` ya existía en `AnchorKind`.
5. **Golden.** `golden_senior` no usa el campo y no cambia: `scripts/golden_search.py`, 10 de 10 contra `housing` en solo lectura.
6. **Cómo volver atrás:** revertir el PR. Sin el campo, la única opción de mayores vuelve a ser la de cuidar a una persona mayor («Con una persona mayor a la que cuidas», antes «Con mayores a cargo»).

## D-245 — Claridad en el móvil, segunda entrega: la fila y la tarjeta esenciales, la zona en la dirección y la pantalla de zona plegada (2026-11-16)
Prueba en persona del 15 nov con una persona mayor («difícil de entender, muchos datos juntos») y un usuario técnico («muchísima información»). La entrega 1 (D-244, #79) arregló la letra, los botones y las palabras; esta ataca «demasiado a la vez» en la lista y la tarjeta, la opción 2 de la auditoría (`prompts/UX_AUDITORIA_MOVIL.md` §7). Decidido por Mariano. **Ni el contrato ni la fórmula cambian**; sí dos textos de la API, a petición del orquestador: «No comparable» (§7) y el trayecto a la familia o a casa (§9). **API y web se despliegan juntas** (la web enseña tal cual la explicación de «No comparable» de la API nueva). El golden sigue 10 de 10. Código: `apps/web/src/lib/essentials.ts` (nuevo), `lib/fit.ts`, `lib/gaps.ts`, `lib/nav.ts`, `lib/searchState.ts`, `lib/map/camera.ts`, `components/search/SearchResults.tsx`, `RealityCheck.tsx`, `components/zone/ZoneCard.tsx`, `FitDetails.tsx`, `OverviewSide.tsx`, `BarrioFit.tsx`, `components/map/MapProvider.tsx` y la pantalla de zona (`ZoneIntro.tsx`). Textos: `pitch/textos_web.md` (UX móvil 2). Evidencia: `evidence/gate-06/2026-11-16-ux-2/`.

1. **Fila de la lista** (también «Casi valen» y los barrios de un distrito): toda la fila es el botón, con una «›»; dice el nombre (18 px en el móvil), la banda en palabras (16 px) y «Unos 1.129 € al mes». Fuera de la fila: el %, «Distrito de Madrid», los m², «Dato aproximado» y la barra y la cabecera de empate. En el escritorio el % se queda, pequeño y en gris, tras la banda. El lugar («· Madrid») solo sale si dos filas a la vista se llamarían igual. En los barrios, sus 1-2 hechos salen al tocarlos (cuando el mapa lo dibuja).
2. **Encima de la lista, una sola línea:** «Hemos encontrado 42 zonas para vosotros» («para ti» si vive una sola persona: adultos, hijos y persona mayor a la que se cuida). El título concuerda: «Zonas que os convienen» («Zonas que te convienen» con una persona). Debajo de la lista: «Precios orientativos: hoy pueden ser algo más caros.», el aviso de empate, el de trabajo y «Hemos mirado las 199 zonas…».
3. **Tarjeta esencial:** «‹ Volver a la lista»; el nombre; qué es y su banda («Distrito de Madrid · Muy buena opción», «Barrio de Madrid · …», «Municipio · …»; revisión R-10 del #81); y tres datos:
   - lo que cuesta: «Unos 1.129 € al mes» y «Precio orientativo» (también al comprar);
   - lo que pidió, con sus minutos: los hechos de la API en su orden, sin el del coste y sin los paseos que la API añade de contexto (`CONTEXT_NEEDS`) a quien pidió menos de tres cosas. Los topes de D-243 se quedan con su frase y sin la coletilla del % («No llegas a la Castellana a las 9:00 en transporte público», «Más de 1 h de trayecto hasta…», «Faltan colegios»; revisión R-04); «Faltan …» se omite solo cuando la línea de lo que falta ya lo dice. Si un servicio de «Lo quiero a un paseo» o un trayecto con límite se cumple y ningún hecho lo dice (la API da 5 como mucho), su línea sale de la condición (`value` de `near:*` o `commute:*`);
   - lo que le falta que le afecte: las filas pertinentes (las del hogar, la regla de D-244, `householdRows`, y después las de lo que la persona marca en «¿Qué quieres tener cerca?» o «Lo quiero a un paseo», como `marked_rows` de la API; revisión R-02) con FALTA o JUSTO, primero FALTA, en palabras («Colegios: hay pocas aulas para tantos niños.»; en un barrio, «Farmacias en Barajas: …»). Sin ninguna: «No le falta nada de lo que buscáis» («buscas»; en un barrio, «En Barajas no falta nada de lo que buscáis.») solo si alguna es CUBIERTO y ninguna es «No comparable» ni SIN DATOS; si alguna lo es, «De lo que podemos comparar, no le falta nada.», sin el visto verde, y debajo la línea de §4 (revisión R-01).
   Debajo, «Ver más sobre {zona}» despliega todo lo de antes: la banda con el % y «¿Qué es el %?», el puesto y el empate («Igual de buena que Latina (94 %)»), «Lo que tienes aquí» con la fiabilidad de cada hecho, el desglose del precio sin repetir la cifra (para qué m², fiabilidad, rango y «Precio de contratos firmados en 2024; los anuncios de hoy suelen pedir más.»), «Lo que le falta a esta zona» entero y «Ver la zona». No se pierde ningún dato.
4. **«No sabemos si le faltan…» (decidido por Mariano, 16 nov: se queda).** Cuando alguna fila pertinente es «No comparable» o SIN DATOS, la tarjeta esencial dice «No sabemos si le faltan centros de salud o centros de mayores.» (en un barrio, «No sabemos si en Barajas faltan…»), bajo lo que falte o bajo «De lo que podemos comparar…». Es la regla de que UNKNOWN nunca es PASS (CLAUDE.md §14).
5. **La zona en la dirección:** la zona elegida en la portada va en `?zona={nivel}/{código}` (`/?zona=distrito/2807913`). Abrirla desde la lista añade un paso al historial: el botón atrás del navegador o del móvil vuelve a la lista, y «Volver a la lista» hace lo mismo (`history.back()`); pasar de una zona a otra en el mapa no añade pasos. Abrir el enlace abre la zona (antes de buscar, con su «Qué falta»); abierta así, «Volver» la cierra sin salir de la web. La lista sigue montada bajo la tarjeta, así que al volver está como estaba y el foco, que se perdió con la tarjeta, vuelve a la fila (nunca si la persona está en otro sitio, como el formulario). Al salir de la portada la zona elegida queda aparcada: volver a la lista por un enlace no la enseña ni un instante, y el botón atrás la vuelve a abrir. Cuando el mapa pasa de distritos a barrios con la búsqueda, la dirección sigue a la zona elegida (un barrio pasa a su distrito; un distrito se suelta). Se lee con `useSearchParams` en un componente sin nada que pintar dentro de `Suspense`, para que la portada siga saliendo del servidor. Los enlaces de antes no cambian (`/`, `/zona/…`, `/que-falta?zona=…`, `/zonas?fila=…`). En la pantalla de zona, tras buscar, «Volver al mapa de la región» pasa a «‹ Volver a la lista».
6. **Pantalla de zona:** la tarjeta esencial arriba, después los barrios que más convienen, y el contexto plegado en «Más datos de la zona»: seguridad percibida, «Otros datos de la zona», «Vivienda nueva y lo que viene», «Entorno», el contador de datos y «Ver las zonas en una lista». «Todos los centros» (la herramienta del mapa) y «Tu búsqueda» siguen fuera.
7. **Deuda de la entrega 1:**
   - **«No comparable»** no es «vive tan poca gente» (Barajas tiene unos 50.000 habitantes): con la gente de la zona y lo que tienen las de su tipo, le tocarían menos de 3,69 centros (D-213, `min_expected`), y con números tan pequeños ni tener cero se distingue del azar. Dice ahora «Para la gente que vive aquí le corresponden muy pocos centros (menos de 4) y, con números tan pequeños, no se puede saber si faltan…». En «Qué falta», la fila enseña la explicación de la API tal cual (`notComparableReason`, `lib/gaps.ts`): ya empieza por el motivo, en la unidad de su fila, y sigue con sus cifras; la frase de la web queda para la leyenda de «Qué falta», «¿Qué quiere decir cada estado?», la etiqueta «No comparable» para el lector de pantalla y una explicación que no empiece por «No comparable:» (revisión M-03). La API se corrige en su origen (`not_comparable_text`, `hi_domain/gap_impact.py`): en una fila de servicios (2SFCA, el denominador es gente) dice «No comparable: para la gente que vive aquí le corresponden menos de 4 {centros} y, con números tan pequeños, no se puede saber si faltan.», sin el número de habitantes («aquí viven muy pocas personas (50.375)» en Barajas); en la de vivienda, cuyo denominador es un recuento de hogares que también tiene que llegar al suelo, sigue «aquí viven muy pocos hogares de 4 o más personas (1)», que ahí sí es el motivo. Solo cambia el texto de `explanation`: ni el contrato, ni el estado, ni `reliable`. El 4 sale del suelo (`ceil(min_expected())`).
   - Los `title` que explicaban (el % de los barrios y las etiquetas de estado, «Junto con sus vecinos» y «No comparable») pasan a texto: «¿Qué es el %?» bajo los barrios donde se ve el %, y «¿Qué quiere decir cada estado?» sobre las listas de «Todas las zonas» con una fila.
   - «DISTRITO DE MADRID» de «Qué falta», en minúsculas, como la tarjeta.
   - El encuadre del mapa en el móvil mide en pantalla lo que lo tapa (el final de la cabecera y el principio de la leyenda); sin medida, lo calcula en rem con la raíz del móvil (antes, 130 y 100 px fijos medidos con 17 px: con 18 px la leyenda medía 125 px y el encuadre quedaba bajo ella).
8. **Propuestas de una búsqueda anterior (visto en producción por C tras desplegar la entrega 1).** Al desmarcar «Somos mayores» sin volver a buscar, «¿Quieres ver más zonas?» seguía ofreciendo «Sin límite de tiempo hasta donde vivimos ahora», y al pulsarla volvía a marcarlo, con su lugar. Regla general: una propuesta es la búsqueda que la calculó con un cambio, así que, cuando el formulario ya no coincide con esa búsqueda (`isStale`), no se ofrece («Estas propuestas eran de tu búsqueda anterior…», `rc.anterior`) y no se puede aplicar (`relaxAttempt` devuelve null); tampoco «Volver a mi búsqueda» (`undoAttempt`), que desharía lo cambiado. Al volver a buscar salen las de la búsqueda nueva.
9. **El trayecto a la familia o a casa no «llega a las 9:00».** El hecho y la explicación del trayecto (`commute_text`, `hi_domain/fit.py`) dicen «, llegando a las 9:00» solo para el trabajo y los estudios (`kind: work` y `study`); para la familia y «donde vivimos ahora» (`family` y `other`), «27 min en transporte público hasta Ciudad Lineal (metro)». El cálculo no cambia: sigue usando los horarios de un día laborable llegando a las 9:00 (D-220 y el proxy declarado de D-240), y así lo dicen las ayudas del formulario. Las fixtures de contrato y el golden son de trabajo y no cambian (10 de 10). Tampoco lo dicen cuando con los horarios publicados no hay trayecto (d534c0d, revisión R-04; corregido aquí en la revisión M-02): la familia y «donde vivimos ahora» leen «No llegas a Ciudad Lineal (metro) en transporte público» y «Con los horarios publicados no se llega a Ciudad Lineal (metro) en transporte público» (`at_nine`, `hi_domain/fit.py`, con su test en `tests/unit/fit/test_fit.py`); el trabajo y los estudios siguen diciendo «a las 9:00».
10. **Revisión independiente del #81 (R-01 a R-13).** Además de lo dicho arriba:
    - «tú» o «vosotros» según el hogar en una sola función (`voice`, `lib/fit.ts`): el título y la línea de la lista, el puesto, «¿Qué es el %?», «Les falta una sola cosa de lo que pedís», el título y el resumen de los barrios, «Buscando zonas para vosotros…» y el aviso de empate (R-03);
    - el panel de un barrio, al tocarlo, vuelve a decir su banda con el %, con quién empata, para qué m² es el precio y su fiabilidad (R-05);
    - el historial marca en su estado (`vfList`) el paso de una tarjeta abierta desde la lista, en lugar de recordarlo en memoria; un `?zona=` que no es una zona del mapa se trata como ninguna y la dirección vuelve a `/`; «‹ Volver a la lista» de la pantalla de zona vuelve dos pasos atrás a la lista de la que vino, sin apilar uno nuevo (R-06);
    - «No comparable» se explica por fila y en su unidad (centros: la prueba cuenta centros equivalentes, también para aulas y plazas, `hi_features/fca.py`); en vivienda, pocos hogares de 4 o más personas; la web enseña la explicación de la API tal cual (R-07);
    - al volver a la lista, el foco va a la fila si se ve y, si no, al título de la lista (R-09);
    - al comprar, bajo la lista, «Precios orientativos: son una estimación del precio de compra.» (R-10);
    - `rankingRows` (las marcas de empate de la lista) se borra: ya no tenía uso (R-13).
11. **Remate (revisión del #81 ya fusionado, M-01 a M-03 e I-03).** Solo la web y los textos; ni el contrato, ni la fórmula, ni la API cambian. Evidencia: `evidence/gate-06/2026-11-16-ux-3/`.
    - **«tú» o «vosotros» en todo lo que habla de la búsqueda del hogar y de sus resultados (M-01),** con `voice` (`lib/fit.ts`, que suma `presupuesto`, `tienes`, `cambias`, `gastes`, `mira` y `dinos`): «Casi valen» y lo que una zona no cumple en la tarjeta (`lib/shortfall.ts`: «Se pasa unos 120 € al mes de vuestro presupuesto», «Tarda unos 12 min más de lo que pedís», «No cumple todo lo que pedís.»), «Lo que tenéis aquí», «No lo sabemos: nos falta el dato para comprobar lo que pedís…», «Fuera de vuestra búsqueda», «Tiene lo que pedís. Aun así…», «No le falta nada de lo que buscáis», «Ningún barrio cumple todo lo que pedís. Mirad abajo qué pasa si cambiáis algo.», «… no podemos comprobar vuestro presupuesto.», la leyenda y la etiqueta del mapa tras buscar («¿Qué queréis ver?», «Zonas que os convienen», «Os conviene más»; revisión R-01 del #82), «¿Queréis ver más zonas?» con su entrada, su límite y su nota («No os decimos que gastéis más…») y «¿Trabajáis fuera de casa? Decidnos dónde o elegid «Madrid capital»…», como ya decía el aviso de empate. El aviso de empate de «Somos mayores» concuerda también con una persona que vive sola («… o elige cerca de dónde quieres vivir…»; antes «… dónde queréis vivir», revisión R-02 del #82).
    - **Siguen en «tú»**, porque hablan a quien maneja la pantalla o no dependen del hogar: el formulario (lo rellena una persona y su botón dice «Buscar zonas para mí»), lo que narra lo que esa persona acaba de hacer («Has cambiado tu búsqueda…», «Estas propuestas eran de tu búsqueda anterior. Pulsa…», «Esto es de tu búsqueda anterior.», «Ahora ves las zonas con:», «Volver a mi búsqueda»), «Toca uno para verlo en el mapa.», lo de antes de buscar, la portada, «Cómo lo calculamos», las notas de contexto de la pantalla de zona («no cambian qué zonas te convienen»), que salen igual sin búsqueda, y los hechos de la API («No llegas a … en transporte público»).
    - **El panel de un barrio (I-03)** ya no repite la banda ni el precio de su fila: dice el % (solo en el móvil, donde la fila no lo enseña), con quién empata, «Para un piso de unos 68 m²» con su fiabilidad y sus hechos. Un barrio sin contorno en el mapa (sus contornos sin cargar, o sin unidad administrativa) sale plegado como los demás: su fila es un botón que abre y cierra el panel (`aria-expanded`, uno a la vez), sin tocar el mapa.
    - **«No comparable» para el lector de pantalla (visto en producción por C):** la etiqueta dice tras su nombre el motivo de su fila, el mismo que se ve (`notComparableHelp`, `lib/gaps.ts`, con test): en la tarjeta y en «Todas las zonas» con una fila, el de su unidad (`notComparableText`; «¿Qué quiere decir cada estado?» de esa lista también); en «Qué falta» la etiqueta no añade nada, porque la explicación de la API (`notComparableReason`) va a la vista en la misma fila. Antes decía en todas las filas la frase común de «centros u hogares», que se queda solo en las leyendas.
    - **Este registro y `pitch/textos_web.md`** dicen lo que hace el código: «No comparable» (§7, M-03) y «a las 9:00» sin trayecto (§9, M-02).
12. **Cómo volver atrás:** revertir el PR (y antes el del remate, §11). No hay datos ni contrato que deshacer; los textos de la API vuelven con él.
13. **Deuda menor de las revisiones (18 nov, F7).** Solo la web, sus scripts y los textos; ni el contrato, ni la fórmula, ni la API cambian. Evidencia: `evidence/gate-06/2026-11-18-f7-web/`.
    - **Un minuto, en singular:** «Tarda 1 min más de lo que pides» (`minutesOver`, `lib/shortfall.ts`) y «Aparcamiento público a 1 min andando» (`parkingText`, `lib/environment.ts`), como ya decía `walkMinutesText`; con 2 o más, «unos». La comprobación del e2e (`nearMissLine`, `infra/deploy/e2e/shown_text.mjs`) ya no acepta «unos 1 min».
    - **«Somos mayores» con una persona sola** (D-244 §2) concuerda con el hogar, con `voice` (§10, que suma `mi`, `vives` y `fueras`): «¿Cerca de dónde quieres vivir?», «Donde vivo ahora», «Cerca de mi familia» (`olderPlaceText`, `lib/workPlaces.ts`). El lugar `kind: other` lleva la etiqueta de su opción, «donde vivo ahora» o «donde vivimos ahora» (`homeLabel`, `lib/scenario.ts`, con el mismo recuento que `speaksToMany`), y la web la cambia al cambiar el hogar y al abrir un enlace compartido, así que los hechos y las propuestas de la API dicen lo mismo que el formulario. Solo esas dos etiquetas: otra de un enlace compartido no se toca.
    - **El panel de un barrio (revisión R-06 del #82):** uno abierto a la vez también entre un barrio sin contorno y uno marcado en el mapa (marcarlo, en una fila, en «Ir a un barrio» o en el mapa, cierra el panel; abrir un panel suelta el barrio marcado); un panel abierto antes de que lleguen los contornos sigue abierto hasta cerrarlo; y en el escritorio el empate se oye una vez (con el panel abierto, lo dice `aria-describedby`, no el nombre del botón).
    - **«Cómo lo calculamos»** ya no dice que la lista enseña «Empatan al 94 %»: el empate está en «Ver más sobre…» de la tarjeta (`zona.empate`). El paso 2 del README habla de «zonas que te convienen» y sus bandas.
    - **Código sin uso:** `ZonePrice.long` y `ZonePrice.area` (`lib/fit.ts`), que ningún componente leía desde la tarjeta esencial (tsc lo confirma).
    - **`check-qa.mjs`:** la web y la API se eligen con `--base` y `--api` o con `QA_BASE_URL` y `QA_API_URL` (por defecto, `http://localhost:3011` y `http://localhost:8011`). El modo `barrios` toma el primer distrito de Madrid de la lista del ejemplo según la respuesta de la API (con `fit-0.9`, Puente de Vallecas; San Blas-Canillejas ya no sale en las 10 primeras) y comprueba lo de arriba con los contornos retenidos hasta abrir un panel. El modo `compra` busca lo que la web dice hoy: la nota tras «¿Qué es esto?», «Precios orientativos: son una estimación del precio de compra.» y, en Chamartín, su precio estimado con «Precio orientativo» y «Dato aproximado» (o, sin precio, `zona.compra.sin_precio`), en lugar de «puede faltar el precio: … no para los distritos» (2e0d28a), que D-234 dejó sin sentido.
    - **Privacidad de la evidencia:** `scripts/redact_paths.py` cambia también un slug de proyecto (`~/.claude/projects/<project-slug>`), que lleva el usuario del Mac, y `CLAUDE.md` §18 explica los marcadores.
    - **Cómo volver atrás:** revertir el PR.

## D-246 — Suelo público para vivienda: las parcelas del Portal del Suelo, como contexto que no puntúa (2026-11-18)
Idea de producto de Mariano, aprobada por él: además de decir **dónde vivir**, enseñar **dónde hay suelo público para construir vivienda**. Es la versión mínima de las herramientas de análisis de parcelas (Nestra, Sitescope) y el primer paso de «de dónde vivir a dónde construir». Es aditivo y reversible: un dataset del portal de la Comunidad que estaba en el catálogo sin ingerir, una métrica, una feature sin `fit` ni `gap_row`, cuatro campos opcionales en los `items` de `GET /features/{id}/values` y unas líneas en «Vivienda nueva y lo que viene» (D-241). **`fit-0.9` no cambia.** Código: `hi_contracts/catalog/pipeline.py` (`PublicLandParcelsPipeline`), `hi_contracts/catalog/manual.py` (`ParcelPointsTable`), `hi_ingestion/pipelines/zone_context/parcels.py` y `run.py` (`run_parcels_pipeline`), `scripts/portal_suelo_points.py`, `hi_features/methods.py` (`metric_items`, `item_dims`), `hi_api/routes/features.py` (`ContextItem`), `apps/web/src/lib/newHousing.ts` (`landLine`) y `components/zone/NewHousing.tsx`. Evidencia: `evidence/gate-01/2026-11-18/cm_parcelas_portal_suelo/` y `evidence/gate-06/2026-11-18-portal-suelo/`.

1. **Fuente y licencia.** «Parcelas publicadas en el Portal del Suelo 4.0» (`cm_parcelas_portal_suelo`, portal de datos abiertos de la Comunidad de Madrid, CC BY 4.0: el `license_url` de su CKAN es el de la 4.0; actualización diaria, «metadata_modified» 18-11-2026 06:36). Gestiona la Dirección General de Suelo. «Parcelas disponibles para venta o concesión administrativa, propiedad de la Comunidad de Madrid y de Ayuntamientos adheridos al Portal». Es un dataset del portal CM y cuenta como tal. Descargado el 18 nov (versión `2026-11-18-b96deb8ff739`).
2. **Cobertura (18 nov).** 525 parcelas (524 el 16 nov), 291 de uso principal residencial (`R`) en 29 municipios, con 394.298 m² edificables publicados. Casan los 29 por código (`28` + `municipio_codigo`) **y** por nombre con la geografía (`name_key`: «Molar, El» es «Molar (El)»). Madrid capital 38 (137.580 m²), Majadahonda 101 (29.312 m²), Pozuelo de Alarcón 44, Guadalix de la Sierra 14, Brunete 13, Boadilla del Monte 11… Una parcela residencial no publica su superficie edificable (Morata de Tajuña): su municipio sale con la parcela y la suma **desconocida**, nunca más corta. Un municipio sin parcelas en el portal tiene 0 (no es todo el suelo público: es el que se ofrece ahí).
3. **Qué significan los códigos (comprobado, no supuesto).** El CSV no los explica. La capa de las mismas parcelas en la IDEM de la Comunidad (WFS `UsoDelSuelo:IDEM_V_SUELO_PARCELA`, enlazada desde la ficha del dataset y la de la IDEM `spacm_parcelaspsuelo`) trae, junto a cada código, su descripción oficial (`DS_*_ES`), leída el 18 nov:
   - `regimen_codigo`: **V** «Venta»; **C** «Concesión / derecho de superficie / alquiler». **D** (12 parcelas, 7 residenciales) y **A** (1) llegan **sin descripción**. Las observaciones de algunas parcelas D dicen «Derecho de Superficie», pero la C oficial también lo incluye (y parcelas C de Alcobendas dicen lo mismo), así que D no se puede confirmar: **D y A no se enseñan** (la parcela sale sin régimen).
   - `clase_codigo`: **URB** «Suelo urbano»; **SEC** «Suelo urbanizable sectorizado». No se usa.
   - `urbanizacion_codigo`: **U** «Urbanizado»; **P** «Pendiente urbanización / no urbanizado». Una parcela trae «p» en minúscula, sin descripción: no se etiqueta. Va en la API (`stage`), no en pantalla.
   - `uso_principal_codigo`: **R** «Residencial» (también T Terciario, I Industrial, C Comercial, O Otros).
   El pipeline declara los códigos explicados (`regimes`, `urbanization`), los que la Comunidad usa sin explicar (`undocumented_*`) y los usos que no se cargan (`other_uses`: T, I, O y C). Cualquier otro código, también de uso, va a cuarentena y bloquea la carga: un código nuevo lo lee una persona antes de enseñarse, y ninguna parcela desaparece sin aviso. También van a cuarentena un enlace al visor que no empiece por `https://idem.comunidad.madrid/` (la web lo convierte en enlace, y además lo vuelve a comprobar) y una superficie con punto («12.192»): el fichero usa coma decimal, y un punto de miles se leería como 12,192 m². La muestra de los tests deja vacía la columna `contacto_direccion` (nombres, teléfonos y correos de personas), que el pipeline no lee.
4. **Madrid capital por distrito y barrio.** El CSV no trae coordenadas. Se usa la geometría de la propia capa de la Comunidad (preferida a las coordenadas del Catastro por referencia catastral, que no hizo falta pedir): `scripts/portal_suelo_points.py` lee el WFS una vez y guarda, para cada parcela de Madrid (50, de todos los usos), un punto **dentro** de su polígono (`representative_point`, nunca el centroide, que puede caer fuera), redondeado al metro y comprobado, en EPSG:25830. El fichero versionado `data/catalog/manual/portal_suelo_madrid_puntos.yaml` lleva la URL de la petición y la fecha de lectura; es entrada de la carga (entra en su checksum y su linaje), así que el pipeline funciona sin red (también en el paquete de demo offline). La carga sitúa cada punto en su distrito y su barrio con PostGIS (`ST_Contains` sobre `geo_admin_unit`). Una parcela de Madrid sin punto (añadida al portal después) o con un punto fuera de todo distrito va a cuarentena y **bloquea**: se vuelve a lanzar el script. Ninguno de los 38 polígonos residenciales toca más de un distrito. Resultado, igual al cruce del orquestador: **Vicálvaro 16** (67.808 m², todas en el barrio Casco Histórico de Vicálvaro, 10 de ellas en Los Berrocales), **Hortaleza 9** (Canillas 5, Pinar del Rey 4), **Fuencarral-El Pardo 7** (Peñagrande 6, Fuentelarreina 1), **San Blas-Canillejas 3** (Arcos, Canillejas y El Salvador), **Salamanca 1** (Fuente del Berro: el depósito de Ventas de Metro de Madrid, 32.697 m²), **Moncloa-Aravaca 1** (Valdezarza) y **Villa de Vallecas 1** (Ensanche de Vallecas). En 11 de los 131 barrios.
5. **Cálculo.** Métrica `suelo_publico_parcela_m2_edificable`: una observación por parcela residencial en su municipio (y en Madrid también en su distrito y su barrio), con sus m² edificables y, como dimensiones, su referencia, localización, parcela, régimen (solo V o C), gestor, enlace al visor y urbanización. Feature `suelo_publico_vivienda_m2` (método `metric_items` de D-241, `value: sum`): el valor es la suma de m² edificables y sus `items` son las parcelas, de mayor a menor; **el número de parcelas es el de sus `items`**. `metric_items` pasa a llevar a cada elemento las dimensiones de `item_dims` que tenga (aquí `parcel`, `regime`, `manager` y `url`). Por municipio (179 filas, 29 con parcelas), distrito (21) y barrio (131). **No se convierten los m² en viviendas:** el fichero no dice cuántas caben y no se inventa un ratio.
6. **API (aditivo).** `ContextItem` suma `parcel`, `regime` (`venta` | `concesion`), `manager` y `url`, que solo salen en los elementos que los tienen (`exclude_if`): las respuestas de Plan Vive y VEDA no cambian (test). El código desplegado antes no los conoce: con los datos sincronizados y la API anterior, los `items` llegan sin esos campos.
7. **Web.** En «Vivienda nueva y lo que viene» (pantalla de un municipio o de un distrito de Madrid, dentro de «Más datos de la zona», D-245 §6; nunca en la tarjeta esencial), la última línea: «Suelo público para vivienda: 16 parcelas, 67.808 m² edificables.», con la nota «Parcelas que la Comunidad de Madrid o los ayuntamientos ofrecen en venta o en concesión para construir vivienda. No dice cuántas viviendas caben.» y su fuente y fecha. Debajo, plegada, «Ver las 16 parcelas»: cada una con su localización y parcela (sin ninguna de las dos, «Referencia» y su código del portal), sus m² edificables, el régimen si la Comunidad explica su código, su gestor y «Ver en el visor de la Comunidad» (pestaña nueva; el icono sigue a la última palabra y, a 390 px, cabe en una línea de 44 px). Sin colores de estado ni de alarma; el texto no se dirige al hogar, así que no usa `voice()`. Una zona sin parcelas no enseña nada, ni «0 parcelas». «Cómo lo calculamos» lo cuenta en «Vivienda nueva y lo que viene», y el dataset sale en `/datasets` con su versión (los CM, uno más). Textos en `pitch/textos_web.md` (`zona.vivienda_nueva.suelo*`).
8. **Por qué no puntúa.** Una parcela en venta o concesión no es una vivienda que el hogar pueda alquilar o comprar: dice dónde se puede construir, no cuántas viviendas habrá, a qué precio ni cuándo. Por eso no tiene `fit` ni `gap_row` (test de catálogo), no filtra, no ordena y no entra en «Qué falta»; la búsqueda no la lee (`FIT_VALUES` solo trae features con `fit`).
9. **Invariante del pitch.** Golden 10/10 contra `housing_suelo` (la copia con estas filas), con `ranked_order` y `near_miss_order` del ejemplo. Las 9 búsquedas del golden y la de barrios en los 21 distritos dan la misma respuesta byte a byte con y sin las 331 filas de `suelo_publico_vivienda_m2` (borradas dentro de una transacción que se deshace).
10. **Orden en producción: desplegar → sincronizar → smoke.** La feature no tiene `fit`, así que sincronizar antes no rompe `/search`, pero la API anterior no sirve los campos nuevos de la lista. **Tras el sync no hay vuelta atrás sin retirar estas filas:** volver a un despliegue anterior con ellas en la base deja en `/datasets` y en el contador del pie un conjunto CM más que la web de entonces no enseña (D-231). Para retirarlas: borrar la fila `suelo_publico_vivienda_m2` de `feature_registry` (las de `feature_value` caen por CASCADE) y la versión de `cm_parcelas_portal_suelo` en `dataset_version`, o volver a sincronizar desde una base sin ellas.
11. **Descartado.**
    - Coordenadas del Catastro por referencia catastral: la capa de la propia Comunidad las da todas en una petición y es la fuente del dato.
    - Leer el WFS en cada carga: la demo offline no tiene red, y el punto de una parcela no cambia.
    - Un número de viviendas a partir de los m² (con una superficie media por vivienda): sería una cifra inventada.
    - Enseñar el régimen D como «derecho de superficie»: no hay texto oficial que lo diga.
    - Las parcelas de otros usos: el encargo es suelo para vivienda.

## D-247 — Datos para la versión para inversores: barrios piloto dentro de la M-40, comercio de proximidad, edificabilidad que queda y unidades del Catastro, como contexto que no puntúa (2026-11-19)
Decisión de Mariano del 19 nov: el modelo tiene tres patas (personas y ayuntamientos gratis; inversores y promotores pagan) y la versión para inversores enseña, por barrio, qué le falta, dónde hay suelo y si una operación sale viable. Piloto: Madrid capital, los barrios dentro de la M-40. Esta decisión cubre **solo los datos** (agente A); la API `/investors`, la calculadora de viabilidad y la web van aparte (agente B), que lee estas features por su id. Es aditivo y reversible: cinco datasets nuevos o por fin cargados, el padrón por barrio, ocho métricas y siete features sin `fit` ni `gap_row`. **`fit-0.9` no cambia.** Código: `hi_contracts/catalog/manual.py` (`PilotZonesTable`, `AreaPointsTable`), `hi_contracts/catalog/pipeline.py` (`MadridPremisesCensusPipeline`, `MadridBuildableAreasPipeline`, `CmDistrictConceptPipeline`, `PilotZonesPipeline` y los campos de barrio de `MadridPadronPipeline`), `hi_ingestion/pipelines/{premises,buildable,district_concept,pilot,padron}/`, `scripts/m40_barrios.py` y `scripts/veda_remanente_points.py`. Evidencia: `evidence/gate-01/2026-11-19/`.

1. **Barrios piloto (`data/catalog/manual/inversores_barrios_m40.yaml`, feature `piloto_inversores_m40`).**
   - **Método:** `scripts/m40_barrios.py` lee una vez de OpenStreetMap (Overpass, ODbL 1.0) las vías `highway=motorway` con `ref=M-40` (308 el 19 nov, datos de las 00:12 UTC), las une con un búfer de 25 m y toma el hueco interior, devuelto al eje con otros 25 m y simplificado a 5 m: un anillo cerrado de 238,6 km². Un barrio entra si su centroide (`ST_Centroid` de su polígono en `geo_admin_unit`) cae dentro. El YAML guarda la consulta, la fecha OSM, el día de lectura, el anillo con su `sha256` y, por barrio, la distancia del centroide al anillo y el % de su superficie dentro. El contrato rechaza un anillo editado a mano (no casa el checksum) y un barrio del borde sin su revisión.
   - **Resultado: 108 de los 131 barrios.** Enteros los 7 distritos de la almendra y Latina, Carabanchel, Usera, Puente de Vallecas, Moratalaz y Ciudad Lineal; en parte Fuencarral-El Pardo (6 de 8), Moncloa-Aravaca (6 de 7), Hortaleza (5 de 6) y San Blas-Canillejas (6 de 8); ninguno de Villaverde, Villa de Vallecas, Vicálvaro y Barajas.
   - **Borde, revisado a mano (15):** los que tienen el centroide a menos de 500 m del anillo o que la M-40 cruza (entre el 5 % y el 95 % dentro). Entran Fuentelarreina, Valverde, Mirasierra, Valdemarín, Campamento, Cuatro Vientos, Buenavista, Orcasitas, Pavones, Horcajo, Palomas y **Palomeras Sureste, el más ajustado** (centroide 150 m dentro, 44 % del barrio fuera). Se quedan fuera Rosas (centroide 284 m fuera, 68 % fuera), El Goloso (11 % dentro) y Valdefuentes (29 % dentro). Cada nota está en el YAML y viaja en el elemento de la feature (`stage: borde`, `note`).
   - **Sin red:** la carga (`hi-ingest run osm_m40`) lee el YAML versionado, que entra en su checksum y su linaje con la URL de la consulta; un cambio de los barrios de la geografía bloquea (`every_barrio_accounted_for`), y la carga vuelve a calcular con PostGIS, sin red, qué centroides caen dentro del anillo versionado (`ST_Within`): si no son exactamente los de la lista, bloquea (`pilot_is_the_ring`), así que una edición a mano de la lista o un cambio de los polígonos de los barrios se ve. El anillo es un derivado de OSM y conserva la ODbL (README). La API desplegada no tiene `data/catalog`: por eso el piloto llega a la base como feature (1 dentro, 0 fuera, en los 131 barrios).
2. **Comercio de proximidad: «Censo de locales, sus actividades y terrazas»** (`ayto_censo_locales_actividades`, datos.madrid.es, CC BY 4.0: el `license_url` de su CKAN es el de la 4.0, comprobado el 19 nov; diario; fichero de actividades cargado el 17 nov, versión `2026-11-19-d9df427e658e`). Complementario, como el padrón (D-209): es del Ayuntamiento.
   - **Qué se cuenta.** El fichero de actividades trae una fila por local y epígrafe (un local sin actividad sale una vez, sin epígrafe; comprobado: todos los locales del fichero de locales están en él con la misma situación). La ficha de estructura (versión mar/2022) manda contar los locales «Puerta de calle» y «Agrupado» (mercados, centros y galerías comerciales), nunca los «Puerta de calle asociado» (no son locales físicos) ni los de baja. «Interior» está en el fichero pero no en la ficha: no cuenta (51.587 locales; solo 53 de las tiendas de proximidad abiertas). Situaciones con su literal: Abierto, Cerrado, Obras, Uso vivienda, Baja y «Baja Reunificación» (la ficha dice «Baja R»).
   - **Cobertura (17 nov):** 225.941 filas, 203.816 locales; cuentan 142.211: 97.114 abiertos, 36.682 cerrados, 0 en obras y 8.415 en uso de vivienda. Los 131 barrios y los 21 distritos.
   - **Comercio de proximidad,** con los epígrafes y las descripciones del propio fichero: autoservicio (471101 autoservicio, 471103 tienda de conveniencia 24 h, 471104 alimentos no perecederos envasados), frutería (472101, 472102), carnicería (472201 a 472207: carnicería, charcutería, carnicería-charcutería, carnicería-salchichería, aves, huevos y caza con y sin obrador, casquería), pescadería (472301, 472302, 472303 bacalao y salazones), panadería (472401 a 472405: pan y bollería con y sin obrador, pastelería), otra alimentación (472501 lácteos, 472905 congelados, 472911 otro comercio de alimentación con vendedor), farmacia (477301) y droguería (477801). Fuera: grandes superficies de alimentación (471102), platos preparados, bodegas, tabaco, helados, golosinas, frutos secos, churrerías, herbolarios, perfumería, puestos y todo el comercio no alimentario. Un local cuenta una vez aunque tenga varios epígrafes. 12.379 tiendas abiertas en la ciudad.
   - **Lo que no se lee.** Un código de situación, de acceso o de epígrafe no declarado (o con otro literal) va a cuarentena y bloquea; también una descripción de un epígrafe de proximidad que cambie, una fila sin identificador de local y un local cuyas filas no digan el mismo acceso, situación y barrio (se cuenta una vez). Los epígrafes que el fichero marca como pendientes («999 SIN ASIGNAR», «PTECO1/PTECO2 PTE. CODIFICAR»: 185 filas) van a cuarentena sin bloquear: su local cuenta por su situación, pero su actividad es desconocida, nunca una tienda ni un 0; los locales abiertos sin actividad legible se publican aparte (`grupo: sin_actividad`, 1.968), así que la cifra de proximidad es un mínimo. Un código pendiente con otro literal bloquea. La ratio de cuarentena de los checks comunes cuenta solo lo que bloquea. Un local sin distrito ni barrio (1) se lista y no cuenta en ningún sitio (bloquea si pasan de 50).
   - **Features (por distrito y barrio):** `locales_abiertos_1000hab` (abiertos por 1.000 empadronados), `locales_cerrados_pct` (cerrados entre abiertos, cerrados y en obras; sin los de vivienda ni las bajas) y `comercio_proximidad_1000hab`. La métrica `locales_comercio_proximidad` guarda además el recuento por grupo.
3. **Población por barrio.** El repo solo tenía el padrón por distrito. El mismo fichero del padrón (versión `2026-11-11-f052edc26159`, 1 oct 2026) trae el barrio de cada fila: el pipeline publica ahora también el total de cada barrio como `poblacion_padron_barrio` (parser 1.1, la versión se reprocesa en su sitio). Las filas de los distritos salen idénticas (mismo `md5` de las 462 filas que en `housing`); las de barrio llevan su nombre del padrón (`DESC_BARRIO`). El fixture del padrón renumera, con su nombre, los barrios que la geografía de muestra no tiene (`scripts/build_padron_fixture.py` hace lo mismo al regenerarlo). Una fila sin barrio, o con un barrio que no se lee (este va a cuarentena), cuenta en su distrito y no en un barrio: la población del distrito nunca depende de la columna de barrios. Dos personas de Villaverde no tienen barrio; si un distrito perdiera más del 0,1 % así, la carga se bloquea. **Decidido:** los checks de barrio (los 131 y que sumen su distrito) son críticos y bloquean también la carga mensual del padrón por distrito, como cualquier otro check: nunca se publica media versión. Si una reforma de barrios lo bloqueara, se publica el distrito solo quitando `barrio_column` y `barrio_metric_id` del YAML del pipeline hasta actualizar la geografía.
4. **Edificabilidad que queda: «PGOUM 97. Edificabilidad remanente en ámbitos»** (VEDA, `ayto_edificabilidad_remanente_ambitos`, datos.madrid.es, CC BY 4.0, semestral; fichero de julio de 2026, «Estado del desarrollo a fecha» 1-7-2026). Complementario.
   - **Qué trae:** una fila por ámbito (229 filas, 225 ámbitos; cuatro en dos etapas, «Etapa 1» y «Resto») con su distrito, su situación (fase de edificación, de gestión y/o urbanización, pendiente de planeamiento de desarrollo, pendiente de plan de sectorización) y los m² edificables disponibles por uso. Se quedan los ámbitos con m² residenciales (colectiva más unifamiliar): 152 filas, 13,41 millones de m² en 20 distritos y 66 barrios (50 de ellos piloto); 21 son solo de otros usos y 56 no tienen nada pendiente.
   - **Prudencia.** Una celda vacía no es un 0: un ámbito con las dos celdas residenciales vacías y algún otro uso con dato no es residencial; uno con todos los usos vacíos se queda con valor desconocido y deja desconocida la suma de su zona. Con una celda residencial con cifra y la otra vacía (42 ámbitos), la vacía se lee como «ese tipo de vivienda no está en el ámbito» y se cuenta (`partial_blank`), para que un cambio en cómo rellena el Ayuntamiento se vea. El «Nº de viviendas» del fichero es la edificabilidad entre 100: **no se lee**, y no se convierten m² en viviendas. Una situación nueva bloquea.
   - **Dónde está cada ámbito.** El fichero solo da el distrito. `scripts/veda_remanente_points.py` lee una vez la capa de ámbitos vigentes del propio visor VEDA del Ayuntamiento (servicio del Departamento de Análisis Urbano, `Ambitos_Vigentes_julio26`, EPSG:25830; su ficha del Geoportal remite al aviso legal de datos.madrid.es) y versiona, para cada ámbito, un punto dentro de la parte de su polígono que cae en el distrito del fichero (los 225 casan por código) y el % de su superficie en el barrio de ese punto (`veda_remanente_puntos.yaml`, entrada de la carga con su checksum y su linaje). La carga sitúa el punto con PostGIS; un ámbito sin punto, o con el punto fuera de su distrito, bloquea. 24 ámbitos ocupan varios barrios (menos del 90 % en el del punto; el que menos, 32 %): cuentan enteros en ese barrio y lo dice su nota.
   - **Feature `edificabilidad_remanente_residencial_m2`** (método `metric_items`, por distrito y barrio): la suma de los m² y sus elementos (ámbito o etapa, nombre, situación, tipo de vivienda en `use`, nota), primero los que están en fase de edificación. Un barrio sin ámbitos tiene 0.
5. **Contexto de la Comunidad (puntúa en el concurso: portal de datos abiertos de la CM).**
   - **«Catastro Inmobiliario. Unidades urbanas por uso. Municipios»** (`cm_catastro_unidades_urbanas_uso`, CC BY 4.0, «Fecha Actualización 25-06-2026», Dirección General del Catastro; 2003 a 2026, se cargan 2024 a 2026). Los 179 municipios casan por código. 2026: 171.545 unidades comerciales en la Comunidad (Madrid 96.106) y 99.820 de suelo vacante (Madrid 13.813).
   - **«Catastro Inmobiliario. Inmuebles por distrito y uso»** (`cm_catastro_inmuebles_distrito_uso`, CC BY 4.0, «Fecha Actualización 06-10-2026»; 2011 a 2026, se cargan 2024 a 2026). Sirve: los 21 distritos con viviendas colectivas y unifamiliares, aparcamientos, comercial, industrial, oficinas y «resto de usos». No trae código: el distrito sale del texto del concepto y casa por nombre con la geografía (pipeline `cm_district_concept`); las filas «sin asignar distrito» no se cargan y se cuentan (en 2026 llevan «-»; en 2024 y 2025, cifra: 773 comerciales en 2025, `unassigned_with_figure`). Una fila sin uso va a cuarentena. En 2026 suma 95.742 inmuebles comerciales en los distritos frente a 96.106 unidades en la ciudad. No sirve para el suelo vacante: va dentro de «resto de usos».
   - **Features:** `unidades_comerciales_1000hab` (por municipio, entre la población del censo anual de 1 de enero de 2025, con la Comunidad como referencia; por distrito de Madrid, con la tabla por distrito entre el padrón) y `suelo_vacante_unidades` (por municipio: un **recuento** de unidades, no una superficie).
6. **Por qué no puntúa.** Son datos para decidir dónde construir o invertir, no para elegir dónde vivir: un local cerrado, un ámbito con edificabilidad o un solar del Catastro no son una vivienda que un hogar pueda alquilar o comprar, y el piloto solo delimita una zona. Por eso ninguna de las siete features tiene `fit`, `gap_row` ni modelo, todas llevan `context_only` (test de catálogo `test_investor_data_is_context_never_a_score`), no filtran, no ordenan y no entran en «Qué falta»; la búsqueda no las lee (`FIT_VALUES` solo trae features con `fit`).
7. **Invariante del pitch.** Golden 10/10 contra `housing_inv_a` (la copia con estas filas). Las 9 búsquedas del golden y la de barrios en los 21 distritos dan la misma respuesta byte a byte con y sin las 1.119 filas de las siete features (borradas, con sus filas de `feature_registry`, dentro de una transacción que se deshace), y la misma que `housing` en solo lectura (sha256 de las 30 respuestas, `74c3542fb3be9d41` en las tres).
8. **Orden en producción: desplegar → sincronizar → smoke.** Sin migraciones. Las features no tienen `fit`, así que sincronizar no cambia `/search`; pero el contador de `/datasets` y del pie pasa de **36 a 38 conjuntos CM** (53 a 58 en total, D-231) por estos datos, y a **39 CM y 59 en total** con el PEM visado del #94, que suma uno más; la web anterior no enseña estos datos. **Tras el sync no hay vuelta atrás sin retirar estas filas:** volver a un despliegue anterior con ellas en la base deja dos conjuntos CM más en el contador que esa web no usa. Para retirarlas: borrar las siete filas de `feature_registry` (las de `feature_value` caen por CASCADE), las versiones de `ayto_censo_locales_actividades`, `ayto_edificabilidad_remanente_ambitos`, `cm_catastro_unidades_urbanas_uso`, `cm_catastro_inmuebles_distrito_uso` y `osm_m40` en `dataset_version`, o volver a sincronizar desde una base sin ellas. La versión del padrón se queda (sus filas de distrito no cambian).
9. **Revisión independiente (`reviewer`, R-01 a R-09).** Sin bloqueantes. Aplicado: un barrio ilegible del padrón ya no saca la fila de su distrito (R-01); los checks de barrio del padrón se quedan críticos, decidido y escrito en el §3 (R-02); un local sin identificador o con filas que no coinciden bloquea (R-03); la ratio de cuarentena del censo solo cuenta lo que bloquea (R-04); se cuentan los ámbitos con una celda residencial vacía (R-05); `m40_barrios.py` valida antes de escribir y deja un borrador si falta una revisión (R-06); `veda_remanente_points.py` para si un ámbito está en dos distritos o tiene dos polígonos (R-07); una fila sin uso de la tabla por distrito va a cuarentena y se cuentan las «sin asignar» con cifra (R-08); y los epígrafes pendientes se comprueban con su literal (R-09).
10. **Descartado.**
   - Repartir los m² de un ámbito entre barrios por superficie: supondría que la edificabilidad está repartida por igual.
   - Las parcelas del visor VEDA (capa de parcelas urbanísticas): no están en el portal de datos abiertos; el fichero abierto es por ámbito.
   - Los locales interiores, sin documentar en la ficha.
   - El PEM visado de la CM (coste de construcción) y el PGOUM por parcela: fuera de este encargo.

## D-248 — Versión para inversores: viabilidad v0 y la sección «Para inversores» (2026-11-19)
Decisión de Mariano del 19 nov, con el análisis de Nestra y Sitescope (privado, fuera del repo). Además de «dónde vivir» (personas) y «qué falta» (ayuntamientos), Vida Fácil dice a quien construye **qué le falta a cada barrio, dónde hay suelo y si una promoción sale**, con la fuente de cada cifra. Es aditivo y reversible: un módulo puro de dominio, tres rutas nuevas de la API, una sección nueva de la web y un dataset nuevo del portal de la Comunidad (los visados, con el PEM). **`/search` y `/gaps` no cambian, `fit-0.9` tampoco:** nada de esto pasa por la búsqueda. Código: `hi_domain/viability.py`, `hi_domain/viability_data.py` e `hi_domain/investors_pilot.py` (generados por `scripts/export_investor_data.py`), `scripts/pem_visados_cm.py`, `hi_contracts/catalog/manual_permits.py` y `pipeline.py` (`PermitBudgetPipeline`), `hi_ingestion/pipelines/permits/`, `hi_contracts/pro/investors.py`, `hi_api/routes/investors.py`, `hi_api/services/investors.py`, `apps/web/src/app/(vida)/inversores/`, `components/investors/` y `lib/investors.ts`. Textos: `pitch/textos_web.md` §11. Evidencia: `evidence/gate-01/2026-11-19/cm_visados_presupuesto_obra/` y `evidence/gate-06/2026-11-19-inversores/`.

1. **Modelo de negocio, tres patas.** Las personas y los ayuntamientos usan Vida Fácil gratis; inversores y promotores pagan un plan («Inversor»; hipótesis del análisis: 99–199 €/mes, sin validar). Explica cómo se financia el proyecto sin degradar la parte pública (CLAUDE.md §3 y §16). **Durante el concurso solo se ve la etiqueta «Plan Inversor (acceso libre durante el concurso)»: sin cobro, sin login y sin datos de nadie.** Sustituye al modelo del 12 nov, en el que pagaban los ayuntamientos; D cambia el pitch.
2. **Piloto:** los barrios de Madrid capital dentro de la M-40 (D-247, línea A: 108 de 131, con la M-40 de OpenStreetMap). La lista viaja a la API como módulo generado (`investors_pilot.py`, el mismo patrón que `zoning_data.py` de D-238): la imagen de la API no lleva `data/`. `make lint` y la CI comprueban que el módulo coincide con el YAML (tras el rebase sobre A, con sus 108 barrios). Sin lista, la API la devuelve vacía con un aviso y la web dice «La lista de barrios del piloto aún no está cargada». La feature `piloto_inversores_m40` de A dice lo mismo en la base; la API no la necesita.
3. **Método residual (viabilidad v0, `viability-0.1`).** Todo en **m² construidos**: la edificabilidad de la parcela o del ámbito, el PEM de los visados (superficie a construir), el precio estimado (valor tasado de la ciudad repartido por el valor catastral por m² construido, D-234) y el alquiler de referencia (m² del Catastro, D-242). La ficha de la Comunidad del valor tasado solo dice «Euros/m2» y la nota metodológica del Ministerio no aclara la superficie; las demás piezas son construidas, así que se trata todo como construido y se dice.
   - ingresos I = A × P × (1 + prima) × fp;
   - construcción C = A × PEM × k × fc;
   - comercialización y otros G = g × I;
   - suelo S (opcional: total o por m² edificable);
   - margen sobre ventas m = (I − C − G − S) / I, antes de financiación e impuestos;
   - **valor residual del suelo** V = I × (1 − m*) − C − G, lo máximo que se puede pagar por el suelo para llegar al margen objetivo m*;
   - rentabilidad bruta del alquiler = A × r × 12 × fp / (S + C). **Nunca sin suelo** (revisión del #94: sin suelo, en Pinar del Rey daba un 21,8 % engañoso): sin precio, S = V («si pagas por el suelo lo máximo que deja el margen objetivo»: un 5,0 %); si V ≤ 0, no hay rentabilidad que dar. Con el suelo a su valor residual, C + V = I × (1 − m* − g), así que la rentabilidad no cambia entre escenarios (es el alquiler frente al precio de venta) y la web lo dice;
   - escenarios: base (fp 1, fc 1), optimista (1,10 y 0,95) y pesimista (0,90 y 1,05), los de la sensibilidad de Nestra.
4. **Entradas por defecto, todas editables y marcadas «dato», «supuesto» o «lo pones tú»:**
   - **m² edificables:** los de la parcela del Portal del Suelo (D-246) o del ámbito con remanente (D-247); sin ellos, los pone la persona (50 m² como mínimo). La calculadora empieza en el mayor. Al elegir una parcela de la Agencia de Vivienda Social o en concesión, un aviso dice que el precio libre y el valor residual no valen para vivienda protegida ni para una concesión.
   - **Precio de venta (dato):** `precio_compra_estimado_m2` del barrio (o del distrito). **Prima de la vivienda nueva (dato):** el valor tasado de la vivienda libre de hasta 5 años frente al de toda la vivienda libre en Madrid (D-241): 5.458,5 / 4.993,3 = **+9,3 %** (2025).
   - **Alquiler (dato):** `alquiler_m2_mensual_referencia` del barrio (o del distrito), con la mitad de los contratos (p25–p75).
   - **PEM (dato): 644 €/m²**, viviendas en bloque, 2025 (634 en 2024). Recalculado por `scripts/pem_visados_cm.py` desde el fichero oficial de la Comunidad «Visados, superficie y presupuesto de dirección de obra de edificios…» (portal 1006022, Estadística de Obras en Edificación del Ministerio de Vivienda, «Fecha Actualización 05-03-2026»): 1.712.790 miles de € entre 2.658.184 m². Versionado en `data/catalog/manual/pem_visados_cm.yaml` con la URL, el fichero, su sha256, el día leído y cada año. El fichero no trae territorio y su ficha dice «Ámbito: Toda España», pero es el portal de la Comunidad y la escala es la regional (1.641 visados de obra nueva en 2025). **La superficie (revisión del #94, comprobado el 19 nov):** la ficha de la CM solo dice «m2», y las notas metodológicas públicas de la misma estadística (Instituto Aragonés de Estadística; definiciones del Anuario de Murcia) definen el PEM («suma de los productos del número de cada unidad de obra por su precio unitario», sin IVA) pero no si la «superficie a construir» incluye la de bajo rasante. El formulario del visado pide la superficie total a construir y, aparte, las plantas bajo rasante, así que lo más probable es que el total incluya sótanos y garajes. La edificabilidad de una parcela es sobre rasante: el PEM por m² reparte el presupuesto también entre garajes, más baratos, y se multiplica solo por los m² sobre rasante, así que el coste queda **por debajo**. Lo dice el aviso junto al coste. **El PEM visado suele declararse a la baja: lo dice un aviso fijo, y junto al coste se lee «Mínimo oficial (PEM visado); el coste de mercado suele ser mayor: ajusta el coeficiente».**
   - **El PEM es un dataset CM registrado** (decisión del 19 nov), con el patrón de tabla versionada de D-241: ficha `cm_visados_presupuesto_obra` (portal CM, CC BY 4.0, atribución de la fuente `comunidad_madrid_ckan`), métrica `pem_visado_m2` (región, por año y tipo de edificio: en bloque, unifamiliar adosada y aislada) y feature `pem_visado_vivienda_bloque_m2` (región, sin `fit` ni `gap_row`). La carga (`permit_budget_table`) lee el fichero versionado, nunca el portal; el contrato `PermitBudgetTable` comprueba que cada €/m² es su presupuesto entre su superficie, y un check crítico, que cada año tenga las viviendas en bloque. La API lee la feature, con su dataset y versión; en una base sin cargar, la misma cifra de `viability_data.py`. **El contador de datasets CM sube en uno** al cargar y sincronizar: de 38 a **39 CM y 59 en total**, sobre los de D-247 (README y D-247 dicen lo mismo; D actualiza el pitch).
   - **Coeficiente sobre el PEM (supuesto): 1,36** = 1 + 19 % de gastos generales y beneficio industrial (13 % + 6 %, los de la obra pública, RD 1098/2001 art. 131) + 8 % de honorarios técnicos (suelen ir del 6 al 10 %) + 5 % de licencia, ICIO y tasas (ICIO de Madrid, 4 %, y ~1 % de tasas) + 4 % de otros (decenal, organismo de control, ensayos, acometidas). Resultado por defecto: 876 €/m² construido.
   - **Comercialización y otros (supuesto): 8 % de las ventas** = 3 % de comercialización + 3 % de gestión + 2 % de notaría, registro e impuestos de la obra nueva.
   - **Margen objetivo (supuesto): 20 %**; un promotor pide entre el 15 y el 20 % o más, y sin financiación se toma el alto.
   - **Financiación:** fuera de la v0, y se dice (aviso fijo). La TIR y el ROE con flujo de caja, para la v1.
5. **Semáforo y veredicto (umbrales supuestos, documentados en pantalla), solo con precio del suelo:** **«Sale»** si m ≥ m* (20 %), **«Ajustar»** si min(10 %, m*) ≤ m < m*, **«No sale»** por debajo (si pierde, «pierde el X % de lo que vende»). Con un objetivo por debajo del 10 %, el suelo de «Ajustar» baja al objetivo: no hay franja de «Ajustar» y la API ya no responde 422 (revisión del #94). Tests con los bordes exactos del 20 % y el 10 % y un «no sale» con margen positivo. **Sin precio del suelo no hay veredicto** (decisión del 19 nov: no tiene sentido); el titular de cada escenario es el valor residual, «Lo máximo que se puede pagar por el suelo: V (€ por m² edificable), para un margen del 20 %», o, si ni gratis llega, «Ni con el suelo gratis se llega al margen objetivo…». En la API, `verdict` es `null` y `headline` dice eso. El semáforo es el único sitio con colores de estado (los de CUBIERTO, JUSTO y FALTA) y siempre lleva icono y palabra.
6. **Comprobación de demanda.** Con la renta neta media de los hogares del barrio (`renta_neta_media_hogar`, panel del Ayuntamiento, Urban Audit del INE) y una vivienda tipo de 80 m² construidos (supuesto: 2–3 dormitorios; 68 m² útiles, la mediana de los hogares de 2 personas, D-214, más zonas comunes), la cuota de una hipoteca al 80 % del precio, 30 años y 3 % fijo (supuestos), el alquiler, y la entrada en años de renta. **Umbral de esfuerzo: 30 %** de la renta media, el de la Ley 12/2023 por el derecho a la vivienda, art. 18.2 a) (zonas tensionadas); el repo no tenía uno. La ley cuenta también los gastos y suministros básicos; aquí solo la cuota o el alquiler, así que la cuenta es optimista, y se dice. **No se inventa una distribución de rentas: es la media, y se dice.**
7. **Avisos fijos** (en la API y en la ficha, también en papel): «No es una tasación ni un informe vinculante ni una garantía de rentabilidad»; «Contexto urbanístico, no qué se puede construir»; «Sin dato no es 0»; financiación fuera; el PEM visado suele declararse a la baja.
8. **API (contrato nuevo, aditivo; `hi_contracts.pro.investors`, esquemas en `data/schemas/api/`).**
   - `GET /api/v1/investors/zones`: los barrios piloto con su distrito, las filas FALTA y JUSTO de su distrito (de los mapas de fila ya cacheados de `/gaps`), sus parcelas públicas, el remanente y el comercio de A, y el precio y el alquiler.
   - `GET /api/v1/investors/zones/{admin_unit_id}`: la ficha. Demanda (renta del barrio; edad y tamaño del hogar del distrito; hogares de 1 y de 5 o más de la ciudad, censo 2021), precios, «Qué falta» (**la lista del distrito**: no se calcula por barrio, y la web lo dice en cada fila, «Dato del distrito de X») más el comercio de A, suelo (parcelas de D-246 con su enlace al visor; ámbitos con remanente y suelo vacante de A) y los valores por defecto con sus fuentes. Cada cifra es un `SourcedValue` con `mark` y su bloque `source` (texto, nivel, periodo, datasets y enlace), como Sitescope; la que falta es `null` con su `null_reason`, nunca 0. Las features de A (`comercio_proximidad_1000hab`, `locales_abiertos_1000hab`, `locales_cerrados_pct`, `unidades_comerciales_1000hab`, `edificabilidad_remanente_residencial_m2`, `suelo_vacante_unidades`) se leen por su id: hasta que se carguen, `SOURCE_NO_COVERAGE` y un aviso. Un id que no es un barrio de Madrid se rechaza antes de abrir conexión (422); uno fuera del piloto, 404.
   - `POST /api/v1/investors/viability`: el cálculo, sin base de datos, con límites en cada entrada (pydantic, `extra="forbid"`; el suelo, total o por m², no los dos). La web comprueba los mismos rangos y pasos en cada campo (un test los compara con el JSON Schema) y dice bajo el campo qué está mal, así que no llega a pedir un cálculo imposible.
   - Rendimiento (revisión del #94): la lista pide los nombres de todas las zonas en una consulta (antes, ~216 por petición): 6 consultas para los 108 barrios, con los mapas de fila cacheados como `/gaps`. Un test lo vigila.
   - Línea A (#95): los ids casan con su PR. La población por barrio de A (`poblacion_padron_barrio`) es una métrica y no una feature, así que la ficha sigue dando la del distrito, y lo dice; cada ámbito con remanente lleva su uso (`use`) y su nota (`note`), que la API sirve en la ficha. **Un ámbito que ocupa varios barrios cuenta entero en el de un punto dentro de él (D-247):** su nota dice qué parte está en el barrio («aquí está el 32 % de su superficie»), la fuente de la suma dice cuántos ámbitos así incluye, y la lista lo avisa (`remaining_shared_areas`). No se reparte la edificabilidad por superficie: el fichero no dice dónde está dentro del ámbito (revisión del #95).
9. **Web.** `/inversores` (la lista por distritos, con «Solo barrios con suelo público») y `/inversores/{código}` (la ficha, en el orden demanda, precios, qué falta, suelo y calculadora). Enlace discreto «Para inversores y promotores» en el pie. «Guardar como PDF» abre la impresión del navegador: CSS `@media print` sin cabecera ni botones, con la fecha, la versión de los datos, las fuentes (con su dirección) y los avisos, y los desgloses abiertos. Reglas de D-244 y D-245: texto de 16 px o más, objetivos de 44 px, axe 0 a 390 y 1440 px (`apps/web/scripts/check-inversores.mjs`).
10. **Ejemplo (19 nov, `housing_inv_b`, solo lectura de las features).** Pinar del Rey (Hortaleza), parcela R25-L de la UVA de Hortaleza, 12.192 m² edificables (AVS). Precio estimado 4.847 €/m², nueva a 5.298 €/m²; PEM 644 × 1,36. Sin suelo (sin veredicto): lo máximo que se puede pagar es 35,82 millones de € (2.939 €/m² edificable) en el base, 3.364 en el optimista y 2.513 en el pesimista. Con el suelo a 3.200 €/m² edificable: base 15,1 % («Ajustar»), optimista 22,8 % («Sale»), pesimista 5,6 % («No sale»). Demanda: con la renta media del barrio (41.018 €), la hipoteca de una vivienda nueva de 80 m² sería el 42 % y el alquiler el 37 %, por encima del 30 %.
11. **Invariante.** El golden (`scripts/golden_search.py`) sigue 10 de 10 contra la API con estas rutas sobre `housing_inv_b`; ninguna feature ni tabla cambia.
12. **Descartado.**
    - Un coste de construcción por zona: no existe abierto (PREOC, Precio Centro y CYPE son privados).
    - Pasar los m² a viviendas: no hay regla escrita (D-246).
    - Una distribución de rentas inventada para contar «cuántos hogares pueden pagar»: solo hay la media.
    - Excel, cobro y login: fuera del MVP.
13. **Orden en producción: desplegar → cargar → sincronizar → smoke.** La API funciona sin el dataset de los visados (usa la cifra versionada) y sin las features de A (nulos con su motivo). Cargar con `make ingest DATASET=cm_visados_presupuesto_obra` y `hi-features compute --feature pem_visado_vivienda_bloque_m2`.
14. **Cómo volver atrás:** revertir el PR. Sin sincronizar, no hay datos que deshacer; tras sincronizar, borrar la fila `pem_visado_vivienda_bloque_m2` de `feature_registry` (las de `feature_value` caen por CASCADE) y la versión de `cm_visados_presupuesto_obra` en `dataset_version`, o volver a sincronizar desde una base sin ellas.
## D-249 — Documentación pública de la API y el MCP; dos herramientas MCP de inversores (2026-11-19)
Decisión de Mariano del 19 nov: **la API pública y el MCP son gratis para todos, igual que los datos**, también para empresas y ayuntamientos (`pitch/modelo_negocio.md`). Antes del cierre (23 nov) quiere una documentación pública que diga qué funciona ya y qué está solo planteado. Es aditivo y reversible: una página nueva de la web, dos enlaces, dos herramientas MCP sobre los servicios de D-248 y documentación. **Ninguna ruta, contrato, feature ni tabla cambia; `fit` y `gap_row` tampoco.** Código: `apps/web/src/app/(vida)/desarrolladores/`, `components/developers/`, `lib/developers.ts`, `services/mcp/src/hi_mcp/` (`server.py`, `tools.py`). Textos: `pitch/textos_web.md` §12. Evidencia: `evidence/gate-06/2026-11-19-desarrolladores/`.

1. **Página `/desarrolladores`** (grupo `(vida)`, sin mapa, con el pie), en castellano llano para el técnico de una empresa o de un ayuntamiento:
   - **Qué es:** API abierta, gratis, de solo lectura y sin clave, en el mismo dominio que la web (`/api/v1`, con su `openapi.json`); el sobre `{data, meta, warnings}`, `methodology_version` y `data_version`; «sin dato no es 0»; errores 422 y 404.
   - **Datos y licencias:** código Apache-2.0, documentación y catálogo CC BY 4.0, y cada conjunto de datos con la suya, como el README: CM y Ayuntamiento CC BY 4.0, CRTM, OSM ODbL (también el anillo de la M-40 del piloto, derivado de OSM), CartoCiudad, y Sanidad, Vivienda y Agencia Tributaria citando fuente y fecha. Cada `DatasetRef` trae su `license` y su `attribution_text`.
   - **Funciona hoy:** las 13 rutas de datos (`/search`, `/search/barrios`, `/gaps/{level}/{code}`, `/gaps?level=&row=`, `/gaps/impact`, `/datasets`, `/features`, `/features/{id}/values`, `/geo/admin-units`, `/places`, `/investors/zones`, `/investors/zones/{admin_unit_id}` y `/investors/viability`), cada una con un `curl` copiable contra `https://vidafacil-madrid.vercel.app`. **Cada ejemplo se probó una vez contra producción el 19 nov:** 17 peticiones en total (los 13 ejemplos, `openapi.json`, `/health`, un 422 de la viabilidad con 40 m² y una primera versión del ejemplo de viabilidad), todas con la respuesta esperada. Nada roto. Los ejemplos viven en `lib/developers.ts`, y un test de vitest comprueba que cubren las 13 rutas una vez, que apuntan a producción y que el cuerpo JSON llega al shell tal cual.
   - **El MCP:** qué es, sus 7 herramientas y cómo conectarlo desde Claude Code y Claude Desktop con `uv run --quiet --directory … hi-mcp` y `DATABASE_URL` hacia una base con los datos cargados (`make dev` y `make ingest-all`). Dice con claridad que hoy funciona en local, por stdio.
   - **Planteado**, marcado «Aún no disponible» y sin fechas: el MCP en remoto (HTTP) en el mismo dominio, avisos de suelo público nuevo, claves opcionales con una cuota de uso justo para integraciones con mucho tráfico y descargas en CSV y GeoJSON.
   - **Uso justo:** una nota amable (caché, sin bucles, avisar antes de un uso intenso). No dice si hay o no un límite de peticiones: lo decide coordinación aparte (`29_api_mcp_security_rate_limits.md`).
   - **Enlaces:** en el pie («API y MCP gratis, para desarrolladores») y en `/inversores` («¿Integrarlo en tu sistema? API y MCP gratis»). No en la cabecera, que se midió a 360 px.
   - **Reglas de D-244 y D-245:** letra de 16 px o más y objetivos de 44 px, también los enlaces dentro de una frase (`display: inline-flex`). El código se desplaza dentro de su caja, que recibe el foco para desplazarse con el teclado (WCAG 2.1.1), nunca la página; cada ejemplo tiene su botón «Copiar» con «Copiado» al lado. `apps/web/scripts/check-desarrolladores.mjs` lo mide a 360, 390 y 1440 px, y el e2e suma el recorrido J8.
   - **Rama de los enlaces:** el `git clone` y los enlaces al repositorio usan `claude/sprint-1-public`, la rama de producción, porque la rama por defecto del repositorio público (`main`) va 311 commits por detrás (19 nov) y no tiene las 7 herramientas. Es una constante (`REPO_BRANCH`): se cambia en una línea cuando `main` se ponga al día.
2. **Dos herramientas MCP de inversores** (7 en total), de solo lectura, sobre las mismas funciones que las rutas de D-248; sin SQL en las herramientas:
   - `ficha_inversor(barrio)`: la ficha de `GET /investors/zones/{admin_unit_id}` (`zone_sheet`), con el mismo sobre y los mismos avisos. `barrio` es su nombre o su código (`28079164` o `ES.28.BAR.28079164`). El nombre se resuelve en Python, sin abrir la base, contra la lista del piloto del propio servicio (`PILOT_BARRIOS`) y con la comparación de `encontrar_zona` (`match_rank`: sin mayúsculas, tildes ni signos; mismo nombre, empieza igual, una palabra empieza igual, lo contiene). Si el mejor puesto lo comparten varios barrios, es un error que los nombra («San» → 5 barrios); si gana uno y coinciden otros, un aviso los nombra. Fuera del piloto, el mismo mensaje que el 404 de la ruta. Es el único texto libre además del nombre de `encontrar_zona`, y el test de «sin SQL libre» lo admite.
   - `viabilidad(request)`: `request` es el `ViabilityRequest` de `POST /investors/viability`, el mismo modelo, así que tiene los mismos campos, límites, valores por defecto y validador (50 m² como mínimo; el suelo en total o por m² edificable, no los dos; ningún campo de más). Una entrada inválida es un error de herramienta antes de calcular, como el 422. Llama a `run_viability` y no abre la base de datos.
   - **Por qué `request` anidado y no los campos sueltos:** el SDK genera el esquema de entrada a partir de la firma; repetir los campos con sus límites duplicaría el contrato. Anidado es el mismo modelo (un test compara los esquemas) y el mismo cuerpo que la API, como el `scenario` de `buscar_zonas`.
   - Las instrucciones del servidor suman el flujo de inversores y piden repetir los avisos (`notices`): no es una tasación.
   - Tamaño y tiempos (base local `housing`, solo lectura): la ficha de Pinar del Rey, 59 KB y 0,34 s (1,3 s la primera); la viabilidad, 3 KB y 0,01 s. Con el ejemplo de D-248 (1.000 m², 4.847 €/m², +9,3 %, PEM 644, suelo a 3.200 €/m²) da lo mismo que la API: 15,1 % «Ajustar», 22,8 % «Sale» y 5,6 % «No sale».
   - Tests: unitarios (las 7 herramientas, sus esquemas, entradas inválidas que no llegan a la base, la viabilidad igual que la ruta sin base y la resolución de nombres y códigos) y de integración (la ficha igual que la ruta por nombre y por código, y el error fuera del piloto igual que el 404).
3. **Invariante:** el golden (`scripts/golden_search.py`) da 10 de 10 sobre `housing`, con una salida idéntica a la de la base (`diff` vacío). Ni `/search` ni `/gaps` cambian.
4. **Pendiente de D:** `pitch/modelo_negocio.md` aún dice «cinco herramientas» y que la API y el MCP gratis no van en la voz «hasta que esté en producción la página de documentación». Con esta página desplegada, D decide.
5. **Cómo volver atrás:** revertir el PR. No hay datos, migraciones ni sincronización que deshacer.

## D-250 — Inversores: buscar por la parcela exacta (referencia catastral, dirección o mapa), con su planeamiento, su edificabilidad y el contexto del barrio (2026-11-19)
Decisión de Mariano del 19 nov, al ver `/inversores` en producción: «Esto es un listado de barrios. Sin más, el inversor debe poner su parcela exacta porque hay que buscar sobre esa parcela en específico como hacen las otras apps». Decidido: **toda Madrid capital**; la **calificación oficial** con el enlace a su ficha; la **edificabilidad siempre editable**, marcada «supuesto» si no es oficial; **llamadas en vivo** a los servicios oficiales, con caché, y **4 parcelas de demostración** guardadas como reserva; `/inversores` abre con **«Busca tu parcela»** y la lista de barrios pasa detrás, como «Explorar barrios». Es aditivo y reversible: dos rutas, un código de error nuevo, lógica pura, tres tablas versionadas y una sección de la web. **Ni `/search` ni `/gaps` cambian, `fit-0.9` tampoco, y nada entra en `fit` ni en `gap_row`.** Base: un spike verificado del 19 nov (privado, fuera del repo). Código: `hi_contracts/pro/investors.py` (`ParcelSheet` y sus bloques), `hi_contracts/api/envelope.py` (`AMBIGUOUS_INPUT`), `hi_contracts/catalog/manual.py` (`BuildableParcelsTable`), `hi_domain/parcels.py`, `hi_domain/zonal_norms.py`, `hi_domain/parcel_data.py` (generado), `hi_api/services/parcels.py` (clientes), `parcel_sheet.py` (la ficha), `upstream_guard.py` (caché y límite), `parcel_demo.json`, `hi_api/privacy.py`, `hi_api/routes/investors.py`, `scripts/buildable_parcels.py`, `scripts/parcel_demo_snapshot.py`, `scripts/export_investor_data.py`, `apps/web/src/lib/parcels.ts`, `components/investors/ParcelSearch.tsx`, `ParcelMap.tsx`, `ParcelSheet.tsx` y `app/(vida)/inversores/parcela/[rc]/`. Textos: `pitch/textos_web.md` §11. Evidencia: `evidence/gate-06/2026-11-19-parcela/`.

1. **Fuentes y licencias.**
   - **Catastro** (servicios web libres de la Sede Electrónica, JSON): la parcela por su referencia (`Consulta_DNPRC`), su punto de referencia (`Consulta_CPMRC`), la parcela de un punto (`Consulta_RCCOOR`, y las cercanas si el punto cae en la calle) y las de un número de una calle (`ObtenerNumerero`, reserva de CartoCiudad). **Licencia de los servicios INSPIRE de la DGC (v1.0, 2016): uso, también comercial, solo de la información transformada**; no se difunde la original ni se presenta nada como «información catastral», «ficha catastral» o «cartografía catastral». `catastro_inspire` pasa a **`RESTRICTED`** y se añade `catastro_ovc` con la misma licencia. Cita (cláusula 12 de la licencia de descarga de 2011): «Elaborado por Vida Fácil a partir de datos de la Dirección General del Catastro (Sede Electrónica del Catastro), consultados el {fecha}.».
   - **Ayuntamiento de Madrid** (sigma.madrid.es, ArcGIS REST): el destino urbanístico en el punto de la parcela (`USOS_SUELO`, capa 3, conjunto 300744) y el instrumento en vigor con el enlace a su ficha (`PLANEAMIENTO_URBANISTICO`, capa 3, conjunto 300489), CC BY 4.0. Fuente nueva `ayuntamiento_madrid_urbanismo_sigma` (CLEAR) y los dos conjuntos en el catálogo (`ayto_usos_suelo_urbanismo`, `ayto_planeamiento_desarrollos`; no se cargan en la base). Cita: «Origen de los datos: Ayuntamiento de Madrid (Área de Urbanismo; Geoportal y datos.madrid.es), CC BY 4.0. Consultado el {fecha}. Información urbanística sin valor jurídico.» («Consultado el» y no «Actualizado a», como piden las condiciones generales, porque estos servicios no publican la fecha de su última actualización: se da la de la consulta, que es la de los datos que se enseñan) y el aviso fijo «Información urbanística sin valor jurídico (Ayuntamiento de Madrid). Consulte la ficha oficial.».
   - **CartoCiudad** (IGN, CC BY 4.0 scne.es, ya en el catálogo): los portales que coinciden con una dirección, con su referencia. Su cita va bajo la lista y en `sources`.
   - **m² edificables oficiales:** VEDA (Ayuntamiento, CC BY 4.0) y el Portal del Suelo 4.0 (Comunidad de Madrid, CC BY 4.0), por referencia catastral.
2. **API (aditiva, `parcels-0.1`).**
   - `GET /api/v1/investors/parcels?rc=|lat=&lon=|address=`: exactamente una forma de entrar. Una referencia mal formada → 422 `OUT_OF_COVERAGE` sin llamar a nadie; inexistente → 404; fuera de Madrid → 422. Un punto fuera de Madrid (recuadro y después `ST_Contains` del municipio) → 422; en la calle → 404 con `details.nearest`. Una dirección solo se resuelve sola si CartoCiudad da **un único portal**, con **el número tecleado** y **en la calle tecleada** (sus palabras, sin tipo de vía, tildes, mayúsculas ni partículas, están en las del candidato: «calle abegondo 1» nunca es «BEGONIAS 1», el error del geocodificador que vio el spike); si no → **422 `AMBIGUOUS_INPUT`** con `details.candidates` (nuevo en `ErrorCode`, aditivo). La web nunca se apoya en esto: enseña siempre los candidatos. `GET /api/v1/investors/parcels/candidates?q=`: los portales para la caja de direcciones.
   - **Orden de las llamadas** (spike): DNPRC y CPMRC en paralelo (una DNPRC más con un inmueble si hay división horizontal); después, en el punto, las tres capas del Ayuntamiento en paralelo: el destino urbanístico, el instrumento y la Z del plano de 1997 (se pide siempre, una llamada barata, y solo se lee en la norma zonal 1, para no alargar la espera). Tiempos: conexión 3 s, Catastro 5 s, Ayuntamiento 10 s, CartoCiudad 4 s, sin reintentos, y **un presupuesto total de 15 s** por búsqueda: si el Catastro no ha respondido dentro, cuenta como caído (ficha de demostración o 503); si el Ayuntamiento no ha respondido, la ficha sale sin planeamiento.
   - **Una respuesta con otra forma** (una lista donde había un objeto, una referencia vacía, CartoCiudad sin su lista) es la fuente fallando, como una página HTML: ficha de demostración, 503 o el índice de calles del Catastro, nunca un 500. Un enlace oficial que no es una dirección https válida (con espacios, por ejemplo) se quita, sin error. Solo el código 72 del punto de referencia («sin cartografía») deja la ficha sin punto; otro código es el Catastro fallando. Cliente `httpx` (nueva dependencia de `apps/api`; ya estaba en el lock) compartido por bucle, con un User-Agent genérico sin datos de nadie.
   - **Caché en el proceso** (LRU de 2.000 entradas, con caducidad por entrada): Catastro 7 días, planeamiento 24 h, CartoCiudad 30 días, punto → referencia 7 días. Guarda nuestros campos, nunca una respuesta original, y solo en memoria. **No se guarda nada incompleto**: una parcela sin punto, un planeamiento al que le falta una capa ni un «sin portales» por un fallo se vuelven a pedir la próxima vez. La clave de una dirección es un hash (sha256) del texto normalizado, nunca el texto. `Cache-Control: public, max-age=3600, s-maxage=86400` en una ficha completa pedida por su referencia o por un punto; `no-store` si falta algo o es de demostración; **`private, no-store` si se pidió por dirección y `private, max-age=600` en `/parcels/candidates`**, para que la CDN no guarde una URL con una dirección.
   - **Límite por IP que cuenta solo las búsquedas que llaman al Catastro o al Ayuntamiento** (fallos de caché): 20 por minuto (`PARCEL_GUARD_PER_MINUTE`), y 60 para CartoCiudad; por encima, 429 `RATE_LIMITED` con `Retry-After`, también para una parcela de demostración (el límite no se esquiva con la reserva). Una búsqueda cuenta una vez aunque haga varias llamadas (hasta ~6). La IP es la primera de `X-Forwarded-For`, la que pone el proxy de Vercel (el contenedor solo confía en él). Protege al Catastro, que puede suspender a un usuario intensivo, sin tocar las búsquedas repetidas ni el e2e. **Vive en cada instancia** (Vercel levanta varias): es un techo, no una cuota.
   - **Si falla una fuente:** sin Ayuntamiento, la ficha sale sin planeamiento (`planning: null`, `degraded: ["planning"]`) y la web dice «El Ayuntamiento no responde ahora; el resto de la ficha sí»; si solo falla su capa de instrumentos, el planeamiento sale sin él y también con `degraded: ["planning"]`; si en la norma zonal 1 falla la Z, `degraded: ["buildability"]` y la edificabilidad queda sin dato. Sin Catastro (caída, HTML, otra forma o fuera de tiempo), la ficha guardada si es una de las 4 de demostración (`fallback: "demo_snapshot"`); si no, 503 `SOURCE_DEGRADED`. Una ficha degradada nunca se guarda en la CDN. Sin base de datos, sin barrio (`degraded: ["context"]`) y la calculadora con sus supuestos y el PEM versionado.
   - **`PARCEL_UPSTREAMS=false`** (demo sin red y e2e): ninguna llamada a ninguna fuente; solo las 4 de demostración, por su referencia.
3. **Edificabilidad de partida** (`hi_domain.parcels.initial_buildability`, por prioridad): (1) VEDA, (2) el Portal del Suelo — **oficial**, la primera cifra residencial (si solo las hay de otros usos, la ficha la enseña como referencia con su uso y la calculadora empieza «sin dato»); (3) el coeficiente de la norma zonal 5, 7, 8 o 9 por grado sobre la superficie del Catastro — **supuesto**, con su artículo y la página del PDF oficial (`hi_domain.zonal_norms`, tabla versionada: refundido de las NNUU de 2022 comprobado contra el BOCM de 27-11-2023; NZ 8 grado 6º cuenta a 0,5 lo que pasa de 500 m²); (4) la norma zonal 1, grados 1º–4º: superficie × Z × C, **supuesto aproximado** (la norma usa el fondo o la parcela edificable); (5) el resto (NZ 2, 3, 4 y 6, ámbitos sin VEDA, uso dotacional, NUP, suelo rústico) — **sin dato**, con el motivo y el artículo: la persona pone los m². Si hay cifra oficial y la norma daría otra, manda la oficial y la nota da la supuesta. Siempre editable; la calculadora conserva la etiqueta hasta que la persona la cambia. Se enseña también lo construido hoy, como contexto.
4. **Datos versionados (sin escribir en la base ni sincronizar).** La imagen de la API no lleva `data/`, como en D-248: `scripts/buildable_parcels.py` escribe `data/catalog/manual/veda_parcelas.yaml` (1.110 filas de la capa de parcelas de VEDA de julio de 2026, leída el 19 nov en una petición; 1.109 parcelas: una viene en dos trozos del mismo ámbito y se suman; la URL con fecha va al catálogo, en el recurso `parcels` de `ayto_edificabilidad_remanente_ambitos`) y `portal_suelo_madrid_parcelas.yaml` (las 50 parcelas de Madrid del CSV del Portal del Suelo ya descargado el 18 nov; solo sus columnas de parcela, nunca la de contacto), validadas por `BuildableParcelsTable`; `scripts/export_investor_data.py` genera `hi_domain/parcel_data.py` y `make lint` comprueba que coincide. Las **4 fichas de demostración** (`parcel_demo.json`: Méndez Álvaro 47–49, VEDA 13.121 m²; Almería 1, Portal del Suelo 32.697 m²; Luis Misson 2, NZ 4 sin coeficiente; Mayor 61, división horizontal de 6 inmuebles, NZ 1 grado 2º, 68 × 5 × 0,66 = 224 m²) las escribió `scripts/parcel_demo_snapshot.py` el 19 nov con los propios clientes de la API, en serie: solo nuestros campos.
5. **El barrio** (PostGIS, solo lectura sobre `geo_admin_unit`, que el rol de la API ya lee): `ST_Contains` del punto de referencia del Catastro. En un barrio del piloto, la ficha entera del barrio (D-248: demanda, precios, qué falta, comercio y suelo), y la calculadora empieza con su precio, su alquiler y su renta. Fuera del piloto, la misma ficha con las cifras del distrito o de la ciudad (nunca las del barrio) y el aviso «Este barrio está fuera del piloto…»; no es un 404.
6. **Web.** `/inversores`: «Busca tu parcela» (la referencia, comprobada como la lee la API; la dirección, con los portales de CartoCiudad para que la persona elija el suyo; un mapa pequeño con el estilo de la app en el que pinchar) y las 4 parcelas de demostración; después el modelo, «¿Integrarlo en tu sistema? API y MCP gratis» y «Explorar barrios» (la lista de D-248). En un móvil de 390 px la referencia cabe en la primera pantalla. `/inversores/parcela/{referencia}` se puede compartir: datos de la parcela, planeamiento con su enlace oficial, el visor del Geoportal y el aviso, edificabilidad con su etiqueta, el barrio con las secciones de la ficha de D-248, la calculadora y las fuentes con su cita; «Guardar como PDF» como en D-248. `/inversores/{barrio}` sigue igual. Reglas de D-244 y D-245 a 360, 390 y 1440 px: `apps/web/scripts/check-parcela.mjs` (texto ≥ 16 px, objetivos ≥ 44 px, sin desborde y axe 0 en la búsqueda, sus estados, las 4 fichas y la impresión); el e2e suma J9 y J8 pasa a 15 rutas.
7. **Privacidad.** La dirección tecleada no se registra: solo la referencia, el tipo de entrada y los tiempos. El log de acceso de uvicorn escribiría la ruta con su consulta (`?address=`, `?q=`): un filtro (`hi_api/privacy.py`) la cambia por `[redactado]`, y los logs de `httpx` quedan en WARNING. **Límite de la plataforma (riesgo que queda):** la dirección viaja en la URL (`?address=`, `?q=`), y los registros de peticiones de Vercel y de su CDN pueden guardar la URL entera; eso no lo controla la API. Se reduce así: la web solo envía texto a `/parcels/candidates` (y después pide la ficha por su referencia), esas respuestas llevan `Cache-Control: private` para que la CDN no las guarde, y nuestros logs y la caché no tienen el texto. Para quitarlo del todo haría falta un `POST` con el texto en el cuerpo (otra versión de la ruta). Los datos no protegidos del Catastro no traen titular, y la división horizontal se resume por uso, sin planta ni puerta. Las respuestas de los tests son **sintéticas** (`respx`), con referencias y calles inventadas.
8. **Desviaciones del spike, y por qué.** (a) Las tablas de VEDA y del Portal del Suelo son módulos generados y no filas de la base, y la referencia del Portal sale del CSV de Bronze en lugar de añadirla a `dims`: el encargo no permitía escribir en la base ni volver a cargar. (b) La cita del Ayuntamiento dice «Consultado el» y no «Actualizado a»: los servicios no dan su fecha de actualización. (c) La fórmula de la NZ 1 (v2 en el spike) entra ya, como aproximada, porque la demo de Mayor 61 la enseña. (d) Sin geometría del WFS, sin precalentar al arrancar y sin solape por polígono (v2): la ficha usa el punto de referencia del Catastro. (e) El límite cuenta búsquedas, no llamadas. (f) La caché del planeamiento va por referencia (el punto es el de la parcela). (g) La Z de la norma zonal 1 se pide en paralelo siempre (spike: solo en NZ 1, después), por el presupuesto de tiempo.
   - **Revisión del #101 (R-01 a R-12), aplicada:** el candidato único tiene que ser de la calle tecleada (R-01); solo el código 72 deja la ficha sin punto, y una parcela sin punto no se guarda (R-02); una capa del Ayuntamiento que falla degrada la ficha, no se guarda y no va a la CDN (R-03); una respuesta de otra forma nunca da 500 (R-04); CartoCiudad sin lista cae al índice de calles (R-05); presupuesto de 15 s y la Z en paralelo (R-06); clave con hash y `Cache-Control: private` para las direcciones (R-07); la primera cifra oficial residencial (R-08); 429 sin ficha de demostración (R-09); tests herméticos sin base de datos (R-10); en el mapa, solo el último clic navega (R-11); el porqué de «Consultado el» (R-12).
9. **Pruebas.** Unitarias: 60 de las reglas puras y la tabla de normas, 51 de la API con respuestas sintéticas (un inmueble, división horizontal, solar, códigos 3, 4, 5, 16, 33, 43 y 72, `lerr` en sus dos formas, HTML de caída, timeout y error de ArcGIS, respuestas de otra forma, un enlace con espacios, la norma zonal 1 con y sin su Z, el presupuesto de tiempo, el Catastro caído con y sin demo, sin fuentes, el candidato de otra calle (Begonias), la caché que no guarda lo incompleto, las cabeceras de caché, el límite por IP, el log sin la dirección, las fichas de demo sin claves del Catastro) y 6 de la caché y el límite; de integración (3, base de fixtures): el barrio del piloto, fuera del piloto y un punto sin barrio. Web: vitest de `lib/parcels.ts` y de la API; e2e J9 y `check-parcela.mjs` solo con las 4 parcelas de demostración y `PARCEL_UPSTREAMS=false`.
10. **Invariante.** El golden (`scripts/golden_search.py`) da 10 de 10 sobre `housing`, con una salida idéntica byte a byte a la del código de la base (20b46d9) sobre la misma base.
11. **Pendiente.** Comprobar en producción, tras desplegar, los dos ejemplos nuevos de `/desarrolladores` (se probaron el 19 nov contra la API local con las fuentes en vivo; el e2e y `check-parcela`, en cambio, con `PARCEL_UPSTREAMS=false`). Si se quiere certeza sobre la licencia del Catastro, preguntar a la DGC. v2: la parcela que cruza dos zonas (solape por polígono), su geometría en el mapa y el planeamiento sin red (los 40.021 polígonos en PostGIS).
12. **Orden en producción y vuelta atrás.** Solo desplegar: sin migraciones, sin cargas ni sincronización. Después, smoke de una parcela de demostración y de `/parcels/candidates`. Volver atrás: revertir el PR.

## D-251 — «Inversores» en la cabecera y la sección de inversores de «Cómo lo calculamos» (2026-11-19)
Petición de Mariano del 19 nov, tras ver producción: «Inversores debe ir en el header de mapa que falta y como lo calculamos». Es aditivo y reversible: una pestaña, una sección de la página del método y dos enlaces. **Ninguna ruta, contrato, feature ni tabla cambia; `fit` y `gap_row` tampoco.** Código: `apps/web/src/lib/nav.ts`, `components/method/InvestorMethod.tsx`, `app/(vida)/como-lo-calculamos/page.tsx`, `components/investors/MethodLink.tsx`, `Calculator.tsx`, `ParcelSheet.tsx`, `lib/investorMethod.ts` (generado) y `scripts/export_investor_data.py`. Textos: `pitch/textos_web.md` §1 (`pestana.inversores`) y §11. Evidencia: `evidence/gate-06/2026-11-19-cabecera-inversores/`.

1. **Pestaña «Inversores»** (`/inversores`), la última de la cabecera, en todas las páginas: también en el mapa, que es la portada y no tiene pie, así que hasta ahora no había forma de llegar desde ahí. Marca `/inversores` y todo lo que cuelga de ahí: la ficha de un barrio (`/inversores/28079164`) y la de una parcela (`/inversores/parcela/{referencia}`). La pestaña activa sigue marcada con fondo, borde y color, no solo con color. **A 360 px no cabían** (las cuatro pedían 344 px y hay 324): el arreglo menos invasivo es **un relleno lateral más fino de las pestañas por debajo de 380 px** (de `--space-2` a `--space-1`, `SiteHeader.module.css`). Siguen en una fila, con las mismas palabras y la misma letra; «Cómo lo calculamos» y «Qué falta» se parten en dos líneas dentro de su píldora (la regla de D-245), y cada pestaña sigue teniendo 44 px o más de ancho y de alto. Descartados: una etiqueta más corta (no la hay más clara que «Inversores») y partir la fila en dos (tapa más mapa en el móvil). Medido en la cabecera del mapa y de las páginas con pie a 360, 390 y 1440 px (`check-cabecera.json`: una fila, dentro de la pantalla, texto de 16 px o más, objetivos de 44 px, pestaña activa con fondo y borde, axe 0), con `check-ux-mobile.mjs`, `check-parcela.mjs` y `check-inversores.mjs`. El enlace del pie («Para inversores y promotores») se queda.
2. **«Cómo calculamos la ficha para inversores»** (`/como-lo-calculamos#inversores`), en llano y **solo con lo que hace el código**: de dónde sale cada dato de la parcela (datos elaborados a partir de los del Catastro, nunca «información catastral»; el planeamiento del Ayuntamiento, sin valor jurídico; el barrio del piloto o, fuera, su distrito); la edificabilidad de partida por orden (VEDA y el Portal del Suelo, la primera cifra residencial; el supuesto de la norma zonal con su coeficiente y su artículo, y el de la norma zonal 1, aproximado; si no, sin dato, que no es 0; siempre editable); la viabilidad por el método residual (entradas y sus fuentes, sin plazos ni financiación, salidas, los tres escenarios, el semáforo supuesto solo con precio del suelo y la comprobación de demanda), y sus límites (no es una tasación; no es lo que permite toda la normativa; la primera búsqueda puede tardar, como mucho el presupuesto de una búsqueda).
3. **Ninguna cifra a mano.** `scripts/export_investor_data.py` genera también `apps/web/src/lib/investorMethod.ts` desde el código (`hi_domain.viability`: coeficiente y sus partes, comercialización, margen objetivo, suelo del «Ajustar», escenarios, vivienda tipo, hipoteca y umbral de esfuerzo; `hi_domain.zonal_norms`: coeficientes por norma zonal y grado con su artículo y su página, la norma zonal 1 y el grado 6º de la 8; `hi_domain.parcels`: el presupuesto de una búsqueda, que pasa a vivir ahí, `LOOKUP_BUDGET_S`) y desde las tablas versionadas (el PEM y su año, los barrios del piloto, las parcelas de VEDA y del Portal del Suelo). `make lint` comprueba que el fichero coincide, así que un cambio del código o de una tabla obliga a regenerarlo. Un vitest renderiza la sección y busca cada cifra.
4. **Enlaces «Cómo lo calculamos»** a esa sección desde la ficha de una parcela (bajo la edificabilidad) y desde la calculadora (al final, también en la ficha de un barrio); 44 px y fuera del papel. El lector de pantalla oye «Cómo lo calculamos: la ficha para inversores», para distinguirlo de la pestaña.
5. **Revisión del #104.** (a) **Sobre el mapa, en el móvil,** la fila de pestañas (dos líneas a 360 y 390 px) caía en la parte transparente del degradado de la cabecera y se veían debajo los rótulos del mapa. El arreglo menos invasivo, solo para la cabecera estrecha sobre el mapa (`header:has(~ main [data-map-layout])`): el degradado es casi opaco (98 %) hasta 0,5 rem del borde de abajo, así que la fila entera va sobre fondo claro. El resto de páginas no cambia. Comprobado midiendo los píxeles del mapa detrás de las letras de cada pestaña (`check-cabecera.json`: el peor contraste es 5,48:1, sobre el mapa a 360 y 390 px). (b) **`main` al día** (Mariano aprobó `main` el 19 nov): `/desarrolladores` enlaza el repositorio en `main` (`REPO_BRANCH`) y el `git clone` va sin `--branch` (punto abierto R-02 del #97, D-249 §1). (c) **El texto, exactamente lo que hace el código** (R-01 a R-11): si el Catastro no responde no hay ficha (salvo las parcelas de ejemplo) y si el Ayuntamiento no responde sale la parcela sin planeamiento; los 15 s son de los servicios oficiales, no de la lectura del barrio; el margen, solo con precio del suelo, y sin rentabilidad si ni con el suelo gratis se llega al objetivo; qué no se puede cambiar en la calculadora (el suelo del «Ajustar», los escenarios y el umbral de esfuerzo) y que sin franja de «Ajustar» con un objetivo por debajo del 10 %; la lista completa de normas zonales sin coeficiente (2, 3, 4, 6, 10 y 11), la norma zonal 1 fuera de sus grados o sin Z, sin grado o sin superficie, generada del código como la regla del grado 6º de la 8; el piloto es por barrio; el precio es una estimación, la prima es la de la ciudad y los escenarios mueven también el alquiler; las parcelas de VEDA incluyen otros usos; y una línea para cada palabra técnica. En la ficha de una parcela, un solo enlace «Cómo lo calculamos». El chequeo de la cabecera es un script versionado, `apps/web/scripts/check-cabecera.mjs`: mide el contraste de las letras de cada pestaña sobre los píxeles que tienen detrás (captura con y sin letras), y sin el arreglo del degradado da 1,69:1 sobre el mapa a 360 px; con él, 5,48:1.
6. **Invariante:** el golden no se toca (ni el buscador ni «Qué falta» cambian). **Cómo volver atrás:** revertir el PR.


## D-252 — Inversores: lo que engañaba, el uso y el coste (2026-11-19)
Feedback de P7 (inversor) y auditoría de experto del 19 nov: la ficha de una parcela no puede pasar por vivienda libre lista para construir lo que no lo es, y tiene que decir la edificabilidad por uso y de dónde sale el coste. **`fit` y `gap_row` no cambian; el golden tampoco.** Código: `hi_domain.parcels` (usos, `plan_use`, `ambit_state`, `parcel_cautions`, reglas de la edificabilidad de partida), `hi_domain.viability` (coste, escenarios, umbral, titular, `break_even`), `hi_domain.ambit_status` y `viability_data` (generados), `hi_api.services.parcels` (tablas 4 y 5 de USOS_SUELO), `parcel_sheet.py`, `investors.py`, la ficha, la calculadora y «Cómo lo calculamos». Textos: `pitch/textos_web.md` §11. **Corrección:** la primera versión de esta decisión decía que el planeamiento «da el uso pero no una cifra de m²». Es falso: las tablas 4 y 5 de USOS_SUELO la dan (punto 2).

1. **Edificabilidad por uso, sin repartir nunca una cifra.** VEDA y el Portal del Suelo publican una sola cifra por parcela catastral, con un solo uso: la ficha enseña una línea por fuente con su uso y su fuente (`buildability.by_use`). De las 1.109 parcelas de VEDA, 574 son de uso residencial, 51 terciario y 484 industrial; de las 50 del Portal, 38, 7, 3 y 2 de otros usos (cifras generadas en `investorMethod.ts`). El uso del planeamiento se clasifica (`use_class`, y `use_ownership` solo en el dotacional, NNUU art. 7.7.2; el terciario no se divide así, art. 7.6.1) y se explica en llano.
2. **El plan por uso (USOS_SUELO, conjunto 300744, CC BY 4.0).** La capa 3 da el `UBOV_ID` de la parcela urbanística y la superficie de su polígono; con él, la tabla 4 («Uso cualificado principal») y la 5 («Otros usos cualificados») dan `USO`, `EDIFICABIL` y `UNIDAD`. Ejemplo: la Manzana B del APR.02.06 tiene 60.230,88 m² residenciales y 21.299,91 m² de servicios terciarios. En m²/m², la cifra se multiplica por la superficie de la parcela urbanística y se marca «supuesto». Avisos: la parcela urbanística puede no ser la catastral; es lo que el plan permite en total, no lo que queda; salvo excepciones, los usos asociados y complementarios no pasan del 50 % de lo edificado, ni del 25 % en una parcela dotacional (NNUU art. 7.2.8). Sin cifra: «el plan no la publica». Las dos tablas van detrás de la capa 3 (necesitan su `UBOV_ID`), en paralelo con las otras capas y con su propio tiempo (4 s, nunca después del plazo de la ficha): si fallan, tardan o falta el `UBOV_ID`, solo se degrada `plan_uses` (`degraded: ["plan_uses"]`), el planeamiento se queda y la ficha no se guarda en caché (R-03; revisión del #109, R-01 y R-07).
3. **Estado del ámbito** (`hi_domain.ambit_status`, generado de `data/catalog/manual/pgoum_ambitos_estado.yaml`, que escribe `scripts/pgoum_ambitos_estado.py` desde bronze): las cuatro fases del conjunto 203200 «PGOUM 97. Estado de desarrollo de los ámbitos» (666 ámbitos a 1 de julio de 2026) y la situación en VEDA (203182), ambos CC BY 4.0. El código de sigma se cruza tal cual (sin mayúsculas), y si no, sin su sufijo (`/M`, `-RP`, `/UE-n`) cuando hay uno solo. Los ámbitos que el Ayuntamiento no sigue (APE.00.01, colonias, anulados) dicen «El Ayuntamiento no publica su estado». Se lee del YAML versionado y no del XLS para que `--check` funcione sin bronze en CI.
4. **Barandillas** (auditoría D2), como la R-08 de #101:
   - un supuesto de norma zonal cuyo uso del plan no es vivienda (la NZ 9 industrial: B1) pasa a referencia, «X m² de uso industrial, no de vivienda», y la calculadora empieza en «sin dato»;
   - una cifra oficial en un ámbito no terminado (alguna fase sin acabar en 203200, o VEDA pendiente de planeamiento, de gestión o de urbanización) pasa a referencia, con el aviso de cesiones y urbanización (Ley 9/2001, arts. 18.2.c, 18.2.d y 21.1, comprobados en el BOE);
   - vivienda protegida (el uso del plan o el de VEDA): aviso con su precio máximo legal (Decreto 74/2009, art. 12), y el precio de la calculadora queda editable y marcado «supuesto»;
   - unifamiliar: aviso de que el coste es de bloque y el precio, del barrio en general;
   - una cifra oficial en un ámbito cuyo estado no publica el Ayuntamiento: aviso de que no está contrastada con su desarrollo (revisión del #109, R-05);
   - suelo público del Portal del Suelo: la ficha dice quién lo ofrece, en qué régimen y si está urbanizado, con los avisos de D-248. Antes no llegaba nunca a la ficha de parcela (`parcels={[]}`); ahora va como aviso, sin el selector de suelo, que volvería a poner la cifra de referencia como dato.
   - «¿Es un solar?» pasa a «¿Está sin edificar? (según su uso en el Catastro)»: «solar» es una condición legal con servicios (Ley 9/2001, art. 14.1.a) que ningún dato abierto da por parcela. «En fase de edificación» ya no dice «se puede construir ya».
5. **Coste** (auditoría D4 y decisión de Mariano). El PEM de partida es **968 €/m²**, el punto medio del bloque abierto en Madrid (871–1.064 €/m²) de los Costes de Referencia General de la Comunidad de Madrid, «actualizado al año 2022», PEM sin gastos generales ni beneficio industrial. Lleva la etiqueta «supuesto: referencia de la Comunidad de Madrid de 2022; los costes han subido desde entonces». Sale de la tabla versionada `costes_referencia_construccion.yaml`. El PEM de los visados (644 €/m², 2025, conjunto 1006022) queda a la vista como referencia baja: la API lo sigue leyendo del Feature Store, con su feature y su conjunto (`cm_visados_presupuesto_obra`), en `defaults.pem_permits_m2`, y la calculadora lo enseña con su fuente; así el dataset de la Comunidad sigue trazable en la ficha del barrio y en la de la parcela. El recuadro «De dónde sale el coste y cuánto varía» da las tres referencias con lo que es cada una; la de Sociedad de Tasación (1.360 €/m², diciembre de 2025, España) es de prensa: sin el informe original no sabemos si incluye gastos generales y beneficio. El ICIO de Madrid es del 3,75 % (ordenanza fiscal del ICIO, art. 25, aprobada por acuerdo plenario de 22/12/2023; Libro de Ordenanzas Fiscales 2024, p. 154; vigente en 2025; el de 2026 no se ha podido leer en la fuente): el coeficiente se deriva de sus partes (`ICIO_RATE`) y pasa de 1,36 a 1,3575. Fuera «Mínimo oficial». «Qué incluye el coste y qué no» sale de lo que modela `viability.py`.
6. **Escenarios y umbral** (auditoría D8, decisión de Mariano): el pesimista pasa a −10 % de precio y +15 % de coste, porque las referencias de coste se separan un 15 % o más; «Ajustar» empieza en el 15 %. Se cita la Orden ECO/805/2003, disposición adicional sexta (margen mínimo del 18 % para viviendas de primera residencia, sin financiación ni Impuesto sobre Sociedades, comprobado en el BOE). El optimista no cambia. `VIABILITY_VERSION` pasa a `viability-0.2`.
7. **Titular del residual** (auditoría D7): tres cifras significativas («unos 67 millones de €»; con un millón justo, «alrededor de 1 millón de €») y «antes de financiación, impuestos de compra del suelo, urbanización y derribo», con un enlace a lo que la cuenta no incluye.
8. **Punto de equilibrio** (`hi_domain.viability.break_even`, puro, con una propiedad: en el equilibrio, el margen es el objetivo). Es lo máximo que puede costar la construcción por m² construido (PEM × coeficiente) para llegar al margen objetivo, con el suelo que se pone y, si se pone, también con el suelo gratis. Si haría falta un coeficiente por debajo de 1, lo dice así: «ni con el PEM solo (coeficiente 1) llega».
9. **Fichas de demostración.** Se rehicieron con 12 llamadas en vivo: la capa 3 y las tablas 4 y 5. El resto de la ficha ya estaba guardado y se recalculó con las reglas nuevas, sin red. Almería 1 (APR.04.09, las cuatro fases «Sin Iniciar») pasa de «oficial» a «sin dato»: sus 32.697 m² quedan como referencia.
10. **Invariante:** el golden no se toca. **Cómo volver atrás:** revertir el PR. Los campos nuevos son opcionales en los contratos, y el escenario pesimista y el umbral son constantes con test.

## D-252b — Usos del plan dentro del presupuesto (2026-11-19)
Hotfix de producción. En frío, las cuatro fichas de demostración salían con `SOURCE_DEGRADED: plan_uses`, y Almería 1 y Mayor 61 seguían así en la segunda visita. Una ficha degradada va con `no-store`, así que no se podía calentar. La hipótesis es el tope fijo de 4 s de las tablas 4 y 5 de USOS_SUELO: van detrás de la capa 3, y en frío Catastro y capa 3 ya gastan buena parte de los 15 s. Cuadra con los tiempos, pero **no está confirmada**: hasta ahora no había logs. Este cambio la corrige y deja la línea para comprobarla.

1. **Las tablas usan el tiempo que queda** hasta el plazo de la ficha, menos un margen de 0,5 s, sin tope fijo. Si fallan rápido (un error, no el tiempo) y queda tiempo, se piden una vez más. Si se agota el tiempo, solo se degrada `plan_uses`; el planeamiento se queda (R-01 de #109). El presupuesto total sigue siendo de 15 s.
2. **Caché por partes.** El planeamiento se guarda aunque falle una parte secundaria (las tablas, el plan en vigor o la Z), y la visita siguiente pide solo lo que falló. Las filas de las tablas se guardan por `UBOV_ID` con el TTL del planeamiento. Nada incompleto llega a la CDN: la ruta sigue mandando `no-store` a toda ficha degradada.
3. **Logs.** Los loggers de `hi_api` no tenían nivel, heredaban WARNING de la raíz y en producción no salía ningún `log.info`. `hi_api.logs.install()` los pone a INFO, con salida a stdout y el filtro que tapa la dirección tecleada. La línea de cada ficha añade `parts=`, con la etapa, la clase de error y los ms de cada parte que falló; no lleva dirección ni coordenadas.
4. **Cache-Control:** los errores de `?address=` y `?q=` van `private, no-store`, porque la dirección viaja en la URL.
5. **Revisión del #111:**
   - Un registro al que le faltó el `UBOV_ID` no se repara por partes: se vuelve a pedir entero, así que no se queda congelado.
   - Una reparación que sigue incompleta conserva la caducidad que tenía.
   - Las tablas 4 y 5 van en un `TaskGroup`: si una falla, la otra se cancela.
   - Un plazo agotado se registra como `TimeoutError`, no como `CancelledError`.
   - Las etapas del log son `instrument`, `z`, `plan_uses` y `planning`.
   - Los 422 de la búsqueda por parcela salen `private, no-store` y sin el `input` que FastAPI repite.
   - Los avisos de `search.py` registran valores cerrados (claves de la API o del catálogo), nunca texto tecleado, y se quedan como están.
6. **Cómo volver atrás:** revertir el PR.

## D-252c — Usos del plan precargados (2026-11-20)
Hotfix de producción tras D-252b. Ya con los logs de D-252b en producción, Méndez, Luis Misson y Mayor 61 seguían saliendo con `plan_uses:TimeoutError` (4,6–7,0 s en las tablas), después de 7,6–10 s de Catastro y capa 3; Almería salió completa.

1. **Medición** (coordinador, desde Madrid): una consulta a la tabla 4 o 5 de USOS_SUELO con un CODIGO que sigma no tiene en caché tarda **6,5–10 s en su servidor** (TTFB de 8,4, 10,4, 7,0, 8,0 y 6,5 s). Solo responde en 0,2 s si ya se ha pedido antes. En local se medían 0,08–0,27 s porque eran consultas calientes. Con 15 s de presupuesto para todo, no caben.
2. **Decisión: precargar las tablas.** `scripts/usos_suelo_tablas.py` las descarga enteras, una vez, en unas 26 peticiones en serie y con pausas:
   - por cada tabla, el recuento y los ids;
   - después, ventanas de como mucho 2.000 OBJECTID, que es su maxRecordCount;
   - comprueba que las filas leídas cuadran con el recuento: 40.021 en la tabla 4 y 1.328 en la 5.
   
   El fichero bruto va a bronze, con su manifiesto, la URL y la licencia (CC BY 4.0 del Ayuntamiento, conjunto 300744; comprobada en su CKAN el 19 nov; el portal no respondió el 20). Luego se escriben dos tablas versionadas:
   - `usos_suelo_edificabilidad.csv`: las 10.545 filas con cifra, por CODIGO;
   - `usos_suelo_parcelas.csv`: los CODIGO de la tabla 4 en 20.487 tramos de CODIGO seguidos con el mismo uso principal, con su índice en `usos_suelo_usos.csv`, que tiene los usos de las dos tablas.
3. **Módulo generado** `hi_domain.plan_uses_data` (627 KB, con `--check` en `make lint` y test en `tests/data`). Los tramos de la tabla 4 van codificados como diferencias (hueco, largo, uso) y se descodifican una vez al importar (comprobado contra las 40.021 filas del bronze al generarlo: ningún desajuste):
   - Es un `.py` y no un `.json.gz` porque la imagen de la API instala los paquetes como wheels de hatchling (que incluyen todo `src/hi_domain`) con `UV_COMPILE_BYTECODE=1`: el bytecode se compila al construir.
   - Importarlo en frío sin compilar tarda 78 ms.
4. **La API ya no pide las tablas.** `plan_uses` sale del snapshot por el UBOV_ID de la capa 3, con la fecha «del plan a fecha 20/11/2026», y ya no se degrada por las tablas: solo si la capa 3 no da UBOV_ID (R-07 de #109).
   - **Uso sin cifra.** Cada parcela urbanística tiene en la tabla 4 una fila con su uso principal, casi siempre sin cifra (30.759 de 40.021). Si la parcela está en la tabla 4 sin cifra, la ficha dice su uso: «El plan fija su uso principal (residencial vivienda colectiva), pero sin cifra de edificabilidad». Si ese uso es «SIN USO PORMENORIZADO» (146 filas, 144 sin cifra; Almería 1, CODIGO 50282, es una), dice «El plan no fija uso pormenorizado ni cifra de edificabilidad para esta parcela urbanística». Si no está en la tabla, dice «El plan no publica la edificabilidad por uso».
   - **Código retirado.** Se quita el de las tablas en vivo: consulta, reintento, presupuesto propio y caché de filas por UBOV_ID.
   - **Caché por partes.** La de D-252b se queda para el plan en vigor y la Z.
5. **El plan en vigor y la Z, acotados** (deuda señalada en la revisión del #110): se piden con el tiempo que queda hasta el plazo de la ficha. Si se pasan, solo se degrada su parte. La capa 3 es la única cuyo fallo tumba el planeamiento.
6. **Tiempos en el log.** La línea `parcel …` añade `stages=` con los ms de cada etapa (catastro, planning, layer3, instrument, z), también en las fichas completas, para ver dónde se van los segundos.
7. **Catálogo (para #110), medido:** 3 consultas en frío a EDIFICIOS_PROTEGIDOS/MapServer/5 en puntos de Sol y la Gran Vía tardaron 81–313 ms. No hace falta precargarlo.
8. **Llamadas en vivo:** 26 para la descarga y 3 para medir el catálogo. **Cómo volver atrás:** revertir el PR.

## D-253 — Inversores: servicios y suministros, catálogo, edificio existente y primer filtro (2026-11-19)
Punto 1 de P7 (inversor) («los suministros son súper importantes»; en Madrid «no hay subestaciones libres») y auditoría de experto, D1, D5 y D6. Es aditivo y sin cifras de terceros que no se puedan reutilizar. **`fit` y `gap_row` no cambian; el golden tampoco.** Código: `hi_domain.supplies`, `hi_domain.parcels` (`CatalogEntry`, `ExistingBuilding`, sus avisos), `hi_api.services.parcels` (capa del catálogo), `parcel_sheet.py`, la ficha, «Cómo lo calculamos» y el catálogo (`data/catalog`). Textos: `pitch/textos_web.md` §11.

1. **«Solar» es una condición legal.** Ley 9/2001 del Suelo de la Comunidad de Madrid, art. 14.1.a: completamente urbanizada, con calzadas pavimentadas, aceras, y agua, saneamiento, electricidad y alumbrado público conectados a las redes públicas. Ningún dato abierto lo dice por parcela, y la ficha lo dice así. La sección nueva «4. Servicios y suministros» (en la ficha, en papel y en el método) da lo que sí se sabe:
   - en una norma zonal, que es suelo urbano común o consolidado (NNUU arts. 3.1.4 y 3.2.2);
   - en un ámbito, el estado de sus obras de urbanización según el conjunto 203200, y si no están terminadas, la licencia con urbanización simultánea y garantía (arts. 19.3, 20.3 y 23.1);
   - en suelo del Portal del Suelo, si lo da por urbanizado.
2. **Potencia (supuesto).** Viviendas ≈ m² de partida / 80. Potencia = 5,75 kW por vivienda (electrificación básica) × el coeficiente de simultaneidad de la tabla 1 de la ITC-BT-10, como la imprime el BOE (suplemento 224 del 18/09/2002, p. 68; en el texto consolidado en línea faltan las comas de 14,3 y 15,3); por encima de 21 viviendas, 15,3 + (n − 21) · 0,5. Sin servicios comunes ni garaje, que se suman aparte: es un mínimo. Por encima de 100 kW: local para centro de transformación (RD 1048/2013, art. 26.1) y la extensión de red la paga quien pide el suministro (art. 25.2); hasta 100 kW en baja tensión, en suelo urbanizado, la hace la distribuidora y cobra los derechos de extensión (art. 25.1). Méndez Álvaro: unas 164 viviendas, al menos 499,1 kW.
3. **Capacidad de la red: solo un enlace.** El mapa de capacidad de demanda de la CNMC, y la frase «aunque haya red en la calle, la subestación puede no tener capacidad: antes de comprar, pregunta a la distribuidora (en Madrid, i-DE o UFD) por el CUPS de la parcela y la potencia». Ni cifras ni ficheros de la CNMC (su web no da licencia de reutilización: «Reservados todos los derechos»), de UFD ni de REE (sus avisos legales lo impiden). Se registra como fuente `cnmc_capacidad_redes`, solo enlace.
4. **Agua:** Canal de Isabel II no publica su red; su compromiso para una acometida nueva es de 10 días laborables «siempre que exista una red adecuada» (Comunidad de Madrid, información al consumidor).
5. **Palabras y plazos de los suministros** (en la ficha y en «Palabras que usamos»): CUPS (guía de la CNMC; Reglamento del RD 88/2026, art. 8), acometida, derechos de acometida (RD 1048/2013, art. 24.2; enganche y verificación, art. 29.1), quién paga la red (arts. 25.1, 25.2 y 25.5; TRLSRU art. 18.1.c) y centro de transformación (art. 26.1). Los plazos son solo los leídos en el BOE: RD 1183/2020, art. 13 (15 días hábiles en baja tensión, 30 entre 1 y 36 kV) y RD 1955/2000, art. 103 (con centro de transformación, presupuesto en 20 días hábiles y, si la obra la hace la distribuidora, 60 días hábiles desde el pago de los derechos, contados desde la cesión del local). Fuera los baremos de la Orden ITC/3519/2009 (vigencia sin verificar) y las cifras de ASPRIMA/Aelec.
6. **Catálogo de edificios protegidos** (datos.madrid.es 300158, CC BY 4.0): se lee en vivo en el punto de la parcela (capa 5 de EDIFICIOS_PROTEGIDOS), en paralelo, opcional y con el tiempo que queda hasta el plazo de la ficha (como el plan en vigor y la Z, D-252c). Si falla o se pasa, solo se degrada `catalog` y no se guarda en caché. En frío tarda 81–313 ms (D-252c). La capa también da «Descatalogado» y «Demolición total»: para esos no se dice «protegido», solo lo que da el catálogo y que se compruebe su ficha. Sin edificio en el punto: «No aparece en el catálogo en el punto de referencia de la parcela»; sin respuesta: «No lo hemos podido leer ahora». Nivel según el art. 4.3.4 de las NNUU. Aviso según el art. 4.3.7: en los niveles 1 y 2, ni en ruina hay licencia de demolición; en el nivel 3, la licencia puede obligar a mantener lo protegido. La cuenta de obra nueva no vale. Mayor 61: nº 02933, protección parcial (nivel 3). No cambia la edificabilidad de partida, solo avisa.
7. **Edificio existente:** si el Catastro dice que hay algo construido, se avisa con sus cifras (m², año, inmuebles en división horizontal) de que la calculadora no cuenta derribo, desalojo ni compra a los propietarios.
8. **Primer filtro** (auditoría D6): arriba de la ficha y en papel, «Esto es un primer filtro de minutos, gratis y con fuentes. No sustituye al estudio de viabilidad que hace una consultora o un arquitecto»; la sección «Lo que añade un estudio completo» (con suelos contaminados, Real Decreto 9/2005, en vigor); y «Llévate esta ficha (PDF) a tu consultora». Sin derivar contactos.
9. **Catálogo de datos:**
   - nuevos `ayto_edificios_protegidos` (300158, citado en las fuentes de la ficha cuando se lee) y `cm_costes_referencia_edificacion` (el CRG de D-252, documento de la Comunidad sin licencia propia, citado con su fuente);
   - nueva fuente `cnmc_capacidad_redes` (RESTRICTED, solo enlace);
   - 203200 ya estaba (D-241).
10. **Citas de D-252 con dónde comprobarlas:**
    - **Decreto 74/2009, art. 12.2** (precio máximo legal de venta por m² útil, fijado por orden): BOCM núm. 188 de 10/08/2009, pág. 8 (página 4 del PDF), columna derecha. https://www.bocm.es/boletin/CM_Orden_BOCM/2009/08/10/2009-08-10_06082009_0220.pdf
    - **Ordenanza fiscal del ICIO, art. 25** («El tipo de gravamen será del 3,75 por 100 de la base imponible»; el art. 23 fija la base en el coste de ejecución material). En el Libro de Ordenanzas Fiscales 2024 de la Agencia Tributaria Madrid, página 154 del PDF, capítulo IX; se cita sin número, porque el Libro solo la da como «Redacción vigente conforme a la aprobación por Acuerdo plenario del Ayuntamiento de Madrid, de 22 de diciembre de 2023». https://agenciatributaria.madrid.es/FWProjects/contribuyente/contenidos/06InfoDocu/01Ordenanzas/Libros/2023.2024/Libro2024.pdf
11. **Demos:** 4 llamadas en vivo (la capa del catálogo en el punto de cada parcela de demostración). Solo Mayor 61 está catalogado.
12. **Invariante:** el golden no se toca. **Cómo volver atrás:** revertir el PR; los campos nuevos son opcionales.
13. **Revisión del #110:**
   - La extensión de red: hasta 100 kW en baja tensión, en suelo urbanizado, la hace la distribuidora y cobra los derechos de extensión (RD 1048/2013, art. 25.1); en el resto la paga quien pide el suministro (art. 25.2). El local del centro de transformación por encima de 100 kW es del art. 26.1 del mismo RD, no de la ITC-BT-10.
   - Sin potencia estimada no se da ningún umbral.
   - Los 60 días hábiles del RD 1955/2000, art. 103, valen si la obra la hace la distribuidora y, con centro de transformación, cuentan desde la cesión del local.
   - Los estados terminados de las obras de un ámbito salen del dominio (`DONE_PHASES`, en `investorMethod.ts`), no de una copia en la web.
   - «Llévate esta ficha (PDF) a tu consultora: ahorra parte de la recopilación de datos públicos.»
   - La ordenanza del ICIO se cita sin número (punto 10): el número que se le daba no se ha podido comprobar.

## D-254 — La fila de vivienda de «Qué falta» pasa a ser contexto (`gap-0.4`, 2026-11-23)
Jurado simulado (§3.3, C4): la fila «Vivienda para familias» salía FALTA en 25 municipios, y 23 de ellos tienen más viviendas de más de 90 m² que hogares de 4 o más personas (Navas del Rey, 342 por cada 100 frente a 436 en los demás rurales). La referencia rural está inflada por las segundas residencias, así que la cifra no dice si falta vivienda y publicaba p = 0 y 4,65·10⁻²⁵⁶ por eso.
Desde `gap-0.4` es una fila de contexto: estado `CONTEXTO` (o `SIN_DATOS`), con su valor, su referencia y la explicación, sin ratio ni p, fuera de `GET /gaps/impact`, del mapa, de la tarjeta, del resumen y de las filas destacadas de la búsqueda. Se llama «Viviendas grandes por cada 100 hogares grandes (contexto)». El contrato lo dice en `method.context_rows` y lo valida: una fila de contexto nunca es FALTA, JUSTO ni CUBIERTO.
El nombre sale del dominio (`CONTEXT_ROWS`) y del catálogo a la vez, así que basta con desplegar: no hace falta sincronizar el registro. **Cómo volver atrás:** revertir el PR.

## D-255 — MCP remoto de solo lectura en `/api/v1/mcp` (2026-11-23)
Decisión de Mariano del 23 nov: un miembro del jurado tiene que poder conectar el MCP desde su cliente de IA sin instalar nada. Hasta hoy solo funcionaba en local, por stdio (D-225), y `/desarrolladores` daba el MCP en remoto como planteado (D-249). Es aditivo y reversible: un fichero nuevo (`services/mcp/src/hi_mcp/http.py`), su test y dos líneas del `Dockerfile`. **Ninguna ruta, contrato, herramienta ni tabla de la API cambia; `fit`, `gap_row` y el golden tampoco.** Uso y configuración de los clientes: `docs/04_technical_architecture/32_mcp_server.md`, «En remoto».

1. **URL:** `https://vidafacil-madrid.vercel.app/api/v1/mcp`. Tiene que ir bajo `/api/v1/`, porque `vercel.json` solo envía eso al contenedor; `/mcp` caería en Next.js y pediría otra regla.
2. **Dónde vive.** El contenedor arranca `hi_mcp.http:app` en lugar de `hi_api.main:app`:
   - es la API, montada tal cual, con una sola ruta delante, `/api/v1/mcp` (una `Route`, no un `Mount`, para no redirigir a `/api/v1/mcp/`);
   - no toca `hi_api`, así que no hay dependencia circular `hi_api → hi_mcp`;
   - la imagen instala `hi-mcp`, que arrastra `hi-api` (`uv sync --package hi-mcp`; suma el SDK `mcp` y sus dependencias).
3. **El *lifespan*.** El gestor de sesiones del transporte Streamable HTTP tiene que correr dentro del *lifespan* de la app, y solo una vez por instancia. `create_app()` crea el suyo (en los tests, uno por app) y lo envuelve con el de la API, porque el *lifespan* de una app montada no se ejecuta solo.
4. **Sin estado y con respuestas JSON** (`stateless_http=True`, `json_response=True`). Vercel no da afinidad de sesión, así que no hay `Mcp-Session-Id` ni flujo SSE. Solo POST: GET, DELETE y OPTIONS dan 405. Sin estado, el SDK dejaría un GET abierto como flujo SSE vacío hasta que lo cortara el cliente o la plataforma. Sin OPTIONS ni CORS no hay *preflight*, así que los clientes MCP de navegador (el Inspector conectado directamente) no pueden usarlo; Claude.ai, Claude Code y `mcp-remote` sí.
5. **Protección contra DNS rebinding: se configura, no se desactiva.** Por defecto el SDK solo admite localhost (daría 421 en producción). Sus listas quedan explícitas, y se pueden cambiar con `MCP_ALLOWED_HOSTS` y `MCP_ALLOWED_ORIGINS` sin tocar el código (listas JSON que sustituyen a la lista por defecto):
   - **Hosts:** `vidafacil-madrid.vercel.app`, `vida-facil-eight.vercel.app` y `127.0.0.1:*`, `localhost:*` y `[::1]:*` (local, tests y el paquete offline). Otro `Host` da 421.
   - **Orígenes**, que solo se comprueban si la petición trae `Origin`: las dos webs, `https://claude.ai`, `https://claude.com` y localhost. Otro da 403.
   - **Por qué así:** sin cookies ni autenticación, lo que protege es que el servidor solo responda en nuestros dominios. Claude.ai entra por si su conector manda `Origin`. Los clientes de servidor, curl y `mcp-remote` no lo mandan.
6. **Lo mismo que la API.** Las 7 herramientas de `build_server` (D-249), los mismos servicios, el mismo *engine* (`hi_api.deps.get_engine`, pool 1 + 0 en producción) y el mismo rol de solo lectura (`vf_api_ro`, por `DATABASE_URL`). Cada llamada va en una transacción `READ ONLY`. Ninguna herramienta llama al Catastro ni a otro servicio externo: la búsqueda por parcela, con su guarda y su caché (`upstream_guard.py`), sigue solo en la API. Sin autenticación ni límite de uso propio, como el resto de la API.
7. **Registros.** El SDK configura el registro raíz para stdio (INFO, a stderr). En el contenedor duplicaría cada línea de la API y sacaría líneas de librerías que hoy no salen, así que `http.py` lo deja como estaba. `hi_mcp` escribe por stdout, como `hi_api`, el nombre y el tiempo de cada herramienta, nunca sus argumentos.
   - **Un fallo del MCP no tumba la API** (revisión del #123, R-01). El SDK se importa al construir la app, no al cargar el módulo. Si la construcción falla, `hi_mcp.http:app` es `hi_api.main:app` tal cual: el MCP da 404 y el registro dice «MCP server not built». Si el gestor de sesiones no arranca en el *lifespan*, se registra («MCP session manager did not start»), la API arranca igual y `/api/v1/mcp` da 503. El smoke (`initialize` y `tools/list`) lo detecta en los dos casos.
8. **Tests** (`tests/unit/mcp/test_http.py`, sin base ni red, con el cliente ASGI de httpx):
   - `initialize` (JSON y sin sesión) y `tools/list` → 7;
   - `tools/call` de `viabilidad`, igual que su ruta, y la base caída como error de herramienta;
   - los hosts públicos pasan; otro `Host` da 421 y otro `Origin`, 403;
   - GET, DELETE y OPTIONS dan 405;
   - sin SDK, o con un fallo al construir el MCP, la API arranca sola (`health` 200); con un fallo del gestor de sesiones, la API arranca y el MCP da 503;
   - `/api/v1/health`, `/api/v1/datasets`, `openapi.json` y un 404 responden igual que `hi_api.main:app`.
   - Comprobado además en local, sin Docker, con un entorno instalado como la imagen (`uv sync --package hi-mcp --no-dev --no-editable`) y el mismo `uvicorn` del `CMD`: curl (`initialize`, `tools/list`, 421, 405), el cliente oficial del SDK por HTTP (`list_tools` → 7 y `viabilidad`) y, con un paquete `mcp` que no se importa, la API arrancando sola (`health` 200, MCP 404).
9. **Después de desplegar:** `tools/list` por curl contra la URL tiene que dar 7 (comando en `32_mcp_server.md`), y hay que probar un cliente real (Claude Code con `--transport http` y el conector de Claude.ai). **Riesgo:** si el proxy de Vercel entregara al contenedor otro `Host` que el dominio público, todo daría 421 y quedaría «Invalid Host header: …» en los registros. Se corrige con `MCP_ALLOWED_HOSTS` y un redespliegue, sin tocar la API. `/desarrolladores` se actualiza aparte, cuando esté verificado en producción.
10. **Cómo volver atrás:** revertir el PR y desplegar, o un rollback al despliegue anterior. No hay datos, migraciones ni sincronización que deshacer.

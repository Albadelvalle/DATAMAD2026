"use client";

import { Baby, BedDouble, CircleParking, Cross, Dumbbell, GraduationCap, HeartHandshake, Hospital, Landmark, type LucideIcon, Pill, Trees, Utensils, Wine } from "lucide-react";
import { useId } from "react";

import { type FacilitiesStatus, useFacilityLayer } from "@/components/map/FacilityLayerProvider";
import { useDatasets } from "@/components/provenance/useDatasets";
import Button from "@/components/ui/Button";
import Chip from "@/components/ui/Chip";
import GlassCard from "@/components/ui/GlassCard";
import { SLOW_TEXT, useSlow } from "@/components/ui/useSlow";
import { errorMessage } from "@/lib/errors";
import { formatNumber } from "@/lib/format";
import {
  capacitySources,
  type Facility,
  FACILITY_COLOR_TOKEN,
  type FacilityKey,
  facilityCountText,
  facilityType,
  HOSPITAL_DEPENDENCY_NOTE,
  hospitalLine,
  hospitalSplitText,
  isLeisureFacility,
  leisureAvailable,
  offeredTypes,
  parkingAvailable,
  orderedTypes,
  selectedCountText,
  SERVICE_FACILITY_KEYS,
} from "@/lib/map/facilities";

import DependencyPill from "./DependencyPill";
import styles from "./FacilitiesPanel.module.css";

// Copy of pitch/textos_web.md, section 5b (T3), with centros.camas and centros.sin_nombre_algunos (HOSP-001).
const TEXT = {
  title: "Todos los centros",
  show: "Ver en el mapa",
  loading: (zone: string) => `Buscando los centros de ${zone}…`,
  // centros.ocio.cargando (D-236): each leisure type is asked when its button is pressed
  leisureLoading: (many: string, zone: string) => `Buscando ${many} en ${zone}…`,
  retry: "Reintentar",
  none: "Toca uno o varios tipos de centro para verlos en el mapa.", // B's draft for D (several at once)
  all: "Todos",
  nothing: "Ninguno",
  list: (n: number) => `Ver la lista (${formatNumber(n, 0)})`,
  // The same schools as the row «Colegios» (gap_rows of places-1): public and concertado
  rowSchools: "Públicos y concertados: los mismos que cuenta «Qué falta».",
  noName: "La fuente oficial no publica el nombre de cada centro de este tipo.",
  // centros.sin_nombre_algunos: the name comes from the Ministry's catalogues; a few could not be matched
  someNoName: "Algunos centros salen sin nombre porque no hemos podido comprobarlo en las fuentes oficiales.",
  // centros.camas (HOSP-001, D-218): the date and the catalogue from /datasets
  // centros.ocio.fuente (D-236): leisure comes from OpenStreetMap, never an official register
  leisure: "Según OpenStreetMap, un mapa hecho por voluntarios: puede faltar algún local o salir sin nombre.",
  bedsBefore: (updated: string | null) => `Camas instaladas${updated ? ` a ${updated}` : ""}, según el `,
  bedsAfter: (publisher: string) => ` del ${publisher}.`,
  newTab: " (se abre en una pestaña nueva)",
  // centros.hospital.que_significa: folds centros.hospital.dependencia (15 nov)
  meaning: "¿Qué significa público y privado?",
};

/** centros.camas: «Camas instaladas a 31 de diciembre de 2024, según el Catálogo … 2025 del Ministerio de Sanidad.» */
function CapacitySourceLine({ type, items }: { type: FacilityKey; items: Facility[] }) {
  const { data } = useDatasets();
  return capacitySources(type, items, data?.datasets ?? null).map((source) => (
    <p key={source.id} className={styles.muted}>
      {TEXT.bedsBefore(source.updated)}
      {source.href ? (
        <a href={source.href} target="_blank" rel="noopener noreferrer">
          {source.catalogue}
          <span className="visually-hidden">{TEXT.newTab}</span>
        </a>
      ) : (
        source.catalogue
      )}
      {TEXT.bedsAfter(source.publisher)}
    </p>
  ));
}

export const FACILITY_ICON: Record<FacilityKey, LucideIcon> = {
  colegio: GraduationCap,
  escuela_infantil: Baby,
  centro_salud: Cross,
  hospital: Hospital,
  farmacia: Pill,
  mayores: HeartHandshake,
  parque: Trees,
  bares: Wine,
  restaurantes: Utensils,
  gimnasios: Dumbbell,
  cultura: Landmark,
  aparcamiento: CircleParking,
};

/** «Hospital La Paz · 1.300 camas» when the API gives the name and the capacity; the label alone otherwise. */
export function facilityLine(f: Facility): { label: string; rest: string | null } {
  const rest = [f.name, f.detail].filter(Boolean).join(" · ");
  return { label: f.label, rest: rest || null };
}

/** In the list a park leads with its own name («Parque del Retiro · 118 ha»): the list already says it is a park. */
function listLine(f: Facility): { label: string; rest: string | null } {
  return f.name && facilityType(f.type).nameFirst ? { label: f.name, rest: f.detail } : facilityLine(f);
}

/** centros.hospital.fila: «[Público] Hospital Universitario La Paz», what else to know under it, and «[cama] 966» beside it. */
function HospitalItem({ facility }: { facility: Facility }) {
  const { dependency, name, notes, beds } = hospitalLine(facility);
  return (
    <>
      <span className={styles.hospitalName}>
        {dependency && <DependencyPill dependency={dependency} />} <strong>{name}</strong>
        {notes.length > 0 && <small>{notes.join(" · ")}</small>}
      </span>
      {beds && (
        <span className={styles.beds}>
          <BedDouble size={16} aria-hidden="true" />
          <span aria-hidden="true">{beds.short}</span>
          <span className="visually-hidden">{beds.full}</span>
        </span>
      )}
    </>
  );
}

function FacilityList({ items, count }: { items: Facility[]; count: string }) {
  return (
    <details className={styles.details}>
      <summary>{TEXT.list(items.length)}</summary>
      {/* Focusable, so the list can be scrolled with the keyboard */}
      <ul className={styles.list} tabIndex={0} aria-label={count}>
        {items.map((f) => {
          if (f.type === "hospital") {
            return (
              <li key={f.id} className={styles.hospital}>
                <HospitalItem facility={f} />
              </li>
            );
          }
          const { label, rest } = listLine(f);
          return (
            <li key={f.id}>
              <strong>{label}</strong>
              {rest && <span> · {rest}</span>}
            </li>
          );
        })}
      </ul>
    </details>
  );
}

/** A leisure type pressed while its own request is on its way, or after it failed (D-236). */
function LeisurePending({ type, zone, status }: { type: FacilityKey; zone: string; status: FacilitiesStatus | undefined }) {
  const { leisureErrors, retryLeisure } = useFacilityLayer();
  const error = isLeisureFacility(type) ? leisureErrors[type] : undefined;
  if (status === "error" && error && isLeisureFacility(type)) {
    return (
      <div role="alert" className={styles.error}>
        <p>{errorMessage(error)}</p>
        <Button variant="secondary" onClick={() => retryLeisure(type)}>
          {TEXT.retry}
        </Button>
      </div>
    );
  }
  return (
    <p role="status" className={styles.muted}>
      {TEXT.leisureLoading(facilityType(type).many, zone)}
    </p>
  );
}

/** One type pressed: how many there are in the zone, what the source does not say, and its list. */
function TypeSummary({ type, items, zone }: { type: FacilityKey; items: Facility[]; zone: string }) {
  const count = facilityCountText(type, items.length, zone);
  // centros.hospital.reparto and centros.hospital.dependencia (D-239)
  const split = type === "hospital" ? hospitalSplitText(items) : null;
  return (
    <div className={styles.typeSummary}>
      <p className={styles.count}>
        <span className={styles.dot} style={{ background: `var(--${FACILITY_COLOR_TOKEN[type]})` }} aria-hidden="true" />
        {count}
        {split && `: ${split}`}
      </p>
      {split && (
        <details className={styles.meaning}>
          <summary>{TEXT.meaning}</summary>
          <p className={styles.muted}>{HOSPITAL_DEPENDENCY_NOTE}</p>
        </details>
      )}
      {type === "colegio" && items.length > 0 && <p className={styles.muted}>{TEXT.rowSchools}</p>}
      {facilityType(type).leisure ? (
        <p className={styles.muted}>{TEXT.leisure}</p>
      ) : (
        items.some((f) => f.name === null) && (
          <p className={styles.muted}>{items.every((f) => f.name === null) ? TEXT.noName : TEXT.someNoName}</p>
        )
      )}
      <CapacitySourceLine type={type} items={items} />
      {items.length > 0 && <FacilityList items={items} count={count} />}
    </div>
  );
}

/**
 * «Todos los centros» (FASE_PRUEBAS, T3): every facility of the zone, not only its key points. A
 * button per type with how many there are; several types can be on at once (petición de Mariano,
 * 13 nov), each with its colour on the map, grouped, and listed here, which is also the way to see
 * them without the map. Filtered on the client: /places brought the services in one request;
 * each leisure type (D-236) is asked apart when its button is pressed and stays out of «Todos».
 */
export default function FacilitiesPanel({ zone }: { zone: string }) {
  const { status, groups, error, retry, types, readyTypes, leisure, toggle, setAll } = useFacilityLayer();
  const titleId = useId();
  const slow = useSlow(status === "loading");
  // Leisure (D-236) once its dataset is published; each type is asked when pressed, never with «Todos»
  const { data: datasets } = useDatasets();
  // Car parks (D-237) only once their datasets are published: never a false 0 before the sync
  const offered = offeredTypes(leisureAvailable(datasets?.datasets), parkingAvailable(datasets?.datasets));
  const shown = orderedTypes(types).filter((key) => offered.some((t) => t.key === key));
  const allServices = SERVICE_FACILITY_KEYS.every((key) => types.includes(key));
  const countOf = (key: FacilityKey) =>
    groups && (!isLeisureFacility(key) || leisure[key] === "ready") ? formatNumber(groups[key].length, 0) : undefined;

  return (
    <GlassCard as="section" aria-labelledby={titleId} className={styles.card}>
      <h2 id={titleId} className={styles.title}>
        {TEXT.title}
      </h2>
      {status === "loading" && (
        <p role="status" className={styles.muted}>
          {TEXT.loading(zone)}
          {slow && ` ${SLOW_TEXT}`}
        </p>
      )}
      {status === "error" && error && (
        <div role="alert" className={styles.error}>
          <p>{errorMessage(error)}</p>
          <Button variant="secondary" onClick={retry}>
            {TEXT.retry}
          </Button>
        </div>
      )}
      {groups && (
        <>
          <div role="group" aria-labelledby={`${titleId}-show`} className={styles.types}>
            <p id={`${titleId}-show`} className="visually-hidden">
              {TEXT.show}
            </p>
            <ul className={styles.chips}>
              {offered.map((t) => (
                <li key={t.key}>
                  <Chip
                    label={t.chip}
                    icon={FACILITY_ICON[t.key]}
                    color={`var(--${FACILITY_COLOR_TOKEN[t.key]})`}
                    count={countOf(t.key)}
                    pressed={types.includes(t.key)}
                    onToggle={() => toggle(t.key)}
                  />
                </li>
              ))}
            </ul>
            <div className={styles.all}>
              <button type="button" onClick={() => setAll(true)} disabled={allServices}>
                {TEXT.all}
              </button>
              <button type="button" onClick={() => setAll(false)} disabled={shown.length === 0}>
                {TEXT.nothing}
              </button>
            </div>
          </div>
          {/* Told when the types change; the lists below are not read out each time */}
          <p role="status" aria-live="polite" className="visually-hidden">
            {selectedCountText(groups, shown.filter((key) => readyTypes.includes(key)), zone) ?? TEXT.none}
          </p>
          <div className={styles.summary}>
            {shown.length ? (
              shown.map((type) =>
                readyTypes.includes(type) ? (
                  <TypeSummary key={type} type={type} items={groups[type]} zone={zone} />
                ) : (
                  <LeisurePending key={type} type={type} zone={zone} status={isLeisureFacility(type) ? leisure[type] : undefined} />
                ),
              )
            ) : (
              <p className={styles.muted}>{TEXT.none}</p>
            )}
          </div>
        </>
      )}
    </GlassCard>
  );
}

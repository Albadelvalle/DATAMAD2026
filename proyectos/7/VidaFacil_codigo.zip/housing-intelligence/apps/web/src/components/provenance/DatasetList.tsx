"use client";

import { ExternalLink } from "lucide-react";

import Button from "@/components/ui/Button";
import { SLOW_TEXT, useSlow } from "@/components/ui/useSlow";
import { errorMessage } from "@/lib/errors";
import { datasetLines, sortDatasets } from "@/lib/provenance";

import styles from "./DatasetList.module.css";
import { useDatasets } from "./useDatasets";

// Copy from pitch/textos_web.md (fuente.*, carga.fuentes, error.reintentar).
const TEXT = {
  loading: "Cargando los conjuntos de datos…",
  retry: "Reintentar",
  open: "Abrir en el portal",
  // The accessible name starts with the visible text (WCAG 2.5.3) and then says which and where
  openHint: (name: string) => `: ${name} (se abre en una pestaña nueva)`,
};

/** Every dataset behind Vida Fácil (GET /api/v1/datasets): who publishes it, version, licence and link. */
export default function DatasetList() {
  const { loading, data, error, retry } = useDatasets();
  const slow = useSlow(loading);

  if (loading) {
    return (
      <p role="status">
        {TEXT.loading}
        {slow && ` ${SLOW_TEXT}`}
      </p>
    );
  }
  if (error || !data) {
    return (
      <div role="alert" className={styles.error}>
        <p>{error ? errorMessage(error) : TEXT.loading}</p>
        <Button variant="secondary" onClick={retry}>
          {TEXT.retry}
        </Button>
      </div>
    );
  }
  return (
    <ul className={styles.list}>
      {sortDatasets(data.datasets).map((ref) => {
        const lines = datasetLines(ref);
        return (
          <li key={ref.dataset_id} className={styles.item}>
            <p className={styles.title}>{lines.title}</p>
            {lines.portal && <p className={styles.portal}>{lines.portal}</p>}
            {[lines.version, lines.license].filter(Boolean).map((line) => (
              <p key={line} className={styles.meta}>
                {line}
              </p>
            ))}
            {lines.url && (
              <a href={lines.url} target="_blank" rel="noopener noreferrer" className={styles.link}>
                {TEXT.open}
                <span className="visually-hidden">{TEXT.openHint(ref.name)}</span>
                <ExternalLink size={16} aria-hidden="true" />
              </a>
            )}
          </li>
        );
      })}
    </ul>
  );
}

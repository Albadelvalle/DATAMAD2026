"use client";

import { ChevronDown } from "lucide-react";
import Link from "next/link";
import { useEffect, useId, useState } from "react";

import { fetchZones } from "@/components/map/fetchZones";
import { useGapRowMap } from "@/components/map/useGapRowMap";
import Button from "@/components/ui/Button";
import Help from "@/components/ui/Help";
import { SLOW_TEXT, useSlow } from "@/components/ui/useSlow";
import type { ZoneGapStatus } from "@/contracts/gap_row_map_response";
import type { GapRowKey } from "@/contracts/zone_gap_list_response";
import { ApiError } from "@/lib/api";
import { errorMessage } from "@/lib/errors";
import { GAP_STATUS, gapsHref, GROUP, inGroup, notComparable, notComparableHelp, SMALL_ZONE } from "@/lib/gaps";
import { searchable, wholeCities, zoneDirectory, type ZoneCollection, zoneHref, type ZoneProperties } from "@/lib/map/zones";

import GapBadge from "./GapBadge";
import GroupTag from "./GroupTag";
import SmallZoneTag from "./SmallZoneTag";
import styles from "./ZoneDirectory.module.css";

// Copy from pitch/textos_web.md (zonas.*, carga.zonas, carga.estado_zonas, error.reintentar).
const TEXT = {
  loading: "Cargando las zonas…",
  retry: "Reintentar",
  search: "Busca una zona",
  distritos: "Distritos de Madrid",
  municipios: "Municipios",
  none: "No hay ninguna zona con ese nombre.",
  wholeCity: (name: string) => `${name} (toda la ciudad)`,
  loadingRow: "Cargando el estado de cada zona…",
  // zonas.ver_todas, zonas.ver_menos: the folded list of «Qué falta»
  all: (n: number) => `Ver las ${n} zonas`,
  fewer: "Ver menos",
  // zonas.estados: what each status of the list means, behind a «?» (they were tooltips, UX mobile audit A5)
  statuses: "¿Qué quiere decir cada estado?",
  statusesAbout: "de la lista de zonas",
};

/**
 * What FALTA, JUSTO, CUBIERTO, SIN DATOS, «No comparable» and «Junto con sus vecinos» mean, once over
 * the lists; «No comparable» in the unit of the list's row, as its tags say it to screen readers.
 */
function StatusesHelp({ row }: { row: GapRowKey }) {
  const lines: [string, string][] = [
    // A list by row is never of a context row (gap-0.4): CONTEXTO is not one of its statuses
    ...Object.values(GAP_STATUS)
      .filter((s) => s !== GAP_STATUS.CONTEXTO)
      .map((s) => [s.label, s.help] as [string, string]),
    [SMALL_ZONE.label, notComparableHelp(row)],
    [GROUP.label, GROUP.help],
  ];
  return (
    <Help about={TEXT.statusesAbout} label={TEXT.statuses}>
      <ul>
        {lines.map(([label, help]) => (
          <li key={label}>
            <strong>{label}:</strong> {help}
          </li>
        ))}
      </ul>
    </Help>
  );
}

type Result = { zones: ZoneCollection } | { error: ApiError };

type HrefFor = (zone: ZoneProperties) => string;

interface LinksProps {
  title: string;
  zones: ZoneProperties[];
  hrefFor: HrefFor;
  /** Each zone's status in a row of «Qué falta», when the list shows one */
  statuses?: ReadonlyMap<string, ZoneGapStatus> | null;
  /** What a «No comparable» tag of the list says to screen readers: the row's reason */
  smallZoneHelp?: string;
}

function ZoneLinks({ title, zones, hrefFor, statuses, smallZoneHelp }: LinksProps) {
  const id = useId();
  if (zones.length === 0) return null;
  return (
    <section aria-labelledby={id} className={styles.group}>
      <h2 id={id}>
        {title} <span className={styles.count}>({zones.length})</span>
      </h2>
      <ul className={styles.list}>
        {zones.map((zone) => {
          const gap = statuses?.get(zone.admin_unit_id);
          return (
            <li key={zone.zone_key}>
              <Link href={hrefFor(zone)}>{zone.name}</Link>
              {gap && (notComparable(gap) ? <SmallZoneTag help={smallZoneHelp} /> : <GapBadge status={gap.status} />)}
              {gap && inGroup(gap) && <GroupTag />}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

interface Props {
  /** Where each zone leads: its screen by default, its «Qué falta» list from that tab. */
  hrefFor?: HrefFor;
  placeholder?: string;
  /** The map's alternative for a row of «Qué falta»: each zone with its status in that row. */
  row?: GapRowKey | null;
  /** Also list Madrid capital as a whole, whose «Qué falta» list exists although the map splits it. */
  wholeCities?: boolean;
  /**
   * Keep the districts and municipios behind «Ver las N zonas» until the person opens them or types
   * a name («Qué falta» on a phone: the whole list is a very long scroll).
   */
  folded?: boolean;
}

/** The map's alternative: every zone as a link, with a filter by name (keyboard and screen readers). */
export default function ZoneDirectory({ hrefFor = zoneHref, placeholder, row = null, wholeCities: withCities = false, folded = false }: Props) {
  const rowMap = useGapRowMap(row);
  const inputId = useId();
  const listId = useId();
  const [all, setAll] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [query, setQuery] = useState("");
  const slow = useSlow(result === null);

  useEffect(() => {
    let cancelled = false;
    fetchZones()
      .then((zones) => {
        if (!cancelled) setResult({ zones });
      })
      .catch((exc: unknown) => {
        if (!cancelled) setResult({ error: exc instanceof ApiError ? exc : new ApiError(0, "NETWORK", String(exc)) });
      });
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  if (!result) {
    return (
      <p role="status">
        {TEXT.loading}
        {slow && ` ${SLOW_TEXT}`}
      </p>
    );
  }
  if ("error" in result) {
    return (
      <div role="alert" className={styles.error}>
        <p>{errorMessage(result.error)}</p>
        <Button
          variant="secondary"
          onClick={() => {
            setResult(null);
            setAttempt((n) => n + 1);
          }}
        >
          {TEXT.retry}
        </Button>
      </div>
    );
  }
  const { distritos, municipios } = zoneDirectory(result.zones, query);
  // A «No comparable» tag of the list says the reason in the unit of its row («Qué falta» by row)
  const smallZoneHelp = row ? notComparableHelp(row) : undefined;
  // A name typed in the field shows its zones at once, folded or not
  const searching = query.trim() !== "";
  // The whole city leads to its «Qué falta» list: on the map it is its districts
  const cities = withCities
    ? wholeCities(result.zones).filter((c) => searchable(TEXT.wholeCity(c.name)).includes(searchable(query)))
    : [];
  return (
    <div className={styles.directory}>
      <label htmlFor={inputId} className={styles.label}>
        {TEXT.search}
      </label>
      <input id={inputId} type="search" placeholder={placeholder} value={query} onChange={(e) => setQuery(e.target.value)} className={styles.input} />
      <p role="status" className="visually-hidden">
        {distritos.length + municipios.length} zonas
      </p>
      {distritos.length + municipios.length + cities.length === 0 && <p>{TEXT.none}</p>}
      {cities.length > 0 && (
        <ul className={styles.list}>
          {cities.map((city) => {
            const gap = rowMap.data?.byZone.get(city.admin_unit_id);
            return (
              <li key={city.admin_unit_id}>
                <Link href={gapsHref("municipio", city.code)}>{TEXT.wholeCity(city.name)}</Link>
                {gap && (notComparable(gap) ? <SmallZoneTag help={smallZoneHelp} /> : <GapBadge status={gap.status} />)}
                {gap && inGroup(gap) && <GroupTag />}
              </li>
            );
          })}
        </ul>
      )}
      {row && rowMap.data && <StatusesHelp row={row} />}
      {row && rowMap.loading && <p role="status">{TEXT.loadingRow}</p>}
      {row && rowMap.error && (
        <div role="alert" className={styles.error}>
          <p>{errorMessage(rowMap.error)}</p>
          <Button variant="secondary" onClick={rowMap.retry}>
            {TEXT.retry}
          </Button>
        </div>
      )}
      {folded && !searching && (
        <button type="button" className={styles.toggle} aria-expanded={all} aria-controls={listId} onClick={() => setAll((v) => !v)}>
          {all ? TEXT.fewer : TEXT.all(distritos.length + municipios.length)}
          <ChevronDown size={18} aria-hidden="true" className={all ? styles.flip : undefined} />
        </button>
      )}
      <div id={listId} className={styles.groups} hidden={folded && !all && !searching}>
        <ZoneLinks title={TEXT.distritos} zones={distritos} hrefFor={hrefFor} statuses={rowMap.data?.byZone} smallZoneHelp={smallZoneHelp} />
        <ZoneLinks title={TEXT.municipios} zones={municipios} hrefFor={hrefFor} statuses={rowMap.data?.byZone} smallZoneHelp={smallZoneHelp} />
      </div>
    </div>
  );
}

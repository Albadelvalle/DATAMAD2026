/**
 * Every facility of a zone (pure, unit tested), not only its key points (FASE_PRUEBAS, T3): the
 * places of /api/v1/places (places-1) asked by zone and subcategory, grouped in the types a person
 * looks for and named in plain words. A type with a row of «Qué falta» counts the places the API
 * says that row counts (`gap_rows`), so the figures agree; hospitals and parks have no row.
 */
import type { DatasetRef } from "@/contracts/dataset_list_response";
import type { AccessFee, GapRowKey } from "@/contracts/places_response";
import type { PlaceCategory } from "@/lib/api";
import { formatNumber } from "@/lib/format";
import { updatedInWords } from "@/lib/provenance";
import { titleCase } from "@/lib/names";

import type { PlaceFeature } from "./places";

export type LeisureFacilityKey = "bares" | "restaurantes" | "gimnasios" | "cultura";
export type FacilityKey = "colegio" | "escuela_infantil" | "centro_salud" | "hospital" | "farmacia" | "mayores" | "parque" | LeisureFacilityKey | "aparcamiento";

export interface FacilityType {
  key: FacilityKey;
  category: PlaceCategory;
  /** Row of «Qué falta» whose places this type shows (`gap_rows` of places-1) */
  row?: GapRowKey;
  /** Name of the type on its button */
  chip: string;
  /** How many there are: «{n} {many}», «1 {one}», «{none}» */
  one: string;
  many: string;
  none: string;
  /** Subcategories of /places that count, each with the label of one place */
  classes: { subcategory: string; label: string }[];
  /** The list leads with the place's own name, which already says what it is («Parque del Retiro») */
  nameFirst?: boolean;
  /** Leisure from OpenStreetMap (D-236): a map made by volunteers, said under its count */
  leisure?: boolean;
  /** Context of the zone (D-237): offered once its datasets are published, never turned on by «Todos» */
  context?: boolean;
}

const PUBLIC_SCHOOL = "Colegio público";
const PRIVATE_SCHOOL = "Colegio privado o concertado";

export const FACILITY_TYPES: readonly FacilityType[] = [
  {
    key: "colegio",
    category: "education",
    row: "colegio",
    chip: "Colegios",
    one: "colegio con primaria",
    many: "colegios con primaria",
    none: "Ningún colegio con primaria",
    classes: [
      { subcategory: "COLEGIO DE EDUCACIÓN INFANTIL Y PRIMARIA", label: PUBLIC_SCHOOL },
      { subcategory: "COLEGIO DE EDUCACIÓN INFANTIL, PRIMARIA Y SECUNDARIA", label: PUBLIC_SCHOOL },
      { subcategory: "COLEGIO DE EDUCACIÓN PRIMARIA", label: PUBLIC_SCHOOL },
      { subcategory: "CENTRO PRIVADO DE EDUCACIÓN INFANTIL Y PRIMARIA", label: PRIVATE_SCHOOL },
      { subcategory: "CENTRO PRIVADO DE EDUCACIÓN INFANTIL, PRIMARIA Y SECUNDARIA", label: PRIVATE_SCHOOL },
      { subcategory: "CENTRO PRIVADO DE EDUCACIÓN PRIMARIA", label: PRIVATE_SCHOOL },
      { subcategory: "CENTRO PRIVADO DE EDUCACIÓN PRIMARIA Y SECUNDARIA", label: PRIVATE_SCHOOL },
    ],
  },
  {
    key: "escuela_infantil",
    category: "education",
    row: "escuela_infantil",
    chip: "Escuelas infantiles",
    one: "escuela infantil",
    many: "escuelas infantiles",
    none: "Ninguna escuela infantil",
    classes: [
      { subcategory: "ESCUELA INFANTIL", label: "Escuela infantil pública" },
      { subcategory: "ESCUELA  INFANTIL-CASA DE NIÑOS", label: "Casa de niños" },
      { subcategory: "ESCUELA INFANTIL PRIVADA", label: "Escuela infantil privada" },
      { subcategory: "CENTRO PRIVADO DE EDUCACIÓN INFANTIL", label: "Escuela infantil privada" },
    ],
  },
  {
    key: "centro_salud",
    category: "health",
    row: "centro_salud",
    chip: "Centros de salud",
    // The list has the consultorios too, which the row does not count as capacity (D, 12 nov)
    one: "centro de salud o consultorio",
    many: "centros de salud y consultorios",
    none: "Ningún centro de salud ni consultorio",
    classes: [
      { subcategory: "Centro de salud", label: "Centro de salud" },
      { subcategory: "Consultorio de atención primaria", label: "Consultorio" },
    ],
  },
  {
    key: "hospital",
    category: "health",
    chip: "Hospitales",
    one: "hospital",
    many: "hospitales",
    none: "Ningún hospital",
    classes: [
      { subcategory: "Hospital general", label: "Hospital" },
      { subcategory: "Hospital especializado", label: "Hospital especializado" },
      { subcategory: "Hospital de media y larga estancia", label: "Hospital de media y larga estancia" },
      { subcategory: "Hospital de salud mental y tratamiento de toxicomanías", label: "Hospital de salud mental" },
    ],
  },
  {
    key: "farmacia",
    category: "pharmacy",
    row: "farmacia",
    chip: "Farmacias",
    one: "farmacia",
    many: "farmacias",
    none: "Ninguna farmacia",
    classes: [{ subcategory: "Farmacia", label: "Farmacia" }],
  },
  {
    key: "mayores",
    category: "social",
    row: "mayores",
    chip: "Mayores",
    one: "centro de mayores",
    many: "centros de mayores",
    none: "Ningún centro de mayores",
    classes: [
      { subcategory: "CENTROS DE DÍA: OTROS", label: "Centro de día" },
      { subcategory: "HOGARES Y CLUBES", label: "Hogar o club de mayores" },
    ],
  },
  {
    // DATA-018 (D-222): urban parks of 1 ha or more from OSM, Casa de Campo and Torre Arias included.
    // Their names come as the API gives them, «Parque sin nombre» too.
    key: "parque",
    category: "green",
    chip: "Parques",
    one: "parque de 1 ha o más",
    many: "parques de 1 ha o más",
    none: "Ningún parque de 1 ha o más",
    classes: [{ subcategory: "Parque", label: "Parque" }],
    nameFirst: true,
  },
  // D-236: leisure from OSM, the four groups of «Ocio» in the search. Fast food is not a restaurant here.
  {
    key: "bares",
    category: "commerce",
    chip: "Bares y cafeterías",
    one: "bar o cafetería",
    many: "bares y cafeterías",
    none: "OpenStreetMap no tiene ningún bar ni cafetería",
    classes: [
      { subcategory: "Bar", label: "Bar" },
      { subcategory: "Pub", label: "Pub" },
      { subcategory: "Cafetería", label: "Cafetería" },
    ],
    leisure: true,
  },
  {
    key: "restaurantes",
    category: "commerce",
    chip: "Restaurantes",
    one: "restaurante",
    many: "restaurantes",
    none: "OpenStreetMap no tiene ningún restaurante",
    classes: [{ subcategory: "Restaurante", label: "Restaurante" }],
    leisure: true,
  },
  {
    key: "gimnasios",
    category: "sport",
    chip: "Gimnasios y deporte",
    one: "gimnasio o centro deportivo",
    many: "gimnasios y centros deportivos",
    none: "OpenStreetMap no tiene ningún gimnasio ni centro deportivo",
    classes: [
      { subcategory: "Gimnasio", label: "Gimnasio" },
      { subcategory: "Centro deportivo", label: "Centro deportivo" },
    ],
    leisure: true,
  },
  // «Cultura»: museums and libraries joined cinemas and theatres after test users asked for them
  {
    key: "cultura",
    category: "culture",
    chip: "Cultura",
    one: "espacio cultural",
    many: "espacios culturales",
    none: "OpenStreetMap no tiene ningún espacio cultural",
    classes: [
      { subcategory: "Museo", label: "Museo" },
      { subcategory: "Biblioteca", label: "Biblioteca" },
      { subcategory: "Teatro", label: "Teatro" },
      { subcategory: "Cine", label: "Cine" },
      { subcategory: "Centro cultural", label: "Centro cultural" },
    ],
    leisure: true,
  },
  {
    // D-237: context only (it never scores). The CRTM's park-and-ride car parks next to stations
    // (with their spaces and whether they are free) and the Ayuntamiento de Madrid's public, mixed
    // and residents' ones. Their names already say what they are («Aparcamiento público. Usera»).
    key: "aparcamiento",
    category: "other",
    chip: "Aparcamientos",
    one: "aparcamiento",
    many: "aparcamientos",
    none: "Ningún aparcamiento de los publicados en abierto",
    classes: [
      { subcategory: "Aparcamiento disuasorio", label: "Aparcamiento disuasorio" },
      { subcategory: "Aparcamiento público", label: "Aparcamiento público" },
      { subcategory: "Aparcamiento mixto", label: "Aparcamiento mixto" },
      { subcategory: "Aparcamiento para residentes", label: "Aparcamiento para residentes" },
    ],
    nameFirst: true,
    context: true,
  },
];

const BY_KEY = new Map(FACILITY_TYPES.map((t) => [t.key, t]));

export function facilityType(key: FacilityKey): FacilityType {
  const type = BY_KEY.get(key);
  if (!type) throw new Error(`Unknown facility type ${key}`);
  return type;
}

export interface FacilityQuery {
  category: PlaceCategory;
  subcategories: string[];
}

/**
 * What to ask /api/v1/places for a zone: one query per category with the subcategories that count.
 * Leisure is left out (D-236): it goes apart, only when one of its types is pressed (leisureQuery).
 */
export function facilityQueries(): FacilityQuery[] {
  const byCategory = new Map<PlaceCategory, FacilityQuery>();
  for (const type of FACILITY_TYPES.filter((t) => !t.leisure)) {
    const query = byCategory.get(type.category) ?? { category: type.category, subcategories: [] };
    query.subcategories.push(...type.classes.map((c) => c.subcategory));
    byCategory.set(type.category, query);
  }
  return [...byCategory.values()];
}

/**
 * One facility on the map and in the list. `detail` is what the register says beyond its name:
 * its capacity («120 plazas autorizadas», later «1.300 camas») and whether it was placed by its
 * address; null when there is nothing to add.
 */
export interface Facility {
  id: string;
  type: FacilityKey;
  label: string;
  name: string | null;
  detail: string | null;
  /** Dataset of the capacity when it is not the register's (hospital beds, D-218), named from /datasets. */
  source: string | null;
  /** Hospitals: public (network of the Servicio Madrileño de Salud) or private (D-239); null when the API does not say. */
  dependency: Dependency | null;
  /** Hospitals: a public one a company runs («gestión privada», D-239); never true for a private one */
  managedPrivately: boolean;
  /** What the register says it holds («651 camas instaladas»), also inside `detail`; null when it does not say */
  capacity: { value: number; unit: string } | null;
  /** Placed by its address (D-216): «ubicación aproximada», also inside `detail` */
  approximate: boolean;
  /** Car parks (D-237): whether parking is free and how many spaces, when the CRTM publishes them */
  fee?: AccessFee;
  spaces?: number | null;
  lon: number;
  lat: number;
}

/**
 * The source of some capacities, as the panel cites it (centros.camas): «Camas instaladas a {updated},
 * según el {catalogue} del {publisher}.», with the link on the catalogue.
 */
export interface CapacitySource {
  id: string;
  catalogue: string;
  publisher: string;
  /** «31 de diciembre de 2024», from the dataset's name */
  updated: string | null;
  href: string | null;
}

/**
 * The hospital beds' source as line D wrote it (D-218), while /datasets has not answered or failed:
 * the beds never show without their source and date (reviews of PR #16 and #17).
 */
const CAPACITY_SOURCE: Partial<Record<FacilityKey, Omit<CapacitySource, "id">>> = {
  hospital: { catalogue: "Catálogo Nacional de Hospitales 2025", publisher: "Ministerio de Sanidad", updated: "31 de diciembre de 2024", href: null },
};

/** Where the capacities of a type's list come from, when not from the register (Facility.source). */
export function capacitySources(type: FacilityKey, items: readonly Facility[], datasets: readonly DatasetRef[] | null): CapacitySource[] {
  const ids = [...new Set(items.flatMap((f) => (f.source ? [f.source] : [])))];
  return ids.flatMap((id): CapacitySource[] => {
    const ref = datasets?.find((d) => d.dataset_id === id);
    if (ref) {
      const catalogue = ref.name.split(" (")[0] ?? ref.name;
      return [{ id, catalogue, publisher: ref.publisher, updated: updatedInWords(ref.name), href: ref.url ?? null }];
    }
    const fixed = CAPACITY_SOURCE[type];
    return fixed ? [{ id, ...fixed }] : [];
  });
}

/** Street types of the pharmacy addresses in the source («AVDA de Alberto Alcocer 22»). */
const STREET: Record<string, string> = {
  AVDA: "Avenida",
  CTRA: "Carretera",
  CMNO: "Camino",
  TRVA: "Travesía",
  GTA: "Glorieta",
  SECT: "Sector",
  URB: "Urbanización",
  BULEV: "Bulevar",
  PSAJE: "Pasaje",
  CLLON: "Callejón",
  CUSTA: "Cuesta",
};

/** «Farmacia · AVDA de Alberto Alcocer 22» -> «Avenida de Alberto Alcocer 22»: the source names a pharmacy by its address. */
function pharmacyAddress(name: string): string {
  const address = name.includes(" · ") ? name.slice(name.indexOf(" · ") + 3) : name;
  const [street = "", ...rest] = address.trim().split(/\s+/);
  const kind = STREET[street] ?? titleCase(street);
  return [kind, titleCase(rest.join(" "))].filter(Boolean).join(" ");
}

/** «SANITAS RESIDENCIAL EL VISO, RESIDENCIA DE PERSONAS MAYORES»: the tail repeats the type. */
const TYPE_TAIL = /^(RESIDENCIA|CENTRO DE D[IÍ]A|HOGAR|CLUB)/;

function placeName(place: PlaceFeature, type: FacilityType): string | null {
  const { name, subcategory } = place.properties;
  // «Hospital general (Madrid)», «Centro de salud (Pinto)»: the source has no proper name for it
  if (!name || (subcategory && name.startsWith(`${subcategory} (`))) return null;
  // Leisure (D-236): the name as OpenStreetMap writes it («VIPS»); «Bar sin nombre» when it has none
  if (type.leisure) return name === `${subcategory} sin nombre` ? null : name;
  if (type.key === "farmacia") return pharmacyAddress(name);
  const comma = name.lastIndexOf(", ");
  const own = comma > 0 && TYPE_TAIL.test(name.slice(comma + 2)) ? name.slice(0, comma) : name;
  return titleCase(own);
}

/** Schools by the ownership of the register, when the API gives it (places-1). */
const SCHOOL_BY_OWNERSHIP = { publica: PUBLIC_SCHOOL, concertada: "Colegio concertado", privada: "Colegio privado" } as const;

/** Coordinates the register lacked or had wrong, found again from the address (D-216). */
const GEOCODED = "ubicación aproximada";

export type Dependency = "publica" | "privada";

/**
 * Public (the network of the Servicio Madrileño de Salud) or private (D-218, D-239): on the place
 * itself, or with its beds from an API older than D-239. A user asked to tell public from private,
 * so it goes as a pill before the hospital's name (hospitalLine).
 */
function dependencyOf(place: PlaceFeature): Dependency | null {
  return place.properties.dependency ?? place.properties.capacity?.dependency ?? null;
}

/**
 * centros.hospital.pastilla: the pill before a hospital's name, «Público» filled and «Privado»
 * outlined. A word, never only a colour or a symbol (WCAG 1.4.1).
 */
export const DEPENDENCY_PILL: Record<Dependency, string> = { publica: "Público", privada: "Privado" };

/** centros.hospital.gestion_privada: under the name of a hospital of the public network a private company runs. */
const PRIVATE_MANAGEMENT = "gestión privada";

/** A hospital as the list and its map label show it (centros.hospital.fila). */
export interface HospitalLine {
  /** The pill before the name; null when the API does not say */
  dependency: Dependency | null;
  /** Its own name, or its type when the source gives none («Hospital especializado») */
  name: string;
  /** Small, under the name: its type when the name does not say it, «gestión privada», «ubicación aproximada» */
  notes: string[];
  /** Beside a bed icon: «651», read aloud as «651 camas instaladas» */
  beds: { short: string; full: string } | null;
}

/**
 * The name first, the pill before it, and the beds as a figure beside a bed icon (Mariano, 15 nov:
 * «si tengo que leer todo eso me da algo»). «gestión privada» goes under the name, never next to
 * «Privado» (it only goes with a public one, D-239). A general hospital's type is left out: its
 * name already says it is a hospital.
 */
export function hospitalLine(f: Facility): HospitalLine {
  const kind = f.name && f.label !== "Hospital" ? f.label : null;
  const notes = [kind, f.dependency === "publica" && f.managedPrivately ? PRIVATE_MANAGEMENT : null, f.approximate ? GEOCODED : null];
  const beds = f.capacity ? { short: formatNumber(f.capacity.value, 0), full: `${formatNumber(f.capacity.value, 0)} ${f.capacity.unit}` } : null;
  return { dependency: f.dependency, name: f.name ?? f.label, notes: notes.filter((n): n is string => n !== null), beds };
}

/** centros.hospital.dependencia: what «público», «gestión privada» and «privado» mean, folded behind «¿Qué significa público y privado?». */
export const HOSPITAL_DEPENDENCY_NOTE =
  "Público: de la red del Servicio Madrileño de Salud, aunque lo gestione una empresa («gestión privada»). Privado: el resto. Según el registro de centros sanitarios y la red de hospitales públicos de la Comunidad de Madrid.";

/** centros.hospital.reparto: «2 públicos y 3 privados», «1 público», «2 privados»; null when the API does not say for any. */
export function hospitalSplitText(items: readonly Pick<Facility, "dependency">[]): string | null {
  const count = (d: Dependency) => items.filter((f) => f.dependency === d).length;
  const parts = [
    [count("publica"), "público", "públicos"],
    [count("privada"), "privado", "privados"],
  ] as const;
  const said = parts.filter(([n]) => n > 0).map(([n, one, many]) => `${formatNumber(n, 0)} ${n === 1 ? one : many}`);
  return said.length ? said.join(" y ") : null;
}

/** Whether a car park is free (D-237), as the CRTM publishes it. */
const ACCESS_FEE_TEXT = { free: "gratuito", paid: "de pago", mixed: "gratuito y de pago" } as const;

/** «966 camas instaladas · ubicación aproximada», «210 plazas · gratuito»: only what the register and the API say. */
function detailText(place: PlaceFeature): string | null {
  const { capacity, coordinates, access_fee: fee } = place.properties;
  const parts = [
    capacity ? `${formatNumber(capacity.value, 0)} ${capacity.unit}` : null,
    fee ? ACCESS_FEE_TEXT[fee] : null,
    coordinates === "geocoded" ? GEOCODED : null,
  ];
  return parts.filter(Boolean).join(" · ") || null;
}

/** A type with a row shows what the row counts (`gap_rows`); without that field, its subcategories. */
function counts(place: PlaceFeature, type: FacilityType): boolean {
  const rows = place.properties.gap_rows;
  return !type.row || rows === undefined || rows.includes(type.row);
}

function facility(place: PlaceFeature, type: FacilityType): Facility | null {
  const cls = type.classes.find((c) => c.subcategory === place.properties.subcategory);
  if (!cls || !counts(place, type)) return null;
  const [lon = 0, lat = 0] = place.geometry.coordinates;
  const { ownership } = place.properties;
  const dependency = type.key === "hospital" ? dependencyOf(place) : null;
  const managedPrivately = dependency === "publica" && place.properties.management === "privada";
  const label = type.key === "colegio" && ownership ? SCHOOL_BY_OWNERSHIP[ownership] : cls.label;
  // Only a capacity from another catalogue is cited apart (hospital beds): the places of mayores
  // carry their own register's «plazas autorizadas», which are not beds
  const { capacity, coordinates } = place.properties;
  const source = CAPACITY_SOURCE[type.key] ? (capacity?.dataset_id ?? null) : null;
  // Car parks (D-237): whether parking is free and how many spaces, when the CRTM publishes them
  const parking = type.key === "aparcamiento" ? { fee: place.properties.access_fee ?? null, spaces: capacity?.value ?? null } : {};
  return {
    id: String(place.id),
    type: type.key,
    label,
    name: placeName(place, type),
    detail: detailText(place),
    source,
    dependency,
    managedPrivately,
    capacity: capacity ? { value: capacity.value, unit: capacity.unit } : null,
    approximate: coordinates === "geocoded",
    lon,
    lat,
    ...parking,
  };
}

const DEPENDENCY_ORDER = { publica: 0, privada: 1 } as const;

/** Public hospitals first, then private, then those the API does not class; other types all tie. */
function byDependency(a: Facility, b: Facility): number {
  const order = (f: Facility) => (f.dependency ? DEPENDENCY_ORDER[f.dependency] : 2);
  return order(a) - order(b);
}

function byName(a: Facility, b: Facility): number {
  if (a.name && b.name) return a.name.localeCompare(b.name, "es");
  return Number(a.name === null) - Number(b.name === null);
}

/**
 * The zone's places by type, named places first in alphabetical order (hospitals: the public ones
 * first, D-239); the rest are left out.
 */
export function groupFacilities(places: readonly PlaceFeature[]): Record<FacilityKey, Facility[]> {
  const groups = Object.fromEntries(FACILITY_TYPES.map((t) => [t.key, [] as Facility[]])) as Record<FacilityKey, Facility[]>;
  for (const place of places) {
    for (const type of FACILITY_TYPES) {
      if (place.properties.category !== type.category) continue;
      const item = facility(place, type);
      if (item) groups[type.key].push(item);
    }
  }
  for (const list of Object.values(groups)) list.sort((a, b) => byDependency(a, b) || byName(a, b));
  return groups;
}

/** «23 colegios con primaria en Chamartín», «1 hospital en …», «Ninguna farmacia en …». */
export function facilityCountText(key: FacilityKey, n: number, zone: string): string {
  const type = facilityType(key);
  if (n === 0) return `${type.none} en ${zone}`;
  return `${formatNumber(n, 0)} ${n === 1 ? type.one : type.many} en ${zone}`;
}

export type FacilityPoint = GeoJSON.Feature<GeoJSON.Point, { id: string; type: FacilityKey }>;

/** Points of the clustered layer; the map looks the facility up by `id` when one is clicked. */
export function facilitiesGeoJSON(list: readonly Facility[]): GeoJSON.FeatureCollection<GeoJSON.Point, FacilityPoint["properties"]> {
  return {
    type: "FeatureCollection",
    features: list.map((f) => ({
      type: "Feature",
      id: f.id,
      geometry: { type: "Point", coordinates: [f.lon, f.lat] },
      properties: { id: f.id, type: f.type },
    })),
  };
}

/** The types pressed in «Todos los centros», in the order of the buttons, without repeats. */
export function orderedTypes(types: Iterable<FacilityKey>): FacilityKey[] {
  const pressed = new Set(types);
  return FACILITY_TYPES.map((t) => t.key).filter((key) => pressed.has(key));
}

/** «Todos los centros» with several types at once (petición de Mariano): their places, in the order of the buttons. */
export function selectedFacilities(groups: Readonly<Record<FacilityKey, readonly Facility[]>>, types: Iterable<FacilityKey>): Facility[] {
  return orderedTypes(types).flatMap((key) => groups[key]);
}

/**
 * «23 colegios con primaria en Chamartín y 12 farmacias en Chamartín»: the types pressed, for the
 * panel's status (with «Ningún parque…» too) or, with `empty: false`, for the map's description;
 * null when nothing is left.
 */
export function selectedCountText(
  groups: Readonly<Record<FacilityKey, readonly Facility[]>>,
  types: Iterable<FacilityKey>,
  zone: string,
  { empty = true }: { empty?: boolean } = {},
): string | null {
  const parts = orderedTypes(types)
    .filter((key) => empty || groups[key].length > 0)
    .map((key) => facilityCountText(key, groups[key].length, zone));
  if (!parts.length) return null;
  return parts.length === 1 ? (parts[0] ?? null) : `${parts.slice(0, -1).join(", ")} y ${parts[parts.length - 1]}`;
}

/** Each type's colour on the map and on its button (tokens.css, --fac-*): never a state colour. */
export const FACILITY_COLOR_TOKEN: Record<FacilityKey, string> = {
  colegio: "fac-colegio",
  escuela_infantil: "fac-escuela-infantil",
  centro_salud: "fac-centro-salud",
  hospital: "fac-hospital",
  farmacia: "fac-farmacia",
  mayores: "fac-mayores",
  parque: "park",
  // One colour for the four leisure groups (D-236): their icons tell them apart, the map stays calm
  bares: "fac-ocio",
  restaurantes: "fac-ocio",
  gimnasios: "fac-ocio",
  cultura: "fac-ocio",
  aparcamiento: "fac-aparcamiento",
};

/** The types of «Ocio» (D-236), in the order of their buttons. */
export const LEISURE_FACILITY_KEYS: readonly LeisureFacilityKey[] = ["bares", "restaurantes", "gimnasios", "cultura"];

export function isLeisureFacility(key: FacilityKey): key is LeisureFacilityKey {
  return (LEISURE_FACILITY_KEYS as readonly FacilityKey[]).includes(key);
}

/**
 * The services «Todos» turns on: every type but leisure and context. A bar is not a service of the
 * zone, and in Centro the four leisure types alone are 2.683 places (review of PR #62, R-07); car
 * parks are context, shown when asked for (review of PR #65, R-06).
 */
export const SERVICE_FACILITY_KEYS: readonly FacilityKey[] = FACILITY_TYPES.filter((t) => !t.leisure && !t.context).map((t) => t.key);

/**
 * «Todos» on: every service, keeping the leisure and context types already pressed. It turns
 * neither on, nor off (review of PR #65, R-01: car parks stay as the person left them).
 */
export function allServicesOn(current: readonly FacilityKey[]): FacilityKey[] {
  return [...SERVICE_FACILITY_KEYS, ...current.filter((key) => isLeisureFacility(key) || facilityType(key).context)];
}

/** What to ask /api/v1/places for one leisure type of a zone, apart and only when its button is pressed. */
export function leisureQuery(key: LeisureFacilityKey): FacilityQuery {
  const type = facilityType(key);
  return { category: type.category, subcategories: type.classes.map((c) => c.subcategory) };
}

/**
 * The types «Todos los centros» offers: the services always; leisure once its dataset is published
 * (GET /datasets, D-236). Its count comes when its button is pressed, and with no place the count
 * says that OpenStreetMap has none, never that the zone has none.
 */
export function offeredTypes(leisure: boolean, parking = false): FacilityType[] {
  return FACILITY_TYPES.filter((t) => (!t.leisure || leisure) && (!t.context || parking));
}

/**
 * «Aparcamientos» is offered once one of its datasets is published (GET /datasets, D-237): before
 * the data are synced its button would say a false 0 (review of PR #65, R-05).
 */
export const PARKING_DATASETS = ["crtm_aparcamientos_disuasion", "ayto_aparcamientos_publicos", "ayto_aparcamientos_residentes"] as const;

export function parkingAvailable(datasets: readonly { dataset_id: string }[] | null | undefined): boolean {
  return datasets?.some((d) => (PARKING_DATASETS as readonly string[]).includes(d.dataset_id)) ?? false;
}

/** «Ocio» is offered in the search once its dataset is published (GET /datasets), never before (D-236). */
export const LEISURE_DATASET = "osm_ocio";

export function leisureAvailable(datasets: readonly { dataset_id: string }[] | null | undefined): boolean {
  return datasets?.some((d) => d.dataset_id === LEISURE_DATASET) ?? false;
}

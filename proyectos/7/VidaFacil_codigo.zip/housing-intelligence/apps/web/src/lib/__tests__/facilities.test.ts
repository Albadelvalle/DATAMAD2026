import { readFileSync } from "node:fs";

import { describe, expect, it } from "vitest";

import type { DatasetRef } from "../../contracts/dataset_list_response";
import type { PlaceCategory } from "../../contracts/places_response";
import {
  allServicesOn,
  type Facility,
  type FacilityKey,
  FACILITY_TYPES,
  DEPENDENCY_PILL,
  HOSPITAL_DEPENDENCY_NOTE,
  hospitalLine,
  hospitalSplitText,
  facilitiesGeoJSON,
  capacitySources,
  facilityCountText,
  facilityQueries,
  facilityType,
  groupFacilities,
  isLeisureFacility,
  LEISURE_FACILITY_KEYS,
  leisureAvailable,
  leisureQuery,
  offeredTypes,
  parkingAvailable,
  orderedTypes,
  selectedCountText,
  selectedFacilities,
  SERVICE_FACILITY_KEYS,
} from "../map/facilities";
import type { PlaceFeature } from "../map/places";

function place(
  id: string,
  category: PlaceCategory,
  subcategory: string,
  name: string,
  lon = -3.68,
  lat = 40.45,
  extra: Partial<PlaceFeature["properties"]> = {},
): PlaceFeature {
  return {
    type: "Feature",
    id,
    geometry: { type: "Point", coordinates: [lon, lat] },
    properties: { name, category, subcategory, municipio: "28079", seccion: "ES.28.SEC.2807905001", confidence: 1, ...extra },
  };
}

const CATALOG_COLEGIO = [
  "COLEGIO DE EDUCACIÓN INFANTIL Y PRIMARIA",
  "COLEGIO DE EDUCACIÓN INFANTIL, PRIMARIA Y SECUNDARIA",
  "COLEGIO DE EDUCACIÓN PRIMARIA",
  "CENTRO PRIVADO DE EDUCACIÓN INFANTIL Y PRIMARIA",
  "CENTRO PRIVADO DE EDUCACIÓN INFANTIL, PRIMARIA Y SECUNDARIA",
  "CENTRO PRIVADO DE EDUCACIÓN PRIMARIA",
  "CENTRO PRIVADO DE EDUCACIÓN PRIMARIA Y SECUNDARIA",
];

describe("facility types", () => {
  it("count the same places as the rows of «Qué falta» (data/catalog/features)", () => {
    const sub = (key: string) => FACILITY_TYPES.find((t) => t.key === key)?.classes.map((c) => c.subcategory);
    expect(sub("colegio")).toEqual(CATALOG_COLEGIO);
    expect(sub("escuela_infantil")).toEqual(["ESCUELA INFANTIL", "ESCUELA  INFANTIL-CASA DE NIÑOS", "ESCUELA INFANTIL PRIVADA", "CENTRO PRIVADO DE EDUCACIÓN INFANTIL"]);
    expect(sub("centro_salud")).toEqual(["Centro de salud", "Consultorio de atención primaria"]);
    expect(sub("farmacia")).toEqual(["Farmacia"]);
    expect(sub("mayores")).toEqual(["CENTROS DE DÍA: OTROS", "HOGARES Y CLUBES"]);
  });

  it("ask /places once per category, by zone and subcategory, never a whole layer", () => {
    const queries = facilityQueries();
    // Leisure (D-236) is asked apart, only when one of its types is pressed (R-07); car parks (D-237) are in it
    expect(queries.map((q) => q.category)).toEqual(["education", "health", "pharmacy", "social", "green", "other"]);
    // Car parks (D-237): never the air quality stations, which are places of the same category
    expect(queries.find((q) => q.category === "other")?.subcategories).not.toContain("Estación de calidad del aire");
    const health = queries.find((q) => q.category === "health");
    expect(health?.subcategories).toContain("Hospital general");
    // Pharmacies have their own category since D-216
    expect(health?.subcategories).not.toContain("Farmacia");
    expect(queries.find((q) => q.category === "pharmacy")?.subcategories).toEqual(["Farmacia"]);
    // The «Centro Polivalente» of health are the social records repeated (FASE_PRUEBAS, T1): left out
    expect(health?.subcategories).not.toContain("Centro Polivalente");
    for (const q of queries) expect(q.subcategories.length).toBeGreaterThan(0);
  });
});

describe("groupFacilities", () => {
  const places = [
    place("1", "education", "COLEGIO DE EDUCACIÓN INFANTIL Y PRIMARIA", "PADRE POVEDA"),
    place("2", "education", "CENTRO PRIVADO DE EDUCACIÓN INFANTIL, PRIMARIA Y SECUNDARIA", "CIUDAD JARDIN"),
    place("3", "education", "INSTITUTO DE EDUCACIÓN SECUNDARIA", "RAMIRO DE MAEZTU"),
    place("4", "health", "Hospital general", "Hospital general (Madrid)"),
    place("5", "health", "Hospital especializado", "Hospital especializado (Madrid)"),
    place("6", "pharmacy", "Farmacia", "Farmacia · AVDA de Alberto Alcocer 22"),
    place("7", "health", "Centro Polivalente", "Centro Polivalente (Madrid)"),
    place("8", "social", "RESIDENCIAS DE PERSONAS MAYORES MIXTA", "SANITAS RESIDENCIAL EL VISO, RESIDENCIA DE PERSONAS MAYORES"),
    place("9", "social", "CENTROS DE DÍA: OTROS", "JUAN PABLO II AYUNTAMIENTO DE MADRID, CENTRO DE DIA"),
    place("10", "health", "Consultorio de atención primaria", "Consultorio de atención primaria (Madrid)"),
  ];
  const groups = groupFacilities(places);

  it("puts each place in its type, and leaves out what no type counts", () => {
    expect(groups.colegio.map((f) => f.id)).toEqual(["2", "1"]);
    expect(groups.hospital).toHaveLength(2);
    expect(groups.farmacia).toHaveLength(1);
    // Residences are not in the row of «Centros de mayores» (hogares, clubes y centros de día)
    expect(groups.mayores.map((f) => f.id)).toEqual(["9"]);
    expect(groups.centro_salud).toHaveLength(1);
    expect(groups.escuela_infantil).toHaveLength(0);
    const all = Object.values(groups).flat();
    expect(all.map((f) => f.id)).not.toContain("3");
    expect(all.map((f) => f.id)).not.toContain("7");
  });

  it("names each place in plain words, and never invents a name the source does not give", () => {
    const one = (list: Facility[], id: string) => list.find((f) => f.id === id);
    expect(one(groups.colegio, "1")).toMatchObject({ label: "Colegio público", name: "Padre Poveda" });
    expect(one(groups.colegio, "2")).toMatchObject({ label: "Colegio privado o concertado", name: "Ciudad Jardin" });
    expect(one(groups.hospital, "4")).toMatchObject({ label: "Hospital", name: null });
    expect(one(groups.hospital, "5")).toMatchObject({ label: "Hospital especializado", name: null });
    expect(one(groups.farmacia, "6")).toMatchObject({ label: "Farmacia", name: "Avenida de Alberto Alcocer 22" });
    expect(one(groups.mayores, "9")).toMatchObject({ label: "Centro de día", name: "Juan Pablo II Ayuntamiento de Madrid" });
    expect(one(groups.centro_salud, "10")).toMatchObject({ label: "Consultorio", name: null });
  });

  it("leaves the capacity empty until the API gives it: no figure is made up", () => {
    for (const f of Object.values(groups).flat()) expect(f.detail).toBeNull();
  });

  it("counts what the row of «Qué falta» counts (gap_rows), not every school of the subcategory", () => {
    const rows = groupFacilities([
      place("in", "education", "CENTRO PRIVADO DE EDUCACIÓN INFANTIL Y PRIMARIA", "CONCERTADO", -3.68, 40.45, { gap_rows: ["colegio"], ownership: "concertada" }),
      place("out", "education", "CENTRO PRIVADO DE EDUCACIÓN INFANTIL Y PRIMARIA", "PRIVADO", -3.68, 40.45, { gap_rows: [], ownership: "privada" }),
    ]);
    expect(rows.colegio.map((f) => f.id)).toEqual(["in"]);
  });

  it("says when a place was placed by its address (places-1, D-216)", () => {
    const geo = groupFacilities([
      place("g", "health", "Centro de salud", "Centro de salud (Madrid)", -3.68, 40.45, { coordinates: "geocoded", confidence: 0.7 }),
      place("m", "social", "HOGARES Y CLUBES", "ZURBANO", -3.68, 40.45, {
        coordinates: "geocoded",
        capacity: { value: 120, unit: "plazas autorizadas", dataset_id: "cm_centros_atencion_social" },
      }),
    ]);
    expect(geo.centro_salud[0]?.detail).toBe("ubicación aproximada");
    expect(geo.mayores[0]?.detail).toBe("120 plazas autorizadas · ubicación aproximada");
    // The places come from their own register: never cited as «Camas instaladas … según el …»
    expect(geo.mayores[0]?.source).toBeNull();
  });

  it("shows the capacity and the ownership when the API gives them (places-1, line A)", () => {
    // Test fixture: the figures are made up for the test only
    const typed = groupFacilities([
      place("h", "health", "Hospital general", "HOSPITAL UNIVERSITARIO LA PAZ", -3.69, 40.48, {
        capacity: { value: 1300, unit: "camas", dataset_id: "cm_hospitales" },
      }),
      place("c", "education", "CENTRO PRIVADO DE EDUCACIÓN INFANTIL Y PRIMARIA", "AMOROS", -3.68, 40.45, { ownership: "concertada" }),
      place("p", "education", "CENTRO PRIVADO DE EDUCACIÓN PRIMARIA", "OTRO", -3.68, 40.45, { ownership: "privada" }),
      place("f", "pharmacy", "Farmacia", "Farmacia · CALLE de Serrano 1"),
    ]);
    expect(typed.hospital[0]).toMatchObject({ name: "Hospital Universitario la Paz", detail: "1.300 camas" });
    expect(typed.colegio.map((f) => f.label)).toEqual(["Colegio concertado", "Colegio privado"]);
    expect(typed.farmacia[0]).toMatchObject({ name: "Calle de Serrano 1" });
  });

  it("names hospitals and their beds from the Catálogo Nacional de Hospitales, public or private in a pill (D-218, D-239)", () => {
    // Test fixture published by line A with the contract (data/fixtures/contracts), not demo data.
    const url = new URL("../../../../../data/fixtures/contracts/places.hospitales_madrid.fixture.json", import.meta.url);
    const { features } = JSON.parse(readFileSync(url, "utf8")) as { features: PlaceFeature[] };
    const hospitals = groupFacilities(features).hospital;
    const doce = hospitals.find((f) => f.name === "Hospital Universitario 12 de Octubre");
    expect(doce).toMatchObject({ label: "Hospital", dependency: "publica", detail: "1.161 camas instaladas", source: "ms_catalogo_nacional_hospitales" });
    // The name first, the pill before it and the beds as a figure (Mariano, 15 nov), read aloud whole
    expect(hospitalLine(doce as Facility)).toEqual({
      dependency: "publica",
      name: "Hospital Universitario 12 de Octubre",
      notes: [],
      beds: { short: "1.161", full: "1.161 camas instaladas" },
    });
    // «Privado No Benéfico» in the register, in the network of the Servicio Madrileño de Salud by
    // concierto singular: public, run by a company (D-239). «gestión privada» goes under its name
    const jd = hospitals.find((f) => f.name === "Hospital Universitario Fundación Jiménez Díaz");
    expect(jd).toMatchObject({ label: "Hospital", detail: "651 camas instaladas", dependency: "publica", managedPrivately: true });
    expect(hospitalLine(jd as Facility)).toMatchObject({ dependency: "publica", notes: ["gestión privada"], beds: { short: "651", full: "651 camas instaladas" } });
    expect(hospitals.filter((f) => hospitalLine(f).notes.includes("gestión privada"))).toHaveLength(1);
    expect(HOSPITAL_DEPENDENCY_NOTE).toMatch(/^Público: de la red del Servicio Madrileño de Salud.*«gestión privada».*Privado: el resto/);
    // The pill says it once: neither the label nor the detail repeats who runs it
    for (const f of hospitals) expect(`${f.label} ${f.detail ?? ""}`).not.toMatch(/gestión|públic|privad/);
    // Beds only with their source, and never a made-up name: the generic «Hospital general (Madrid)» stays unnamed
    expect(hospitals.some((f) => f.name === null)).toBe(true);
    for (const f of hospitals) expect(f.source !== null).toBe(/camas/.test(f.detail ?? ""));
  });

  it("labels each hospital as public or private from the place itself or, with an older API, from its beds (D-239)", () => {
    // Test fixture: made-up hospitals for the test only
    const beds = (dependency: "publica" | "privada") => ({ value: 100, unit: "camas instaladas", dataset_id: "ms_catalogo_nacional_hospitales", dependency });
    const { hospital, centro_salud } = groupFacilities([
      place("z", "health", "Hospital general", "HOSPITAL ZETA", -3.7, 40.4, { dependency: "privada" }),
      place("m", "health", "Hospital de salud mental y tratamiento de toxicomanías", "HOSPITAL EME", -3.7, 40.4, { capacity: beds("publica") }),
      place("e", "health", "Hospital especializado", "HOSPITAL E", -3.7, 40.4, { dependency: "privada", capacity: beds("publica") }),
      place("u", "health", "Hospital general", "HOSPITAL U"),
      place("a", "health", "Hospital general", "HOSPITAL A", -3.7, 40.4, { dependency: "publica" }),
      place("c", "health", "Centro de salud", "Centro de salud Uno", -3.7, 40.4, { dependency: "publica" }),
    ]);
    // Public first, then private, then the one the API does not class; by name inside each. The
    // type goes under the name when the name does not say it is a general hospital
    expect(hospital.map((f) => [hospitalLine(f).name, f.dependency, hospitalLine(f).notes])).toEqual([
      ["Hospital A", "publica", []],
      ["Hospital Eme", "publica", ["Hospital de salud mental"]],
      ["Hospital e", "privada", ["Hospital especializado"]], // the place's own field wins over the beds'
      ["Hospital Zeta", "privada", []],
      ["Hospital U", null, []],
    ]);
    expect(Object.values(DEPENDENCY_PILL)).toEqual(["Público", "Privado"]);
    expect(hospitalSplitText(hospital)).toBe("2 públicos y 2 privados");
    // A hospital of the public network a company runs is public, and says so; «gestión privada»
    // never goes with a private one (all of them are run privately)
    const managed = groupFacilities([
      place("g", "health", "Hospital general", "HOSPITAL GE", -3.7, 40.4, { dependency: "publica", management: "privada" }),
      place("p", "health", "Hospital general", "HOSPITAL PE", -3.7, 40.4, { dependency: "privada", management: "privada" }),
      place("s", "health", "Hospital general", "HOSPITAL ESE", -3.7, 40.4, { dependency: "publica", management: "publica" }),
    ]).hospital;
    expect(managed.map((f) => [DEPENDENCY_PILL[f.dependency ?? "publica"], hospitalLine(f).notes.join()])).toEqual([
      ["Público", ""],
      ["Público", "gestión privada"],
      ["Privado", ""],
    ]);
    expect(hospitalSplitText(managed)).toBe("2 públicos y 1 privado");
    expect(hospitalSplitText(hospital.slice(0, 1))).toBe("1 público");
    expect(hospitalSplitText(hospital.slice(4))).toBeNull();
    expect(hospitalSplitText([])).toBeNull();
    // Without a name, its type stands for it; placed by its address, it says so under the name
    const [unnamed] = groupFacilities([
      place("n", "health", "Hospital especializado", "Hospital especializado (Madrid)", -3.7, 40.4, { dependency: "privada", coordinates: "geocoded" }),
    ]).hospital;
    expect(hospitalLine(unnamed as Facility)).toEqual({ dependency: "privada", name: "Hospital especializado", notes: ["ubicación aproximada"], beds: null });
    // Only hospitals are told apart
    expect(centro_salud[0]).toMatchObject({ label: "Centro de salud", dependency: null });
  });

  it("sorts named places by name, after them the ones without a name", () => {
    const sorted = groupFacilities([
      place("a", "health", "Hospital general", "Hospital general (Madrid)"),
      place("b", "social", "HOGARES Y CLUBES", "ZURBANO"),
      place("c", "social", "HOGARES Y CLUBES", "ÁLAMOS"),
    ]);
    expect(sorted.mayores.map((f) => f.name)).toEqual(["Álamos", "Zurbano"]);
  });
});

describe("parks (DATA-018, D-222)", () => {
  // Test fixture: names as /places gives them for Retiro and Moncloa-Aravaca
  const parks = groupFacilities([
    place("r", "green", "Parque", "Parque del Retiro", -3.683, 40.415),
    place("s", "green", "Parque", "Parque sin nombre", -3.72, 40.44),
    place("c", "green", "Parque", "Casa de Campo", -3.756, 40.424),
    place("x", "green", "Jardín", "Jardín pequeño"),
  ]).parque;

  it("keeps every park of 1 ha or more the API gives, and only them, named as it names them", () => {
    expect(FACILITY_TYPES.find((t) => t.key === "parque")).toMatchObject({ category: "green", classes: [{ subcategory: "Parque" }] });
    expect(parks.map((f) => [f.label, f.name])).toEqual([
      ["Parque", "Casa de Campo"],
      ["Parque", "Parque del Retiro"],
      ["Parque", "Parque sin nombre"],
    ]);
    // No area in /places yet: nothing is made up
    for (const f of parks) expect(f.detail).toBeNull();
  });

  it("shows the area when the API gives it («Parque del Retiro · 118 ha»)", () => {
    // Test fixture: the area is made up for the test only
    const [retiro] = groupFacilities([
      place("r", "green", "Parque", "Parque del Retiro", -3.683, 40.415, { capacity: { value: 118, unit: "ha", dataset_id: "osm_parques" } }),
    ]).parque;
    // Its own dataset's area: no source line apart, as for the beds of a hospital
    expect(retiro).toMatchObject({ name: "Parque del Retiro", detail: "118 ha", source: null });
  });

  it("counts them as parks of 1 ha or more", () => {
    expect(facilityCountText("parque", 6, "Retiro")).toBe("6 parques de 1 ha o más en Retiro");
    expect(facilityCountText("parque", 1, "Tres Cantos")).toBe("1 parque de 1 ha o más en Tres Cantos");
    expect(facilityCountText("parque", 0, "Patones")).toBe("Ningún parque de 1 ha o más en Patones");
  });
});

describe("facilityCountText", () => {
  it("says how many there are, in singular, plural and none", () => {
    expect(facilityCountText("colegio", 23, "Chamartín")).toBe("23 colegios con primaria en Chamartín");
    expect(facilityCountText("colegio", 1, "Chamartín")).toBe("1 colegio con primaria en Chamartín");
    expect(facilityCountText("hospital", 0, "La Acebeda")).toBe("Ningún hospital en La Acebeda");
    expect(facilityCountText("farmacia", 0, "La Acebeda")).toBe("Ninguna farmacia en La Acebeda");
    expect(facilityCountText("escuela_infantil", 1234, "Madrid")).toBe("1.234 escuelas infantiles en Madrid");
    expect(facilityCountText("mayores", 2, "Tres Cantos")).toBe("2 centros de mayores en Tres Cantos");
    // The list has the consultorios too (pitch/textos_web.md, 12 nov)
    expect(facilityCountText("centro_salud", 7, "Chamartín")).toBe("7 centros de salud y consultorios en Chamartín");
    expect(facilityCountText("centro_salud", 1, "La Acebeda")).toBe("1 centro de salud o consultorio en La Acebeda");
    expect(facilityCountText("centro_salud", 0, "X")).toBe("Ningún centro de salud ni consultorio en X");
  });
});

describe("facilitiesGeoJSON", () => {
  it("makes points for the clustered layer, with what the map label shows", () => {
    const { colegio } = groupFacilities([place("1", "education", "COLEGIO DE EDUCACIÓN PRIMARIA", "LUIS BELLO", -3.67, 40.46)]);
    const geo = facilitiesGeoJSON(colegio);
    expect(geo.features).toHaveLength(1);
    expect(geo.features[0]).toMatchObject({
      type: "Feature",
      id: "1",
      geometry: { type: "Point", coordinates: [-3.67, 40.46] },
      properties: { id: "1", type: "colegio" },
    });
  });
});

describe("capacitySources", () => {
  const bed = (id: string, source: string | null): Facility => ({
    id,
    type: "hospital",
    label: "Hospital",
    name: id,
    detail: null,
    source,
    dependency: null,
    managedPrivately: false,
    capacity: null,
    approximate: false,
    lon: 0,
    lat: 0,
  });
  const items = [bed("a", "ms_catalogo_nacional_hospitales"), bed("b", "ms_catalogo_nacional_hospitales"), bed("c", null)];
  const ref = {
    dataset_id: "ms_catalogo_nacional_hospitales",
    name: "Catálogo Nacional de Hospitales 2025 (directorio de hospitales, actualizado a 31 de diciembre de 2024)",
    publisher: "Ministerio de Sanidad",
    is_cm_open_data: false,
    url: "https://www.sanidad.gob.es/",
  };

  it("cites the catalogue of the beds and its update date from /datasets, once per dataset (centros.camas)", () => {
    expect(capacitySources("hospital", items, [ref])).toEqual([
      {
        id: "ms_catalogo_nacional_hospitales",
        catalogue: "Catálogo Nacional de Hospitales 2025",
        publisher: "Ministerio de Sanidad",
        updated: "31 de diciembre de 2024",
        href: "https://www.sanidad.gob.es/",
      },
    ]);
  });

  it("never leaves the beds without their source and date while /datasets has not answered or failed: line D's fixed text", () => {
    expect(capacitySources("hospital", items, null)).toEqual([
      {
        id: "ms_catalogo_nacional_hospitales",
        catalogue: "Catálogo Nacional de Hospitales 2025",
        publisher: "Ministerio de Sanidad",
        updated: "31 de diciembre de 2024",
        href: null,
      },
    ]);
    expect(capacitySources("hospital", items, [])).toHaveLength(1);
  });

  it("keeps the fallback of the beds faithful: what the API's fixture gives today, but for the link", () => {
    const url = new URL("../../../../../data/fixtures/contracts/dataset_list.all.fixture.json", import.meta.url);
    const { datasets } = JSON.parse(readFileSync(url, "utf8")) as { datasets: DatasetRef[] };
    const [fromApi] = capacitySources("hospital", items, datasets);
    const [fallback] = capacitySources("hospital", items, null);
    expect({ ...fromApi, href: null }).toEqual(fallback);
  });

  it("has nothing to cite when no capacity comes from another dataset", () => {
    expect(capacitySources("farmacia", [bed("c", null)], null)).toEqual([]);
  });
});

describe("several types at once («Todos los centros», petición de Mariano)", () => {
  const f = (id: string, type: FacilityKey): Facility => ({
    id,
    type,
    label: id,
    name: null,
    detail: null,
    source: null,
    dependency: null,
    managedPrivately: false,
    capacity: null,
    approximate: false,
    lon: 0,
    lat: 0,
  });
  const groups = {
    colegio: [f("c1", "colegio"), f("c2", "colegio")],
    escuela_infantil: [],
    centro_salud: [],
    hospital: [],
    farmacia: [f("f1", "farmacia")],
    mayores: [],
    parque: [f("p1", "parque")],
    bares: [],
    restaurantes: [],
    gimnasios: [],
    cultura: [],
    aparcamiento: [],
  } as Record<FacilityKey, Facility[]>;

  it("keeps the order of the buttons, whatever the order they were pressed", () => {
    expect(orderedTypes(["parque", "colegio", "parque"])).toEqual(["colegio", "parque"]);
    expect(selectedFacilities(groups, ["farmacia", "colegio"]).map((x) => x.id)).toEqual(["c1", "c2", "f1"]);
    expect(selectedFacilities(groups, [])).toEqual([]);
  });

  it("says how many of each type are pressed, also none; the map leaves out the empty ones", () => {
    expect(selectedCountText(groups, ["hospital"], "Perales de Tajuña")).toBe("Ningún hospital en Perales de Tajuña");
    expect(selectedCountText(groups, ["farmacia", "colegio", "hospital"], "Chamartín", { empty: false })).toBe(
      "2 colegios con primaria en Chamartín y 1 farmacia en Chamartín",
    );
    expect(selectedCountText(groups, ["colegio", "farmacia", "parque"], "Chamartín")).toBe(
      "2 colegios con primaria en Chamartín, 1 farmacia en Chamartín y 1 parque de 1 ha o más en Chamartín",
    );
    expect(selectedCountText(groups, ["hospital"], "Chamartín", { empty: false })).toBeNull();
    expect(selectedCountText(groups, [], "Chamartín")).toBeNull();
  });
});

describe("car parks (D-237)", () => {
  // Test fixture: places shaped as /places gives them (places-1), names and figures from 14 nov
  const parks = groupFacilities([
    place("a", "other", "Aparcamiento disuasorio", "Aparcamiento disuasorio Doce de Octubre", -3.69, 40.37, {
      capacity: { value: 210, unit: "plazas", dataset_id: "crtm_aparcamientos_disuasion" },
      access_fee: "free",
    }),
    place("b", "other", "Aparcamiento público", "Aparcamiento público. Plaza de España"),
    place("c", "other", "Aparcamiento para residentes", "Aparcamiento para residentes Barceló"),
    place("d", "other", "Estación de calidad del aire", "Getafe"),
  ]).aparcamiento;

  it("lists the public, park-and-ride and residents' ones, never the air stations", () => {
    expect(parks.map((f) => f.id).sort()).toEqual(["a", "b", "c"]);
  });

  it("leads with the name and says the spaces and whether it is free, from the CRTM", () => {
    const doce = parks.find((f) => f.id === "a");
    expect(doce).toMatchObject({ label: "Aparcamiento disuasorio", detail: "210 plazas · gratuito", fee: "free", spaces: 210 });
    expect(parks.find((f) => f.id === "b")).toMatchObject({ detail: null, fee: null, spaces: null });
    expect(facilityType("aparcamiento").nameFirst).toBe(true);
  });

  it("is never counted by a row of «Qué falta»", () => {
    expect(facilityType("aparcamiento").row).toBeUndefined();
  });

  it("is offered once its datasets are published, never turned on by «Todos» (R-05, R-06)", () => {
    expect(parkingAvailable(null)).toBe(false);
    expect(parkingAvailable([{ dataset_id: "osm_parques" }])).toBe(false);
    expect(parkingAvailable([{ dataset_id: "crtm_aparcamientos_disuasion" }])).toBe(true);
    expect(offeredTypes(false).map((t) => t.key)).not.toContain("aparcamiento");
    expect(SERVICE_FACILITY_KEYS).not.toContain("aparcamiento");
    // «Todos» neither turns car parks on nor off (R-01 of the second review), as with leisure
    expect(allServicesOn(["colegio"])).toEqual([...SERVICE_FACILITY_KEYS]);
    expect(allServicesOn(["aparcamiento", "bares"])).toEqual([...SERVICE_FACILITY_KEYS, "aparcamiento", "bares"]);
    // «Entorno» still needs them in the zone's request
    expect(facilityQueries().find((q) => q.category === "other")?.subcategories).toContain("Aparcamiento disuasorio");
  });
});

describe("leisure from OpenStreetMap (D-236)", () => {
  const places = [
    place("b1", "commerce", "Bar", "Casa Paco"),
    place("b2", "commerce", "Pub", "Pub sin nombre"),
    place("b3", "commerce", "Cafetería", "LA TAPE"),
    place("r1", "commerce", "Restaurante", "Restaurante sin nombre"),
    place("g1", "sport", "Centro deportivo", "Polideportivo Municipal"),
    place("t1", "culture", "Teatro", "Teatro Real"),
    place("m1", "culture", "Museo", "Museo del Prado"),
    place("l1", "culture", "Biblioteca", "Biblioteca Eugenio Trías"),
    place("x1", "commerce", "Comida rápida", "Burger"), // not a class of any type: left out
  ];
  const groups = groupFacilities(places);

  it("groups the places in the four groups of «Ocio», each with what it is", () => {
    expect(groups.bares.map((f) => [f.label, f.name])).toEqual([
      ["Bar", "Casa Paco"],
      ["Cafetería", "LA TAPE"], // as OpenStreetMap writes it: never recased
      ["Pub", null], // «Pub sin nombre»: no name, only what it is
    ]);
    expect(groups.restaurantes.map((f) => [f.label, f.name])).toEqual([["Restaurante", null]]);
    expect(groups.gimnasios.map((f) => f.label)).toEqual(["Centro deportivo"]);
    // «Cultura»: museums and libraries too, each with what it is (D-236)
    expect(groups.cultura.map((f) => [f.label, f.name])).toEqual([
      ["Biblioteca", "Biblioteca Eugenio Trías"],
      ["Museo", "Museo del Prado"],
      ["Teatro", "Teatro Real"],
    ]);
    expect(Object.values(groups).flat()).toHaveLength(8);
  });

  it("counts them in plain words, and with none says what OpenStreetMap lacks, not what the zone lacks", () => {
    expect(facilityCountText("bares", 3, "Centro")).toBe("3 bares y cafeterías en Centro");
    expect(facilityCountText("restaurantes", 1, "Centro")).toBe("1 restaurante en Centro");
    expect(facilityCountText("bares", 0, "Patones")).toBe("OpenStreetMap no tiene ningún bar ni cafetería en Patones");
    expect(facilityCountText("restaurantes", 0, "Patones")).toBe("OpenStreetMap no tiene ningún restaurante en Patones");
    expect(facilityCountText("gimnasios", 0, "Patones")).toBe("OpenStreetMap no tiene ningún gimnasio ni centro deportivo en Patones");
    expect(facilityCountText("cultura", 2, "Centro")).toBe("2 espacios culturales en Centro");
    expect(facilityCountText("cultura", 1, "Patones")).toBe("1 espacio cultural en Patones");
    expect(facilityCountText("cultura", 0, "Patones")).toBe("OpenStreetMap no tiene ningún espacio cultural en Patones");
  });

  it("offers the leisure types once their dataset is published, and keeps them out of «Todos» and the zone's request", () => {
    const keys = (leisure: boolean) => offeredTypes(leisure).map((t) => t.key);
    const services = ["colegio", "escuela_infantil", "centro_salud", "hospital", "farmacia", "mayores", "parque"];
    expect(keys(false)).toEqual(services);
    expect(keys(true)).toEqual([...services, "bares", "restaurantes", "gimnasios", "cultura"]);
    expect(offeredTypes(true, true).map((t) => t.key)).toEqual([...services, "bares", "restaurantes", "gimnasios", "cultura", "aparcamiento"]);
    expect(SERVICE_FACILITY_KEYS).toEqual(services);
    expect(LEISURE_FACILITY_KEYS.every(isLeisureFacility)).toBe(true);
    expect(services.some((key) => isLeisureFacility(key as FacilityKey))).toBe(false);
    expect(leisureQuery("cultura")).toEqual({ category: "culture", subcategories: ["Museo", "Biblioteca", "Teatro", "Cine", "Centro cultural"] });
    expect(leisureQuery("bares")).toEqual({ category: "commerce", subcategories: ["Bar", "Pub", "Cafetería"] });
    expect(FACILITY_TYPES).toHaveLength(services.length + LEISURE_FACILITY_KEYS.length + 1); // + car parks (D-237)
  });

  it("offers «Ocio» in the search once its dataset is published", () => {
    expect(leisureAvailable(null)).toBe(false);
    expect(leisureAvailable([{ dataset_id: "osm_parques" }])).toBe(false);
    expect(leisureAvailable([{ dataset_id: "osm_parques" }, { dataset_id: "osm_ocio" }])).toBe(true);
  });
});

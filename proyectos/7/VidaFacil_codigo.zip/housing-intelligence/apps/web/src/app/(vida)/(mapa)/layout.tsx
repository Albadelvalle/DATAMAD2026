import type { ReactNode } from "react";

import FacilityLayerProvider from "@/components/map/FacilityLayerProvider";
import GapLayerProvider from "@/components/map/GapLayerProvider";
import MapProvider from "@/components/map/MapProvider";
import VidaMap from "@/components/map/VidaMap";
import MapSheet from "@/components/shell/MapSheet";

import styles from "./layout.module.css";

/**
 * Pages over the map (Mapa and Zona). The map stays mounted between them, so the camera can
 * fly from the 2D overview to a zone in 3D. On mobile the content goes in a bottom sheet.
 */
export default function MapaLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <MapProvider>
      <GapLayerProvider>
        <FacilityLayerProvider>
          <VidaMap />
          {/* data-map-layout: the header knows it is over the map (SiteHeader.module.css, D-251) */}
          <div className={styles.overlay} data-map-layout>
            <MapSheet>{children}</MapSheet>
          </div>
        </FacilityLayerProvider>
      </GapLayerProvider>
    </MapProvider>
  );
}
